package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.ChatMessage
import com.nexo.family.model.ChatPreview
import com.nexo.family.model.MessageKind
import com.nexo.family.ui.components.NexoAvatar
import com.nexo.family.ui.theme.NexoColors

@Composable
fun ChatDetailScreen(
    chat: ChatPreview,
    messages: List<ChatMessage>,
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit,
    onCallClick: () -> Unit,
    onVideoCallClick: () -> Unit,
    onAttachClick: () -> Unit,
    onVoiceClick: () -> Unit
) {
    var draft by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
    ) {
        // Chat Top Bar
        Surface(color = NexoColors.SurfaceBar) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Назад",
                            tint = NexoColors.TextPrimary
                        )
                    }
                    NexoAvatar(
                        initials = chat.initials,
                        accentColor = chat.accentColor,
                        size = 42.dp,
                        isOnline = chat.isOnline
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = chat.title,
                            color = NexoColors.TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = if (chat.isFamilyChat) "5 участников • 3 в сети" else if (chat.isOnline) "В сети" else "Не в сети",
                            color = if (chat.isOnline) NexoColors.SuccessGreen else NexoColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onCallClick) {
                        Icon(Icons.Rounded.Call, contentDescription = "Аудиозвонок", tint = NexoColors.Turquoise)
                    }
                    IconButton(onClick = onVideoCallClick) {
                        Icon(Icons.Rounded.Videocam, contentDescription = "Видеозвонок", tint = NexoColors.Purple)
                    }
                }
                HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.55f))
            }
        }

        // Honest stage notice banner
        Surface(
            color = NexoColors.GraphiteCard,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Shield, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Этап 1 (Интерфейс) • Доставка через Supabase Realtime — Этап 4",
                    color = NexoColors.TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // Messages list
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                MessageBubbleItem(msg = msg, showSender = chat.isFamilyChat && !msg.isMine)
            }
        }

        // Input Bar
        Surface(color = NexoColors.SurfaceBar) {
            Column {
                HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.55f))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .imePadding()
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onAttachClick) {
                        Icon(Icons.Rounded.AttachFile, contentDescription = "Вложение", tint = NexoColors.TextSecondary)
                    }
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Сообщение…", color = NexoColors.TextSecondary, fontSize = 14.sp) },
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NexoColors.GraphiteCard,
                            unfocusedContainerColor = NexoColors.GraphiteCard,
                            focusedBorderColor = NexoColors.Turquoise,
                            unfocusedBorderColor = NexoColors.CardBorder,
                            focusedTextColor = NexoColors.TextPrimary,
                            unfocusedTextColor = NexoColors.TextPrimary
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    if (draft.isBlank()) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(NexoColors.PurpleDim),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(onClick = onVoiceClick) {
                                Icon(Icons.Rounded.Mic, contentDescription = "Голосовое", tint = NexoColors.Purple)
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(NexoColors.Turquoise),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(onClick = {
                                onSendMessage(draft)
                                draft = ""
                            }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Send,
                                    contentDescription = "Отправить",
                                    tint = NexoColors.DeepNavy
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubbleItem(
    msg: ChatMessage,
    showSender: Boolean
) {
    val bubbleColor = if (msg.isMine) NexoColors.TurquoiseDim else NexoColors.GraphiteCard
    val bubbleShape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = if (msg.isMine) 18.dp else 4.dp,
        bottomEnd = if (msg.isMine) 4.dp else 18.dp
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isMine) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 295.dp)
                .clip(bubbleShape)
                .background(bubbleColor)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            if (showSender) {
                Text(
                    text = msg.senderName,
                    color = NexoColors.Turquoise,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(3.dp))
            }

            if (msg.kind == MessageKind.VOICE) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(NexoColors.Purple.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = "Воспроизвести", tint = NexoColors.Purple)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(msg.voiceDuration ?: "0:15", color = NexoColors.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                        Text("1× • Расшифровка ИИ (Этап 8)", color = NexoColors.TextSecondary, fontSize = 10.sp)
                    }
                }
            } else {
                Text(
                    text = msg.text,
                    color = NexoColors.TextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }

            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.align(Alignment.End),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = msg.time,
                    color = NexoColors.TextSecondary,
                    fontSize = 10.sp
                )
                if (msg.isMine) {
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        imageVector = if (msg.isRead) Icons.Rounded.DoneAll else Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = if (msg.isRead) NexoColors.SuccessGreen else NexoColors.TextSecondary,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}
