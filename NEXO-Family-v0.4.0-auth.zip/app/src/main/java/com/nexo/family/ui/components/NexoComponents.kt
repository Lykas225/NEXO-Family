package com.nexo.family.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.NexoTab
import com.nexo.family.ui.theme.NexoColors

@Composable
fun NexoTopBar(
    familyName: String,
    onlineCount: Int,
    unreadNotifications: Int,
    onNotificationsClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    Surface(
        color = NexoColors.SurfaceBar,
        tonalElevation = 0.dp
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // NEXO Emblem
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(NexoColors.Turquoise, NexoColors.Purple)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "N",
                        color = NexoColors.DeepNavy,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Spacer(Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = familyName,
                        color = NexoColors.TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(NexoColors.SuccessGreen)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "$onlineCount в сети • Закрытая группа",
                            color = NexoColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                // Notifications button
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(NexoColors.GraphiteCard)
                        .clickable { onNotificationsClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Notifications,
                        contentDescription = "Уведомления",
                        tint = NexoColors.TextPrimary,
                        modifier = Modifier.size(21.dp)
                    )
                    if (unreadNotifications > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 6.dp, end = 7.dp)
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(NexoColors.Turquoise)
                        )
                    }
                }

                Spacer(Modifier.width(10.dp))

                // User Avatar -> Profile & Settings
                NexoAvatar(
                    initials = "ВЫ",
                    accentColor = NexoColors.Turquoise,
                    size = 42.dp,
                    isOnline = true,
                    modifier = Modifier.clickable { onProfileClick() }
                )
            }
            HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.55f), thickness = 1.dp)
        }
    }
}

@Composable
fun NexoBottomBar(
    currentTab: NexoTab,
    onTabSelected: (NexoTab) -> Unit
) {
    Surface(
        color = NexoColors.SurfaceBar,
        tonalElevation = 0.dp
    ) {
        Column {
            HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.55f), thickness = 1.dp)
            NavigationBar(
                containerColor = NexoColors.SurfaceBar,
                tonalElevation = 0.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                val items: List<Pair<NexoTab, ImageVector>> = listOf(
                    NexoTab.CHATS to Icons.Rounded.ChatBubble,
                    NexoTab.FAMILY to Icons.Rounded.Groups,
                    NexoTab.EVENTS to Icons.Rounded.Event,
                    NexoTab.GALLERY to Icons.Rounded.PhotoLibrary,
                    NexoTab.AI to Icons.Rounded.AutoAwesome
                )
                items.forEach { (tab, icon) ->
                    val selected = currentTab == tab
                    val activeColor = if (tab == NexoTab.AI) NexoColors.Purple else NexoColors.Turquoise
                    val indicatorColor = if (tab == NexoTab.AI) NexoColors.PurpleDim else NexoColors.TurquoiseDim
                    NavigationBarItem(
                        selected = selected,
                        onClick = { onTabSelected(tab) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = tab.title,
                                modifier = Modifier.size(23.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = activeColor,
                            selectedTextColor = activeColor,
                            indicatorColor = indicatorColor,
                            unselectedIconColor = NexoColors.TextSecondary,
                            unselectedTextColor = NexoColors.TextSecondary
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun NexoAvatar(
    initials: String,
    accentColor: Color,
    size: Dp = 52.dp,
    isOnline: Boolean = false,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.size(size)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.18f))
                .border(1.5.dp, accentColor.copy(alpha = 0.65f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initials,
                color = accentColor,
                fontSize = (size.value * 0.34f).sp,
                fontWeight = FontWeight.Bold
            )
        }
        if (isOnline) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(size * 0.27f)
                    .clip(CircleShape)
                    .background(NexoColors.DeepNavy)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(NexoColors.SuccessGreen)
            )
        }
    }
}

@Composable
fun NexoCard(
    modifier: Modifier = Modifier,
    borderColor: Color = NexoColors.CardBorder.copy(alpha = 0.7f),
    containerColor: Color = NexoColors.GraphiteCard,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    val cardModifier = if (onClick != null) {
        modifier.clip(shape).clickable { onClick() }
    } else {
        modifier
    }
    Card(
        modifier = cardModifier,
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor),
        content = content
    )
}

@Composable
fun SectionLabel(title: String, trailing: String? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title.uppercase(),
            color = NexoColors.TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.4.sp
        )
        if (trailing != null) {
            Text(
                text = trailing,
                color = NexoColors.Turquoise,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
