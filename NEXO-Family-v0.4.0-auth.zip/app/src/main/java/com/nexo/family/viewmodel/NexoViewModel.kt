package com.nexo.family.viewmodel

import android.app.Application
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexo.family.data.*
import com.nexo.family.model.*
import com.nexo.family.ui.theme.NexoColors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class NexoViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = SessionStorage(application)
    private val client = SupabaseClient()

    private val _uiState = MutableStateFlow(createBaseState())
    val uiState: StateFlow<NexoUiState> = _uiState.asStateFlow()

    init {
        restoreSessionOnStart()
    }

    private fun restoreSessionOnStart() {
        val config = storage.getServerConfig()
        _uiState.update {
            it.copy(
                supabaseUrl = config.url,
                supabaseAnonKey = config.anonKey,
                isServerConfigured = config.isConfigured
            )
        }

        val saved = storage.getSession()
        if (!config.isConfigured || saved == null) {
            _uiState.update { it.copy(gate = AppGate.AUTH) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(gate = AppGate.CHECKING_SESSION, isLoading = true) }
            when (val refreshed = client.refreshSession(config, saved.refreshToken)) {
                is ApiResult.Success -> {
                    storage.saveSession(refreshed.data)
                    loadFamilyAndRoute(config, refreshed.data)
                }
                is ApiResult.Error -> {
                    storage.clearSession()
                    _uiState.update {
                        it.copy(
                            gate = AppGate.AUTH,
                            isLoading = false,
                            authNotice = "Сессия завершена. Войдите снова."
                        )
                    }
                }
            }
        }
    }

    fun saveServerConfig(url: String, anonKey: String) {
        storage.saveServerConfig(url, anonKey)
        val updated = storage.getServerConfig()
        _uiState.update {
            it.copy(
                supabaseUrl = updated.url,
                supabaseAnonKey = updated.anonKey,
                isServerConfigured = updated.isConfigured,
                authError = if (updated.isConfigured) null else "Проверьте формат URL (https://...) и публичный ключ.",
                authNotice = if (updated.isConfigured) "Параметры сервера сохранены." else null
            )
        }
    }

    fun signIn(email: String, password: String) {
        val config = storage.getServerConfig()
        if (!config.isConfigured) {
            _uiState.update { it.copy(authError = "Сначала укажите Project URL и Anon Key в настройках Supabase.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null, authNotice = null) }
            when (val res = client.signIn(config, email, password)) {
                is ApiResult.Success -> {
                    storage.saveSession(res.data)
                    loadFamilyAndRoute(config, res.data)
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, authError = res.message) }
                }
            }
        }
    }

    fun signUp(email: String, password: String) {
        val config = storage.getServerConfig()
        if (!config.isConfigured) {
            _uiState.update { it.copy(authError = "Сначала укажите Project URL и Anon Key в настройках Supabase.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null, authNotice = null) }
            when (val res = client.signUp(config, email, password)) {
                is ApiResult.Success -> {
                    val outcome = res.data
                    if (outcome.session != null) {
                        storage.saveSession(outcome.session)
                        loadFamilyAndRoute(config, outcome.session)
                    } else {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                authNotice = "Аккаунт создан! Подтвердите email по ссылке из письма и нажмите «Войти»."
                            )
                        }
                    }
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, authError = res.message) }
                }
            }
        }
    }

    fun createFamily(displayName: String, familyName: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession()
        if (!config.isConfigured || session == null) {
            _uiState.update { it.copy(gate = AppGate.AUTH, authError = "Требуется вход в аккаунт.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null) }
            when (val res = client.createFamily(config, session.accessToken, displayName, familyName)) {
                is ApiResult.Success -> {
                    loadFamilyAndRoute(config, session)
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, authError = res.message) }
                }
            }
        }
    }

    fun refreshFamilyFromServer() {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null) }
            loadFamilyAndRoute(config, session)
        }
    }

    fun signOut() {
        val config = storage.getServerConfig()
        val session = storage.getSession()
        viewModelScope.launch {
            if (config.isConfigured && session != null) {
                client.signOut(config, session.accessToken)
            }
            storage.clearSession()
            _uiState.update {
                createBaseState().copy(
                    gate = AppGate.AUTH,
                    supabaseUrl = config.url,
                    supabaseAnonKey = config.anonKey,
                    isServerConfigured = config.isConfigured,
                    authNotice = "Вы вышли из аккаунта."
                )
            }
        }
    }

    private suspend fun loadFamilyAndRoute(config: ServerConfig, session: StoredSession) {
        when (val bundleRes = client.fetchMyFamilyBundle(config, session)) {
            is ApiResult.Success -> {
                val bundle = bundleRes.data
                if (bundle == null) {
                    _uiState.update {
                        it.copy(
                            gate = AppGate.CREATE_FAMILY,
                            isLoading = false,
                            currentUserEmail = session.email,
                            authError = null
                        )
                    }
                } else {
                    val palette = listOf(
                        NexoColors.Turquoise,
                        NexoColors.Purple,
                        Color(0xFF38BDF8),
                        Color(0xFFA78BFA),
                        Color(0xFF34D399)
                    )
                    val uiMembers = bundle.members.mapIndexed { idx, m ->
                        val role = when (m.role) {
                            "owner" -> MemberRole.OWNER
                            "admin" -> MemberRole.ADMIN
                            else -> MemberRole.MEMBER
                        }
                        val isMe = m.userId == session.userId
                        FamilyMember(
                            id = m.userId,
                            name = if (isMe) "${m.displayName} (Вы)" else m.displayName,
                            role = role,
                            isOnline = isMe,
                            status = if (isMe) "В сети" else "Участник семьи",
                            joinedDate = m.joinedAt.ifEmpty { "Сегодня" },
                            initials = m.displayName.trim().take(2).uppercase().ifEmpty { "Н" },
                            avatarColor = palette[idx % palette.size]
                        )
                    }
                    val uiChats = bundle.chats.mapIndexed { idx, c ->
                        val isFam = c.kind == "family"
                        ChatPreview(
                            id = c.id,
                            title = c.title,
                            lastMessage = if (isFam) "Семейный чат создан на сервере" else "Личная переписка",
                            time = "Сейчас",
                            unreadCount = 0,
                            initials = if (isFam) "NF" else c.title.take(1).uppercase(),
                            accentColor = if (isFam) NexoColors.Turquoise else palette[(idx + 1) % palette.size],
                            isFamilyChat = isFam,
                            isPinned = isFam,
                            isOnline = true
                        )
                    }
                    val myRoleEnum = when (bundle.myRole) {
                        "owner" -> MemberRole.OWNER
                        "admin" -> MemberRole.ADMIN
                        else -> MemberRole.MEMBER
                    }
                    _uiState.update {
                        it.copy(
                            gate = AppGate.MAIN,
                            isLoading = false,
                            authError = null,
                            currentUserEmail = session.email,
                            currentUserDisplayName = bundle.myDisplayName,
                            currentUserRole = myRoleEnum,
                            familyId = bundle.familyId,
                            familyName = bundle.familyName,
                            memberLimit = bundle.memberLimit,
                            members = uiMembers,
                            chats = uiChats
                        )
                    }
                }
            }
            is ApiResult.Error -> {
                _uiState.update {
                    it.copy(
                        gate = AppGate.CREATE_FAMILY,
                        isLoading = false,
                        currentUserEmail = session.email,
                        authError = bundleRes.message
                    )
                }
            }
        }
    }

    fun selectTab(tab: NexoTab) {
        _uiState.update { it.copy(currentTab = tab, showProfile = false, selectedChatId = null) }
    }

    fun openProfile() {
        _uiState.update { it.copy(showProfile = true, selectedChatId = null) }
    }

    fun closeProfile() {
        _uiState.update { it.copy(showProfile = false) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun openChat(chatId: String) {
        _uiState.update { state ->
            val updatedChats = state.chats.map { chat ->
                if (chat.id == chatId) chat.copy(unreadCount = 0, hasMissedCall = false) else chat
            }
            state.copy(selectedChatId = chatId, chats = updatedChats)
        }
    }

    fun closeChat() {
        _uiState.update { it.copy(selectedChatId = null) }
    }

    fun sendLocalPreviewMessage(chatId: String, rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        _uiState.update { state ->
            val currentList = state.messagesByChat[chatId].orEmpty()
            val newMsg = ChatMessage(
                id = "local_${System.currentTimeMillis()}",
                chatId = chatId,
                senderName = state.currentUserDisplayName,
                text = text,
                time = "Сейчас",
                isMine = true,
                isRead = false
            )
            val updatedMap = state.messagesByChat.toMutableMap().apply {
                put(chatId, currentList + newMsg)
            }
            val updatedChats = state.chats.map { chat ->
                if (chat.id == chatId) chat.copy(lastMessage = text, time = "Сейчас") else chat
            }
            state.copy(messagesByChat = updatedMap, chats = updatedChats)
        }
    }

    fun toggleEventConfirmation(eventId: String) {
        _uiState.update { state ->
            val updated = state.events.map { event ->
                if (event.id == eventId) {
                    val nowConfirmed = !event.isConfirmedByMe
                    event.copy(
                        isConfirmedByMe = nowConfirmed,
                        confirmedCount = if (nowConfirmed) event.confirmedCount + 1 else (event.confirmedCount - 1).coerceAtLeast(0)
                    )
                } else event
            }
            state.copy(events = updated)
        }
    }

    fun toggleShoppingItem(itemId: String) {
        _uiState.update { state ->
            state.copy(
                shoppingList = state.shoppingList.map {
                    if (it.id == itemId) it.copy(isBought = !it.isBought) else it
                }
            )
        }
    }

    fun addShoppingItem(title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        _uiState.update { state ->
            val item = ShoppingItem(
                id = "shop_${System.currentTimeMillis()}",
                title = clean,
                category = "Семейное",
                isBought = false
            )
            state.copy(shoppingList = listOf(item) + state.shoppingList)
        }
    }

    fun toggleTask(taskId: String) {
        _uiState.update { state ->
            state.copy(
                tasks = state.tasks.map {
                    if (it.id == taskId) it.copy(isDone = !it.isDone) else it
                }
            )
        }
    }

    fun sendAiPreviewPrompt(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        _uiState.update { state ->
            val userMsg = AiChatItem("u_${System.currentTimeMillis()}", text, true, "Сейчас")
            val botMsg = AiChatItem(
                "a_${System.currentTimeMillis() + 1}",
                "Запрос принят в интерфейсе NEXO AI. Подключение защищённого серверного AI Gateway запланировано на Этапе 8.",
                false,
                "Сейчас"
            )
            state.copy(aiMessages = state.aiMessages + userMsg + botMsg)
        }
    }

    fun toggleBiometric(enabled: Boolean) {
        _uiState.update { it.copy(biometricEnabled = enabled) }
    }

    fun togglePin(enabled: Boolean) {
        _uiState.update { it.copy(pinEnabled = enabled) }
    }

    fun toggleLocationSharing(enabled: Boolean) {
        _uiState.update { it.copy(locationSharingEnabled = enabled) }
    }

    fun showInfoDialog(title: String, body: String) {
        _uiState.update { it.copy(infoDialogTitle = title, infoDialogBody = body) }
    }

    fun dismissInfoDialog() {
        _uiState.update { it.copy(infoDialogTitle = null, infoDialogBody = null) }
    }

    private fun createBaseState(): NexoUiState {
        return NexoUiState(
            events = listOf(
                FamilyEvent("e1", "Семейный ужин", "Воскресенье, 29 ноя", "15:00", "Дом родителей", "Семья", 1, true)
            ),
            shoppingList = listOf(
                ShoppingItem("s1", "Молоко и творог", "Молочное", false),
                ShoppingItem("s2", "Фрукты к ужину", "Фрукты", false)
            ),
            tasks = listOf(
                FamilyTask("t1", "Пригласить участников семьи", "Владелец", "Этап 3", false)
            ),
            albums = listOf(
                GalleryAlbum("g1", "Семейные встречи", 0, "2026", "Вся семья", true, false)
            ),
            aiTools = listOf(
                AiTool("ai1", "Сводка переписки", "Кратко о главном за день", "Сделай краткую сводку обсуждения"),
                AiTool("ai2", "Список покупок", "Собрать и сгруппировать", "Составь список продуктов для семейного ужина"),
                AiTool("ai3", "Планировщик", "Поездки и праздники", "Помоги спланировать семейную поездку")
            ),
            aiMessages = listOf(
                AiChatItem(
                    "ai_welcome",
                    "Привет! Я NEXO AI — встроенный помощник вашей семьи. Серверный AI Gateway будет подключён на Этапе 8.",
                    false,
                    "Сегодня"
                )
            )
        )
    }
}
