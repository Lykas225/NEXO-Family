package com.nexo.family.data

import android.content.Context
import com.nexo.family.BuildConfig

data class StoredSession(
    val accessToken: String,
    val refreshToken: String,
    val userId: String,
    val email: String
)

data class ServerConfig(
    val url: String,
    val anonKey: String
) {
    val isConfigured: Boolean
        get() = url.startsWith("https://") && anonKey.length >= 20
}

class SessionStorage(context: Context) {
    private val prefs = context.getSharedPreferences("nexo_family_session_v1", Context.MODE_PRIVATE)

    fun saveServerConfig(url: String, anonKey: String) {
        val cleanUrl = url.trim().trimEnd('/')
        val cleanKey = anonKey.trim()
        prefs.edit()
            .putString(KEY_SUPABASE_URL, cleanUrl)
            .putString(KEY_SUPABASE_ANON_KEY, cleanKey)
            .apply()
    }

    fun getServerConfig(): ServerConfig {
        val savedUrl = prefs.getString(KEY_SUPABASE_URL, "")?.trim().orEmpty()
        val savedKey = prefs.getString(KEY_SUPABASE_ANON_KEY, "")?.trim().orEmpty()
        val finalUrl = if (savedUrl.isNotEmpty()) savedUrl else BuildConfig.SUPABASE_URL.trim().trimEnd('/')
        val finalKey = if (savedKey.isNotEmpty()) savedKey else BuildConfig.SUPABASE_ANON_KEY.trim()
        return ServerConfig(finalUrl, finalKey)
    }

    fun saveSession(session: StoredSession) {
        prefs.edit()
            .putString(KEY_ACCESS_TOKEN, session.accessToken)
            .putString(KEY_REFRESH_TOKEN, session.refreshToken)
            .putString(KEY_USER_ID, session.userId)
            .putString(KEY_USER_EMAIL, session.email)
            .apply()
    }

    fun getSession(): StoredSession? {
        val access = prefs.getString(KEY_ACCESS_TOKEN, null) ?: return null
        val refresh = prefs.getString(KEY_REFRESH_TOKEN, null) ?: return null
        val userId = prefs.getString(KEY_USER_ID, null) ?: return null
        val email = prefs.getString(KEY_USER_EMAIL, "") ?: ""
        return StoredSession(access, refresh, userId, email)
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_ACCESS_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_USER_ID)
            .remove(KEY_USER_EMAIL)
            .apply()
    }

    companion object {
        private const val KEY_SUPABASE_URL = "supabase_url"
        private const val KEY_SUPABASE_ANON_KEY = "supabase_anon_key"
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_EMAIL = "user_email"
    }
}
