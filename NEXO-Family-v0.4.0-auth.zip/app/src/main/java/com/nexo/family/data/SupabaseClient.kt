package com.nexo.family.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String, val code: Int = 0) : ApiResult<Nothing>()
}

data class AuthOutcome(
    val session: StoredSession?,
    val requiresEmailConfirmation: Boolean = false
)

data class RemoteFamilyMember(
    val userId: String,
    val displayName: String,
    val role: String,
    val joinedAt: String
)

data class RemoteChat(
    val id: String,
    val title: String,
    val kind: String
)

data class RemoteFamilyBundle(
    val familyId: String,
    val familyName: String,
    val memberLimit: Int,
    val myDisplayName: String,
    val myRole: String,
    val members: List<RemoteFamilyMember>,
    val chats: List<RemoteChat>
)

class SupabaseClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun signUp(config: ServerConfig, email: String, password: String): ApiResult<AuthOutcome> =
        withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject()
                    .put("email", email.trim())
                    .put("password", password)
                val req = Request.Builder()
                    .url("${config.url}/auth/v1/signup")
                    .addHeader("apikey", config.anonKey)
                    .addHeader("Content-Type", "application/json")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                http.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext ApiResult.Error(parseError(raw, "Ошибка регистрации (${resp.code})"), resp.code)
                    }
                    val obj = JSONObject(raw)
                    val accessToken = obj.optString("access_token", "")
                    val refreshToken = obj.optString("refresh_token", "")
                    val userObj = obj.optJSONObject("user")
                    val userId = userObj?.optString("id", "").orEmpty()
                    val userEmail = userObj?.optString("email", email).orEmpty()

                    if (accessToken.isNotEmpty() && refreshToken.isNotEmpty() && userId.isNotEmpty()) {
                        ApiResult.Success(
                            AuthOutcome(
                                session = StoredSession(accessToken, refreshToken, userId, userEmail),
                                requiresEmailConfirmation = false
                            )
                        )
                    } else {
                        ApiResult.Success(
                            AuthOutcome(session = null, requiresEmailConfirmation = true)
                        )
                    }
                }
            } catch (e: Exception) {
                ApiResult.Error("Нет связи с сервером: ${e.localizedMessage ?: "ошибка сети"}")
            }
        }

    suspend fun signIn(config: ServerConfig, email: String, password: String): ApiResult<StoredSession> =
        withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject()
                    .put("email", email.trim())
                    .put("password", password)
                val req = Request.Builder()
                    .url("${config.url}/auth/v1/token?grant_type=password")
                    .addHeader("apikey", config.anonKey)
                    .addHeader("Content-Type", "application/json")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                http.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext ApiResult.Error(parseError(raw, "Неверный email или пароль"), resp.code)
                    }
                    parseSessionResponse(raw, email)
                }
            } catch (e: Exception) {
                ApiResult.Error("Нет связи с сервером: ${e.localizedMessage ?: "ошибка сети"}")
            }
        }

    suspend fun refreshSession(config: ServerConfig, refreshToken: String): ApiResult<StoredSession> =
        withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject().put("refresh_token", refreshToken)
                val req = Request.Builder()
                    .url("${config.url}/auth/v1/token?grant_type=refresh_token")
                    .addHeader("apikey", config.anonKey)
                    .addHeader("Content-Type", "application/json")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                http.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext ApiResult.Error(parseError(raw, "Сессия истекла"), resp.code)
                    }
                    parseSessionResponse(raw, "")
                }
            } catch (e: Exception) {
                ApiResult.Error("Ошибка сети при проверке сессии: ${e.localizedMessage ?: "нет связи"}")
            }
        }

    suspend fun signOut(config: ServerConfig, accessToken: String) = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("${config.url}/auth/v1/logout")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().close()
        } catch (_: Exception) {
            // Local session will still be cleared
        }
    }

    suspend fun createFamily(
        config: ServerConfig,
        accessToken: String,
        displayName: String,
        familyName: String
    ): ApiResult<String> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject()
                .put("displayName", displayName.trim())
                .put("familyName", familyName.trim())

            val req = Request.Builder()
                .url("${config.url}/functions/v1/create-family")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    val friendly = when (resp.code) {
                        409 -> "Этот аккаунт уже владеет семейной группой."
                        401 -> "Сессия истекла. Войдите в аккаунт заново."
                        400 -> parseError(raw, "Проверьте имя и название семьи.")
                        else -> parseError(raw, "Не удалось создать семью (${resp.code})")
                    }
                    return@withContext ApiResult.Error(friendly, resp.code)
                }
                val obj = JSONObject(raw)
                val familyId = obj.optString("familyId", "")
                if (familyId.isEmpty()) {
                    ApiResult.Error("Сервер не вернул идентификатор семьи")
                } else {
                    ApiResult.Success(familyId)
                }
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети при создании семьи: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun fetchMyFamilyBundle(
        config: ServerConfig,
        session: StoredSession
    ): ApiResult<RemoteFamilyBundle?> = withContext(Dispatchers.IO) {
        try {
            // 1. Check current user's membership
            val membershipUrl =
                "${config.url}/rest/v1/family_members?select=family_id,display_name,role,joined_at&user_id=eq.${session.userId}&limit=1"
            val memReq = Request.Builder()
                .url(membershipUrl)
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer ${session.accessToken}")
                .get()
                .build()

            val membershipArray = http.newCall(memReq).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Ошибка загрузки профиля (${resp.code})"), resp.code)
                }
                JSONArray(raw)
            }

            if (membershipArray.length() == 0) {
                return@withContext ApiResult.Success(null)
            }

            val myRow = membershipArray.getJSONObject(0)
            val familyId = myRow.getString("family_id")
            val myDisplayName = myRow.optString("display_name", "Участник")
            val myRole = myRow.optString("role", "member")

            // 2. Fetch family details
            val familyReq = Request.Builder()
                .url("${config.url}/rest/v1/families?select=id,name,member_limit&id=eq.$familyId&limit=1")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer ${session.accessToken}")
                .get()
                .build()

            var familyName = "NEXO Family"
            var memberLimit = 20
            http.newCall(familyReq).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val arr = JSONArray(raw)
                    if (arr.length() > 0) {
                        val f = arr.getJSONObject(0)
                        familyName = f.optString("name", "NEXO Family")
                        memberLimit = f.optInt("member_limit", 20)
                    }
                }
            }

            // 3. Fetch all family members
            val allMembersReq = Request.Builder()
                .url("${config.url}/rest/v1/family_members?select=user_id,display_name,role,joined_at&family_id=eq.$familyId&order=joined_at.asc")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer ${session.accessToken}")
                .get()
                .build()

            val members = mutableListOf<RemoteFamilyMember>()
            http.newCall(allMembersReq).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        members.add(
                            RemoteFamilyMember(
                                userId = obj.optString("user_id", ""),
                                displayName = obj.optString("display_name", "Участник"),
                                role = obj.optString("role", "member"),
                                joinedAt = obj.optString("joined_at", "").take(10)
                            )
                        )
                    }
                }
            }

            // 4. Fetch visible chats
            val chatsReq = Request.Builder()
                .url("${config.url}/rest/v1/chats?select=id,title,kind&family_id=eq.$familyId&order=created_at.asc")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer ${session.accessToken}")
                .get()
                .build()

            val chats = mutableListOf<RemoteChat>()
            http.newCall(chatsReq).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        chats.add(
                            RemoteChat(
                                id = obj.optString("id", ""),
                                title = obj.optString("title", "Чат"),
                                kind = obj.optString("kind", "family")
                            )
                        )
                    }
                }
            }

            ApiResult.Success(
                RemoteFamilyBundle(
                    familyId = familyId,
                    familyName = familyName,
                    memberLimit = memberLimit,
                    myDisplayName = myDisplayName,
                    myRole = myRole,
                    members = members,
                    chats = chats
                )
            )
        } catch (e: Exception) {
            ApiResult.Error("Ошибка загрузки семьи: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    private fun parseSessionResponse(raw: String, fallbackEmail: String): ApiResult<StoredSession> {
        val obj = JSONObject(raw)
        val accessToken = obj.optString("access_token", "")
        val refreshToken = obj.optString("refresh_token", "")
        val userObj = obj.optJSONObject("user")
        val userId = userObj?.optString("id", "").orEmpty()
        val email = userObj?.optString("email", fallbackEmail).orEmpty()
        return if (accessToken.isNotEmpty() && refreshToken.isNotEmpty() && userId.isNotEmpty()) {
            ApiResult.Success(StoredSession(accessToken, refreshToken, userId, email))
        } else {
            ApiResult.Error("Сервер вернул неполную сессию")
        }
    }

    private fun parseError(raw: String, fallback: String): String {
        return try {
            val obj = JSONObject(raw)
            obj.optString("msg")
                .ifEmpty { obj.optString("error_description") }
                .ifEmpty { obj.optString("error") }
                .ifEmpty { obj.optString("message") }
                .ifEmpty { fallback }
        } catch (_: Exception) {
            fallback
        }
    }
}
