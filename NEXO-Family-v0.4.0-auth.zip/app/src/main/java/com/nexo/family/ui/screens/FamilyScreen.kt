package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.FamilyMember
import com.nexo.family.model.MemberRole
import com.nexo.family.ui.components.NexoAvatar
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

@Composable
fun FamilyScreen(
    familyName: String,
    members: List<FamilyMember>,
    memberLimit: Int,
    freeSlots: Int,
    onCreateInviteClick: () -> Unit,
    onManageRolesClick: () -> Unit
) {
    val progress = (members.size.toFloat() / memberLimit.coerceAtLeast(1)).coerceIn(0f, 1f)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Family Hero Card
        item {
            NexoCard(
                borderColor = NexoColors.Turquoise.copy(alpha = 0.4f)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(NexoColors.Turquoise, NexoColors.Purple)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Groups, contentDescription = null, tint = NexoColors.DeepNavy, modifier = Modifier.size(32.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(familyName, color = NexoColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp))
                            Text("Закрытая семейная группа", color = NexoColors.TextSecondary, fontSize = 13.sp)
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Участников: ${members.size} из $memberLimit",
                            color = NexoColors.TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Свободно мест: $freeSlots",
                            color = NexoColors.SuccessGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(6.dp)),
                        color = NexoColors.Turquoise,
                        trackColor = NexoColors.GraphiteElevated
                    )

                    Spacer(Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onCreateInviteClick,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NexoColors.Turquoise,
                                contentColor = NexoColors.DeepNavy
                            )
                        ) {
                            Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Пригласить", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onManageRolesClick,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NexoColors.TextPrimary)
                        ) {
                            Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = NexoColors.Purple, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Роли")
                        }
                    }
                }
            }
        }

        item {
            SectionLabel("Участники семьи", "${members.size} / $memberLimit")
        }

        items(members, key = { it.id }) { member ->
            NexoCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NexoAvatar(
                        initials = member.initials,
                        accentColor = member.avatarColor,
                        size = 52.dp,
                        isOnline = member.isOnline
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = member.name,
                                color = NexoColors.TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            RoleBadge(role = member.role)
                        }
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = member.status,
                            color = if (member.isOnline) NexoColors.SuccessGreen else NexoColors.TextSecondary,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "В группе с ${member.joinedDate}",
                            color = NexoColors.TextSecondary.copy(alpha = 0.8f),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RoleBadge(role: MemberRole) {
    val (bg, fg) = when (role) {
        MemberRole.OWNER -> NexoColors.TurquoiseDim to NexoColors.Turquoise
        MemberRole.ADMIN -> NexoColors.PurpleDim to NexoColors.Purple
        MemberRole.MEMBER -> NexoColors.GraphiteElevated to NexoColors.TextSecondary
    }
    Surface(color = bg, shape = RoundedCornerShape(8.dp)) {
        Text(
            text = role.label,
            color = fg,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
        )
    }
}
