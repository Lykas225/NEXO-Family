import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

function buildSmartFamilyReply(prompt: string, context: Record<string, unknown>): string {
  const lower = prompt.toLowerCase();
  const events = Array.isArray(context.events) ? context.events : [];
  const shopping = Array.isArray(context.shopping) ? context.shopping : [];
  const tasks = Array.isArray(context.tasks) ? context.tasks : [];

  if (lower.includes("покуп") || lower.includes("продукт") || lower.includes("ужин")) {
    const activeShop = shopping
      .filter((s: any) => s && !s.isBought)
      .map((s: any) => s.title);
    if (activeShop.length > 0) {
      return `Сейчас в вашем списке покупок (${activeShop.length}): ${activeShop.join(", ")}.\n\nМогу предложить добавить к ужину: хлеб, зелень, воду или десерт — напишите, что именно внести.`;
    }
    return "Список покупок сейчас пуст. Для семейного ужина отлично подойдут: мясо или рыба, овощи для салата, гарнир, хлеб, напитки и фрукты.";
  }

  if (lower.includes("задач") || lower.includes("дел") || lower.includes("план") || lower.includes("поездк")) {
    const openTasks = tasks
      .filter((t: any) => t && !t.isDone)
      .map((t: any) => `${t.title} (${t.assignee || "Семья"})`);
    const evList = events
      .slice(0, 3)
      .map((e: any) => `${e.title} — ${e.dateLabel}, ${e.timeLabel}`);
    const parts: string[] = [];
    if (evList.length > 0) {
      parts.push(`Ближайшие события:\n• ${evList.join("\n• ")}`);
    }
    if (openTasks.length > 0) {
      parts.push(`Открытые задачи:\n• ${openTasks.join("\n• ")}`);
    }
    if (parts.length === 0) {
      parts.push("Пока нет запланированных событий и открытых задач. Хотите составить чек-лист поездки или выходных?");
    }
    return parts.join("\n\n");
  }

  return `Принял запрос: «${prompt}».\n\nЯ вижу ваши семейные списки (событий: ${events.length}, покупок: ${shopping.length}, задач: ${tasks.length}). Подскажите, нужно собрать список покупок, распределить задачи или набросать план мероприятия?`;
}

Deno.serve(async (request: Request): Promise<Response> => {
  if (request.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }

  const authorization = request.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) {
    return jsonResponse({ error: "Authentication required" }, 401);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const publicKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  if (!supabaseUrl || !publicKey) {
    return jsonResponse({ error: "Server configuration error" }, 500);
  }

  let body: Record<string, unknown>;
  try {
    const parsed = await request.json();
    body = typeof parsed === "object" && parsed !== null ? parsed as Record<string, unknown> : {};
  } catch {
    return jsonResponse({ error: "Invalid JSON body" }, 400);
  }

  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  if (!prompt) {
    return jsonResponse({ error: "Empty prompt" }, 400);
  }

  const context = typeof body.context === "object" && body.context !== null
    ? body.context as Record<string, unknown>
    : {};

  const accessToken = authorization.slice("Bearer ".length);
  const supabase = createClient(supabaseUrl, publicKey, {
    global: { headers: { Authorization: authorization } },
    auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
  });

  const { data: userData, error: authError } = await supabase.auth.getUser(accessToken);
  if (authError || !userData.user) {
    return jsonResponse({ error: "Invalid session" }, 401);
  }

  const openAiKey = Deno.env.get("OPENAI_API_KEY");
  const geminiKey = Deno.env.get("GEMINI_API_KEY");

  try {
    if (openAiKey) {
      const resp = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${openAiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: "Ты NEXO AI — бережный и практичный семейный помощник на русском языке. Отвечай кратко, по делу и помогай с планами, покупками и задачами.",
            },
            {
              role: "user",
              content: `Контекст семьи: ${JSON.stringify(context)}\nЗапрос: ${prompt}`,
            },
          ],
          temperature: 0.6,
          max_tokens: 500,
        }),
      });
      if (resp.ok) {
        const data = await resp.json();
        const reply = data?.choices?.[0]?.message?.content?.trim();
        if (reply) return jsonResponse({ reply }, 200);
      }
    }

    if (geminiKey) {
      const resp = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${geminiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `Ты NEXO AI — семейный помощник на русском языке. Отвечай кратко и по делу.\nКонтекст семьи: ${JSON.stringify(context)}\nЗапрос: ${prompt}`,
                  },
                ],
              },
            ],
          }),
        },
      );
      if (resp.ok) {
        const data = await resp.json();
        const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
        if (reply) return jsonResponse({ reply }, 200);
      }
    }
  } catch (_e) {
    // Fallback below
  }

  return jsonResponse({ reply: buildSmartFamilyReply(prompt, context) }, 200);
});
