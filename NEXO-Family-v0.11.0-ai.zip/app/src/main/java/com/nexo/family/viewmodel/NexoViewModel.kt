package com.nexo.family.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexo.family.data.*
import com.nexo.family.model.*
import com.nexo.family.ui.theme.NexoColors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class NexoViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = SessionStorage(application)
    private val client = SupabaseClient()
    val voiceHelper = VoiceMediaHelper(application)
    private val notificationHelper = NotificationHelper(application)
    private val lastSeenChatTimes = mutableMapOf<String, String>()
    private val notifiedCallIds = mutableSetOf<String>()
    private val loadingMediaPaths = mutableSetOf<String>()
    private val loadingGalleryPaths = mutableSetOf<String>()
    private var chatPollingJob: Job? = null
    private var listPollingJob: Job? = null

    private val _uiState = MutableStateFlow(createBaseState())
    val uiState: StateFlow<NexoUiState> = _uiState.asStateFlow()

    init {
        restoreSessionOnStart()
    }

    override fun onCleared() {
        super.onCleared()
        voiceHelper.releaseAll()
    }

    private fun restoreSessionOnStart() {
        val config = storage.getServerConfig()
        val bioOn = storage.isBiometricEnabled()
        val pinOn = storage.isPinEnabled()
        val hasSavedSession = storage.getSession() != null
        _uiState.update {
            it.copy(
                supabaseUrl = config.url,
                supabaseAnonKey = config.anonKey,
                isServerConfigured = config.isConfigured,
                biometricEnabled = bioOn,
                pinEnabled = pinOn,
                isAppLocked = hasSavedSession && (bioOn || pinOn)
            )
        }

        val saved = storage.getSession()
        if (!config.isConfigured || saved == null) {
            _uiState.update { it.copy(gate = AppGate.AUTH) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(gate = AppGate.CHECKING_SESSION, isLoading = true) }
            when (val refreshed = client.refreshSession(config, saved.refreshToken)) {
                is ApiResult.Success -> {
                    storage.saveSession(refreshed.data)
                    loadFamilyAndRoute(config, refreshed.data)
                }
                is ApiResult.Error -> {
                    storage.clearSession()
                    _uiState.update {
                        it.copy(
                            gate = AppGate.AUTH,
                            isLoading = false,
                            authNotice = "Сессия завершена. Войдите снова."
                        )
                    }
                }
            }
        }
    }

    fun saveServerConfig(url: String, anonKey: String) {
        storage.saveServerConfig(url, anonKey)
        val updated = storage.getServerConfig()
        _uiState.update {
            it.copy(
                supabaseUrl = updated.url,
                supabaseAnonKey = updated.anonKey,
                isServerConfigured = updated.isConfigured,
                authError = if (updated.isConfigured) null else "Проверьте формат URL (https://...) и публичный ключ.",
                authNotice = if (updated.isConfigured) "Параметры сервера сохранены." else null
            )
        }
    }

    fun signIn(email: String, password: String) {
        val config = storage.getServerConfig()
        if (!config.isConfigured) {
            _uiState.update { it.copy(authError = "Сначала укажите Project URL и Anon Key в настройках Supabase.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null, authNotice = null) }
            when (val res = client.signIn(config, email, password)) {
                is ApiResult.Success -> {
                    storage.saveSession(res.data)
                    loadFamilyAndRoute(config, res.data)
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, authError = res.message) }
                }
            }
        }
    }

    fun signUp(email: String, password: String) {
        val config = storage.getServerConfig()
        if (!config.isConfigured) {
            _uiState.update { it.copy(authError = "Сначала укажите Project URL и Anon Key в настройках Supabase.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null, authNotice = null) }
            when (val res = client.signUp(config, email, password)) {
                is ApiResult.Success -> {
                    val outcome = res.data
                    if (outcome.session != null) {
                        storage.saveSession(outcome.session)
                        loadFamilyAndRoute(config, outcome.session)
                    } else {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                authNotice = "Аккаунт создан! Подтвердите email по ссылке из письма и нажмите «Войти»."
                            )
                        }
                    }
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, authError = res.message) }
                }
            }
        }
    }

    fun createFamily(displayName: String, familyName: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession()
        if (!config.isConfigured || session == null) {
            _uiState.update { it.copy(gate = AppGate.AUTH, authError = "Требуется вход в аккаунт.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null) }
            when (val res = client.createFamily(config, session.accessToken, displayName, familyName)) {
                is ApiResult.Success -> loadFamilyAndRoute(config, session)
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, authError = res.message) }
            }
        }
    }

    fun redeemInvite(code: String, displayName: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession()
        if (!config.isConfigured || session == null) {
            _uiState.update { it.copy(gate = AppGate.AUTH, authError = "Требуется вход в аккаунт.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null) }
            when (val res = client.redeemInvite(config, session.accessToken, code, displayName)) {
                is ApiResult.Success -> loadFamilyAndRoute(config, session)
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, authError = res.message) }
            }
        }
    }

    fun openInviteDialog() {
        _uiState.update { it.copy(showInviteDialog = true) }
        loadInvitesFromServer()
    }

    fun closeInviteDialog() {
        _uiState.update { it.copy(showInviteDialog = false, lastGeneratedInviteCode = null) }
    }

    fun generateOneTimeInvite(expiresHours: Int = 24) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val res = client.createInvite(config, session.accessToken, expiresHours)) {
                is ApiResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            lastGeneratedInviteCode = res.data.code
                        )
                    }
                    loadInvitesFromServer()
                }
                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            infoDialogTitle = "Не удалось создать приглашение",
                            infoDialogBody = res.message
                        )
                    }
                }
            }
        }
    }

    fun revokeInvite(inviteId: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            when (val res = client.revokeInvite(config, session.accessToken, inviteId)) {
                is ApiResult.Success -> loadInvitesFromServer()
                is ApiResult.Error -> showInfoDialog("Ошибка", res.message)
            }
        }
    }

    fun toggleMemberAdminRole(member: FamilyMember) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val targetRole = if (member.role == MemberRole.ADMIN) "member" else "admin"
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val res = client.updateMemberRole(config, session.accessToken, member.id, targetRole)) {
                is ApiResult.Success -> loadFamilyAndRoute(config, session)
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false) }
                    showInfoDialog("Изменение роли", res.message)
                }
            }
        }
    }

    fun removeFamilyMember(member: FamilyMember) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val res = client.removeMember(config, session.accessToken, member.id)) {
                is ApiResult.Success -> loadFamilyAndRoute(config, session)
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false) }
                    showInfoDialog("Удаление участника", res.message)
                }
            }
        }
    }

    private fun loadInvitesFromServer() {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            when (val res = client.listInvites(config, session.accessToken)) {
                is ApiResult.Success -> {
                    val mapped = res.data.map {
                        FamilyInvite(
                            id = it.id,
                            expiresAt = it.expiresAt,
                            uses = it.uses,
                            maxUses = it.maxUses,
                            revokedAt = it.revokedAt,
                            createdAt = it.createdAt
                        )
                    }
                    _uiState.update { it.copy(invites = mapped) }
                }
                is ApiResult.Error -> Unit
            }
        }
    }

    fun refreshFamilyFromServer() {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null) }
            loadFamilyAndRoute(config, session)
        }
    }

    fun signOut() {
        chatPollingJob?.cancel()
        listPollingJob?.cancel()
        val config = storage.getServerConfig()
        val session = storage.getSession()
        viewModelScope.launch {
            if (config.isConfigured && session != null) {
                client.signOut(config, session.accessToken)
            }
            storage.clearSession()
            _uiState.update {
                createBaseState().copy(
                    gate = AppGate.AUTH,
                    supabaseUrl = config.url,
                    supabaseAnonKey = config.anonKey,
                    isServerConfigured = config.isConfigured,
                    authNotice = "Вы вышли из аккаунта."
                )
            }
        }
    }

    private suspend fun loadFamilyAndRoute(config: ServerConfig, session: StoredSession) {
        when (val bundleRes = client.fetchMyFamilyBundle(config, session)) {
            is ApiResult.Success -> {
                val bundle = bundleRes.data
                if (bundle == null) {
                    _uiState.update {
                        it.copy(
                            gate = AppGate.CREATE_FAMILY,
                            isLoading = false,
                            currentUserId = session.userId,
                            currentUserEmail = session.email,
                            authError = null
                        )
                    }
                } else {
                    val palette = listOf(
                        NexoColors.Turquoise,
                        NexoColors.Purple,
                        Color(0xFF38BDF8),
                        Color(0xFFA78BFA),
                        Color(0xFF34D399)
                    )
                    val uiMembers = bundle.members.mapIndexed { idx, m ->
                        val role = when (m.role) {
                            "owner" -> MemberRole.OWNER
                            "admin" -> MemberRole.ADMIN
                            else -> MemberRole.MEMBER
                        }
                        val isMe = m.userId == session.userId
                        FamilyMember(
                            id = m.userId,
                            name = if (isMe) "${m.displayName} (Вы)" else m.displayName,
                            role = role,
                            isOnline = isMe,
                            status = if (isMe) "В сети" else "Участник семьи",
                            joinedDate = m.joinedAt.ifEmpty { "Сегодня" },
                            initials = m.displayName.trim().take(2).uppercase().ifEmpty { "Н" },
                            avatarColor = palette[idx % palette.size],
                            isCurrentUser = isMe
                        )
                    }
                    val previewChats = when (val pRes = client.listMyChatsWithPreview(config, session.accessToken)) {
                        is ApiResult.Success -> pRes.data
                        is ApiResult.Error -> bundle.chats
                    }
                    val uiChats = mapRemoteChats(previewChats, palette)
                    val myRoleEnum = when (bundle.myRole) {
                        "owner" -> MemberRole.OWNER
                        "admin" -> MemberRole.ADMIN
                        else -> MemberRole.MEMBER
                    }
                    _uiState.update {
                        it.copy(
                            gate = AppGate.MAIN,
                            isLoading = false,
                            authError = null,
                            currentUserId = session.userId,
                            currentUserEmail = session.email,
                            currentUserDisplayName = bundle.myDisplayName,
                            currentUserRole = myRoleEnum,
                            familyId = bundle.familyId,
                            familyName = bundle.familyName,
                            memberLimit = bundle.memberLimit,
                            members = uiMembers,
                            chats = uiChats
                        )
                    }
                    if (myRoleEnum == MemberRole.OWNER || myRoleEnum == MemberRole.ADMIN) {
                        loadInvitesFromServer()
                    }
                    startChatListPolling()
                    refreshFamilyHubData()
                }
            }
            is ApiResult.Error -> {
                _uiState.update {
                    it.copy(
                        gate = AppGate.CREATE_FAMILY,
                        isLoading = false,
                        currentUserId = session.userId,
                        currentUserEmail = session.email,
                        authError = bundleRes.message
                    )
                }
            }
        }
    }

    fun selectTab(tab: NexoTab) {
        _uiState.update { it.copy(currentTab = tab, showProfile = false, selectedChatId = null) }
        if (tab == NexoTab.EVENTS || tab == NexoTab.GALLERY) {
            refreshFamilyHubData()
        }
    }

    fun openProfile() {
        _uiState.update { it.copy(showProfile = true, selectedChatId = null) }
    }

    fun closeProfile() {
        _uiState.update { it.copy(showProfile = false) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun openChat(chatId: String) {
        _uiState.update { state ->
            val updatedChats = state.chats.map { chat ->
                if (chat.id == chatId) chat.copy(unreadCount = 0, hasMissedCall = false) else chat
            }
            state.copy(selectedChatId = chatId, chats = updatedChats)
        }
        startChatPolling(chatId)
    }

    fun closeChat() {
        chatPollingJob?.cancel()
        _uiState.update { it.copy(selectedChatId = null) }
        refreshChatsOnly()
    }

    fun startDirectChat(member: FamilyMember) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val res = client.getOrCreateDirectChat(config, session.accessToken, member.id)) {
                is ApiResult.Success -> {
                    val chatId = res.data
                    refreshChatsOnlySuspend(config, session)
                    _uiState.update { it.copy(isLoading = false, currentTab = NexoTab.CHATS) }
                    openChat(chatId)
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false) }
                    showInfoDialog("Личный чат", res.message)
                }
            }
        }
    }

    fun sendMessage(chatId: String, rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return

        // Optimistic UI append
        _uiState.update { state ->
            val currentList = state.messagesByChat[chatId].orEmpty()
            val optimistic = ChatMessage(
                id = "temp_${System.currentTimeMillis()}",
                chatId = chatId,
                senderName = state.currentUserDisplayName,
                text = text,
                time = "Отправка…",
                isMine = true,
                isRead = false
            )
            val updatedMap = state.messagesByChat.toMutableMap().apply {
                put(chatId, currentList + optimistic)
            }
            val updatedChats = state.chats.map { chat ->
                if (chat.id == chatId) chat.copy(lastMessage = text, time = "Сейчас") else chat
            }
            state.copy(messagesByChat = updatedMap, chats = updatedChats)
        }

        viewModelScope.launch {
            val encryptedText = CryptoHelper.encryptText(_uiState.value.familyId, text)
            when (val res = client.sendChatMessage(config, session.accessToken, chatId, session.userId, encryptedText)) {
                is ApiResult.Success -> {
                    loadMessagesOnce(config, session, chatId)
                    refreshChatsOnlySuspend(config, session)
                }
                is ApiResult.Error -> {
                    showInfoDialog("Ошибка отправки", res.message)
                    loadMessagesOnce(config, session, chatId)
                }
            }
        }
    }

    private fun startChatPolling(chatId: String) {
        chatPollingJob?.cancel()
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        chatPollingJob = viewModelScope.launch {
            while (isActive) {
                loadMessagesOnce(config, session, chatId)
                delay(3000)
            }
        }
    }

    private fun startChatListPolling() {
        listPollingJob?.cancel()
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        listPollingJob = viewModelScope.launch {
            while (isActive) {
                delay(8000)
                if (_uiState.value.gate == AppGate.MAIN) {
                    if (_uiState.value.selectedChatId == null) {
                        refreshChatsOnlySuspend(config, session)
                    }
                    checkActiveCallsSuspend(config, session)
                }
            }
        }
    }

    private suspend fun loadMessagesOnce(config: ServerConfig, session: StoredSession, chatId: String) {
        when (val res = client.listChatMessages(config, session.accessToken, chatId)) {
            is ApiResult.Success -> {
                val uiMsgs = res.data.map { m ->
                    val kind = when (m.messageType) {
                        "photo" -> MessageKind.PHOTO
                        "voice" -> MessageKind.VOICE
                        "file" -> MessageKind.FILE
                        else -> MessageKind.TEXT
                    }
                    val decryptedPayload = CryptoHelper.decryptText(_uiState.value.familyId, m.ciphertext)
                    var displayText = decryptedPayload
                    var mediaPath: String? = null
                    var mediaName: String? = null
                    var mediaMime: String? = null
                    var voiceDuration: String? = null

                    if (kind != MessageKind.TEXT) {
                        try {
                            val json = JSONObject(decryptedPayload)
                            mediaPath = json.optString("path", "").ifEmpty { null }
                            mediaName = json.optString("name", "").ifEmpty { null }
                            mediaMime = json.optString("mime", "").ifEmpty { null }
                            voiceDuration = json.optString("duration", "").ifEmpty { null }
                            displayText = mediaName ?: when (kind) {
                                MessageKind.PHOTO -> "Фото"
                                MessageKind.VOICE -> "Голосовое сообщение"
                                MessageKind.FILE -> "Файл"
                                else -> ""
                            }
                        } catch (_: Exception) {
                        }
                    }

                    ChatMessage(
                        id = m.id,
                        chatId = m.chatId,
                        senderName = m.senderName,
                        text = displayText,
                        time = formatShortTime(m.createdAt),
                        isMine = m.senderId == session.userId,
                        isRead = true,
                        kind = kind,
                        voiceDuration = voiceDuration,
                        mediaPath = mediaPath,
                        mediaName = mediaName,
                        mediaMime = mediaMime
                    )
                }
                _uiState.update { state ->
                    val updatedMap = state.messagesByChat.toMutableMap().apply {
                        put(chatId, uiMsgs)
                    }
                    state.copy(messagesByChat = updatedMap)
                }
                // Pre-download photos that aren't cached yet
                uiMsgs.filter { it.kind == MessageKind.PHOTO && !it.mediaPath.isNullOrBlank() }.forEach { msg ->
                    ensureMediaLoaded(msg.mediaPath!!)
                }
            }
            is ApiResult.Error -> Unit
        }
    }

    fun ensureMediaLoaded(path: String) {
        if (_uiState.value.mediaCache.containsKey(path) || loadingMediaPaths.contains(path)) return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        loadingMediaPaths.add(path)
        viewModelScope.launch {
            try {
                when (val res = client.downloadChatMedia(config, session.accessToken, path)) {
                    is ApiResult.Success -> {
                        _uiState.update { st ->
                            val newCache = st.mediaCache.toMutableMap().apply { put(path, res.data) }
                            st.copy(mediaCache = newCache)
                        }
                    }
                    is ApiResult.Error -> Unit
                }
            } finally {
                loadingMediaPaths.remove(path)
            }
        }
    }

    fun sendMediaFromUri(chatId: String, uri: Uri, isPhoto: Boolean) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val app = getApplication<Application>()
        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingMedia = true) }
            try {
                val resolver = app.contentResolver
                val mime = resolver.getType(uri) ?: if (isPhoto) "image/jpeg" else "application/octet-stream"
                var fileName = if (isPhoto) "photo.jpg" else "document.bin"
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0 && cursor.moveToFirst()) {
                        val queried = cursor.getString(nameIdx)
                        if (!queried.isNullOrBlank()) fileName = queried
                    }
                }
                val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null || bytes.isEmpty()) {
                    _uiState.update { it.copy(isUploadingMedia = false) }
                    showInfoDialog("Ошибка файла", "Не удалось прочитать выбранный файл.")
                    return@launch
                }
                if (bytes.size > 25 * 1024 * 1024) {
                    _uiState.update { it.copy(isUploadingMedia = false) }
                    showInfoDialog("Файл слишком большой", "Максимальный размер вложения — 25 МБ.")
                    return@launch
                }
                when (val up = client.uploadChatMedia(config, session.accessToken, chatId, fileName, mime, bytes)) {
                    is ApiResult.Success -> {
                        val objectPath = up.data
                        val meta = JSONObject()
                            .put("path", objectPath)
                            .put("name", fileName)
                            .put("mime", mime)
                            .toString()
                        val msgType = if (isPhoto) "photo" else "file"
                        if (isPhoto) {
                            _uiState.update { st ->
                                val newCache = st.mediaCache.toMutableMap().apply { put(objectPath, bytes) }
                                st.copy(mediaCache = newCache)
                            }
                        }
                        val encMeta = CryptoHelper.encryptText(_uiState.value.familyId, meta)
                        when (val sendRes = client.sendChatMessage(config, session.accessToken, chatId, session.userId, encMeta, msgType)) {
                            is ApiResult.Success -> {
                                loadMessagesOnce(config, session, chatId)
                                refreshChatsOnlySuspend(config, session)
                            }
                            is ApiResult.Error -> showInfoDialog("Ошибка отправки", sendRes.message)
                        }
                    }
                    is ApiResult.Error -> showInfoDialog("Ошибка загрузки", up.message)
                }
            } catch (e: Exception) {
                showInfoDialog("Ошибка", e.localizedMessage ?: "Не удалось отправить файл")
            } finally {
                _uiState.update { it.copy(isUploadingMedia = false) }
            }
        }
    }

    fun sendVoiceBytes(chatId: String, bytes: ByteArray, durationStr: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingMedia = true) }
            try {
                when (val up = client.uploadChatMedia(config, session.accessToken, chatId, "voice.m4a", "audio/mp4", bytes)) {
                    is ApiResult.Success -> {
                        val objectPath = up.data
                        val meta = JSONObject()
                            .put("path", objectPath)
                            .put("name", "voice.m4a")
                            .put("mime", "audio/mp4")
                            .put("duration", durationStr)
                            .toString()
                        _uiState.update { st ->
                            val newCache = st.mediaCache.toMutableMap().apply { put(objectPath, bytes) }
                            st.copy(mediaCache = newCache)
                        }
                        val encMeta = CryptoHelper.encryptText(_uiState.value.familyId, meta)
                        when (val sendRes = client.sendChatMessage(config, session.accessToken, chatId, session.userId, encMeta, "voice")) {
                            is ApiResult.Success -> {
                                loadMessagesOnce(config, session, chatId)
                                refreshChatsOnlySuspend(config, session)
                            }
                            is ApiResult.Error -> showInfoDialog("Ошибка отправки", sendRes.message)
                        }
                    }
                    is ApiResult.Error -> showInfoDialog("Ошибка загрузки голосового", up.message)
                }
            } finally {
                _uiState.update { it.copy(isUploadingMedia = false) }
            }
        }
    }

    fun toggleVoicePlayback(msg: ChatMessage) {
        val path = msg.mediaPath ?: return
        if (_uiState.value.playingVoiceId == msg.id) {
            voiceHelper.stopPlayback()
            _uiState.update { it.copy(playingVoiceId = null) }
            return
        }
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            val cached = _uiState.value.mediaCache[path]
            val bytes = cached ?: when (val res = client.downloadChatMedia(config, session.accessToken, path)) {
                is ApiResult.Success -> {
                    _uiState.update { st ->
                        val newCache = st.mediaCache.toMutableMap().apply { put(path, res.data) }
                        st.copy(mediaCache = newCache)
                    }
                    res.data
                }
                is ApiResult.Error -> {
                    showInfoDialog("Голосовое сообщение", res.message)
                    return@launch
                }
            }
            _uiState.update { it.copy(playingVoiceId = msg.id) }
            voiceHelper.playAudio(bytes, _uiState.value.voicePlaybackSpeed) {
                _uiState.update { it.copy(playingVoiceId = null) }
            }
        }
    }

    fun cycleVoiceSpeed() {
        val next = when (_uiState.value.voicePlaybackSpeed) {
            1.0f -> 1.5f
            1.5f -> 2.0f
            else -> 1.0f
        }
        _uiState.update { it.copy(voicePlaybackSpeed = next) }
        voiceHelper.setPlaybackSpeed(next)
    }

    fun openFileAttachment(msg: ChatMessage) {
        val path = msg.mediaPath ?: return
        val fileName = msg.mediaName ?: "file.bin"
        val mime = msg.mediaMime ?: "application/octet-stream"
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val app = getApplication<Application>()

        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingMedia = true) }
            try {
                val cached = _uiState.value.mediaCache[path]
                val bytes = cached ?: when (val res = client.downloadChatMedia(config, session.accessToken, path)) {
                    is ApiResult.Success -> {
                        _uiState.update { st ->
                            val newCache = st.mediaCache.toMutableMap().apply { put(path, res.data) }
                            st.copy(mediaCache = newCache)
                        }
                        res.data
                    }
                    is ApiResult.Error -> {
                        showInfoDialog("Ошибка скачивания", res.message)
                        return@launch
                    }
                }
                val safeName = fileName.replace(Regex("[^a-zA-Z0-9._ -]"), "_").ifEmpty { "attachment.bin" }
                val outFile = File(app.cacheDir, safeName)
                outFile.writeBytes(bytes)
                val contentUri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", outFile)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(contentUri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    app.startActivity(intent)
                } catch (_: Exception) {
                    showInfoDialog("Файл загружен", "Файл «$fileName» сохранён в кэш, но на телефоне нет приложения для его открытия.")
                }
            } finally {
                _uiState.update { it.copy(isUploadingMedia = false) }
            }
        }
    }

    private fun refreshChatsOnly() {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            refreshChatsOnlySuspend(config, session)
        }
    }

    private suspend fun refreshChatsOnlySuspend(config: ServerConfig, session: StoredSession) {
        when (val res = client.listMyChatsWithPreview(config, session.accessToken)) {
            is ApiResult.Success -> {
                val palette = listOf(
                    NexoColors.Turquoise,
                    NexoColors.Purple,
                    Color(0xFF38BDF8),
                    Color(0xFFA78BFA),
                    Color(0xFF34D399)
                )
                val uiChats = mapRemoteChats(res.data, palette)
                res.data.forEachIndexed { idx, remoteChat ->
                    val prevTime = lastSeenChatTimes[remoteChat.id]
                    if (prevTime != null && remoteChat.lastMessageAt.isNotEmpty() && remoteChat.lastMessageAt != prevTime) {
                        val previewText = uiChats.getOrNull(idx)?.lastMessage ?: "Новое сообщение"
                        notificationHelper.showMessageNotification(
                            chatTitle = remoteChat.title,
                            messagePreview = previewText,
                            notificationId = remoteChat.id.hashCode()
                        )
                    }
                    if (remoteChat.lastMessageAt.isNotEmpty()) {
                        lastSeenChatTimes[remoteChat.id] = remoteChat.lastMessageAt
                    }
                }
                _uiState.update { it.copy(chats = uiChats) }
            }
            is ApiResult.Error -> Unit
        }
    }

    private fun mapRemoteChats(chats: List<RemoteChat>, palette: List<Color>): List<ChatPreview> {
        val famId = _uiState.value.familyId
        return chats.mapIndexed { idx, c ->
            val isFam = c.kind == "family"
            val decryptedPreview = CryptoHelper.decryptText(famId, c.lastMessage)
            val preview = decryptedPreview.ifBlank {
                if (isFam) "Общий чат вашей семьи" else "Начните личную переписку"
            }
            ChatPreview(
                id = c.id,
                title = c.title,
                lastMessage = preview,
                time = formatShortTime(c.lastMessageAt).ifEmpty { "Сейчас" },
                unreadCount = 0,
                initials = if (isFam) "NF" else c.title.trim().take(2).uppercase().ifEmpty { "Ч" },
                accentColor = if (isFam) NexoColors.Turquoise else palette[(idx + 1) % palette.size],
                isFamilyChat = isFam,
                isPinned = isFam,
                isOnline = true
            )
        }
    }

    private fun formatShortTime(iso: String): String {
        val tIndex = iso.indexOf('T')
        if (tIndex != -1 && iso.length >= tIndex + 6) {
            return iso.substring(tIndex + 1, tIndex + 6)
        }
        return ""
    }

    fun refreshFamilyHubData() {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val famId = _uiState.value.familyId ?: return
        viewModelScope.launch {
            when (val evRes = client.fetchFamilyEvents(config, session.accessToken, famId, session.userId)) {
                is ApiResult.Success -> {
                    val mapped = evRes.data.map {
                        FamilyEvent(it.id, it.title, it.dateLabel, it.timeLabel, it.location, it.organizerName, it.confirmedCount, it.isConfirmedByMe)
                    }
                    _uiState.update { it.copy(events = mapped) }
                }
                is ApiResult.Error -> Unit
            }
            when (val shRes = client.fetchShoppingItems(config, session.accessToken, famId)) {
                is ApiResult.Success -> {
                    val mapped = shRes.data.map { ShoppingItem(it.id, it.title, it.category, it.isBought) }
                    _uiState.update { it.copy(shoppingList = mapped) }
                }
                is ApiResult.Error -> Unit
            }
            when (val tRes = client.fetchFamilyTasks(config, session.accessToken, famId)) {
                is ApiResult.Success -> {
                    val mapped = tRes.data.map { FamilyTask(it.id, it.title, it.assignee, it.deadline, it.isDone) }
                    _uiState.update { it.copy(tasks = mapped) }
                }
                is ApiResult.Error -> Unit
            }
            when (val gRes = client.fetchGalleryPhotos(config, session.accessToken, famId)) {
                is ApiResult.Success -> {
                    val mapped = gRes.data.map { GalleryPhoto(it.id, it.albumName, it.storagePath, it.caption, it.createdAt) }
                    _uiState.update { it.copy(galleryPhotos = mapped) }
                    mapped.forEach { photo -> ensureGalleryPhotoLoaded(photo.storagePath) }
                }
                is ApiResult.Error -> Unit
            }
        }
    }

    fun addEvent(title: String, dateLabel: String, timeLabel: String, location: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val famId = _uiState.value.familyId ?: return
        val org = _uiState.value.currentUserDisplayName
        viewModelScope.launch {
            when (val res = client.createFamilyEvent(config, session.accessToken, famId, session.userId, org, clean, dateLabel, timeLabel, location)) {
                is ApiResult.Success -> refreshFamilyHubData()
                is ApiResult.Error -> showInfoDialog("Событие", res.message)
            }
        }
    }

    fun toggleEventConfirmation(eventId: String) {
        val current = _uiState.value.events.firstOrNull { it.id == eventId } ?: return
        val nextConfirm = !current.isConfirmedByMe
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            when (val res = client.setEventRsvp(config, session.accessToken, eventId, session.userId, nextConfirm)) {
                is ApiResult.Success -> refreshFamilyHubData()
                is ApiResult.Error -> showInfoDialog("Участие", res.message)
            }
        }
    }

    fun toggleShoppingItem(itemId: String) {
        val current = _uiState.value.shoppingList.firstOrNull { it.id == itemId } ?: return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            when (val res = client.updateShoppingItemRemote(config, session.accessToken, itemId, !current.isBought)) {
                is ApiResult.Success -> refreshFamilyHubData()
                is ApiResult.Error -> showInfoDialog("Покупки", res.message)
            }
        }
    }

    fun addShoppingItem(title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val famId = _uiState.value.familyId ?: return
        viewModelScope.launch {
            when (val res = client.addShoppingItemRemote(config, session.accessToken, famId, session.userId, clean)) {
                is ApiResult.Success -> refreshFamilyHubData()
                is ApiResult.Error -> showInfoDialog("Покупки", res.message)
            }
        }
    }

    fun deleteShoppingItem(itemId: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            client.deleteShoppingItemRemote(config, session.accessToken, itemId)
            refreshFamilyHubData()
        }
    }

    fun addTask(title: String, assignee: String, deadline: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val famId = _uiState.value.familyId ?: return
        viewModelScope.launch {
            when (val res = client.addFamilyTaskRemote(config, session.accessToken, famId, session.userId, clean, assignee, deadline)) {
                is ApiResult.Success -> refreshFamilyHubData()
                is ApiResult.Error -> showInfoDialog("Задачи", res.message)
            }
        }
    }

    fun toggleTask(taskId: String) {
        val current = _uiState.value.tasks.firstOrNull { it.id == taskId } ?: return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            when (val res = client.updateFamilyTaskRemote(config, session.accessToken, taskId, !current.isDone)) {
                is ApiResult.Success -> refreshFamilyHubData()
                is ApiResult.Error -> showInfoDialog("Задачи", res.message)
            }
        }
    }

    fun deleteTask(taskId: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            client.deleteFamilyTaskRemote(config, session.accessToken, taskId)
            refreshFamilyHubData()
        }
    }

    fun uploadGalleryPhoto(uri: Uri, albumName: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val famId = _uiState.value.familyId ?: return
        val app = getApplication<Application>()
        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingGallery = true) }
            try {
                val resolver = app.contentResolver
                val mime = resolver.getType(uri) ?: "image/jpeg"
                var fileName = "family_photo.jpg"
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0 && cursor.moveToFirst()) {
                        val queried = cursor.getString(nameIdx)
                        if (!queried.isNullOrBlank()) fileName = queried
                    }
                }
                val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null || bytes.isEmpty()) {
                    showInfoDialog("Галерея", "Не удалось прочитать выбранное фото.")
                    return@launch
                }
                when (val up = client.uploadGalleryPhotoBytes(config, session.accessToken, famId, fileName, mime, bytes)) {
                    is ApiResult.Success -> {
                        val path = up.data
                        _uiState.update { st ->
                            val newCache = st.galleryCache.toMutableMap().apply { put(path, bytes) }
                            st.copy(galleryCache = newCache)
                        }
                        when (val rec = client.insertGalleryPhotoRecord(config, session.accessToken, famId, session.userId, albumName, path, _uiState.value.currentUserDisplayName)) {
                            is ApiResult.Success -> refreshFamilyHubData()
                            is ApiResult.Error -> showInfoDialog("Галерея", rec.message)
                        }
                    }
                    is ApiResult.Error -> showInfoDialog("Ошибка загрузки фото", up.message)
                }
            } finally {
                _uiState.update { it.copy(isUploadingGallery = false) }
            }
        }
    }

    private fun ensureGalleryPhotoLoaded(path: String) {
        if (_uiState.value.galleryCache.containsKey(path) || loadingGalleryPaths.contains(path)) return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        loadingGalleryPaths.add(path)
        viewModelScope.launch {
            try {
                when (val res = client.downloadGalleryPhotoBytes(config, session.accessToken, path)) {
                    is ApiResult.Success -> {
                        _uiState.update { st ->
                            val newCache = st.galleryCache.toMutableMap().apply { put(path, res.data) }
                            st.copy(galleryCache = newCache)
                        }
                    }
                    is ApiResult.Error -> Unit
                }
            } finally {
                loadingGalleryPaths.remove(path)
            }
        }
    }

    fun sendAiPreviewPrompt(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        val stateSnapshot = _uiState.value
        val userMsg = AiChatItem("u_${System.currentTimeMillis()}", text, true, "Сейчас")
        _uiState.update { it.copy(aiMessages = it.aiMessages + userMsg, isAiThinking = true) }

        val config = storage.getServerConfig()
        val session = storage.getSession()

        val ctxJson = JSONObject().apply {
            val evArr = JSONArray()
            stateSnapshot.events.take(5).forEach { e ->
                evArr.put(JSONObject().put("title", e.title).put("dateLabel", e.dateLabel).put("timeLabel", e.timeLabel))
            }
            put("events", evArr)

            val shArr = JSONArray()
            stateSnapshot.shoppingList.take(15).forEach { s ->
                shArr.put(JSONObject().put("title", s.title).put("isBought", s.isBought))
            }
            put("shopping", shArr)

            val tkArr = JSONArray()
            stateSnapshot.tasks.take(10).forEach { t ->
                tkArr.put(JSONObject().put("title", t.title).put("assignee", t.assignee).put("isDone", t.isDone))
            }
            put("tasks", tkArr)
        }

        viewModelScope.launch {
            val replyText = if (config.isConfigured && session != null) {
                when (val res = client.askNexoAi(config, session.accessToken, text, ctxJson)) {
                    is ApiResult.Success -> res.data
                    is ApiResult.Error -> buildLocalAiFallback(text, stateSnapshot)
                }
            } else {
                buildLocalAiFallback(text, stateSnapshot)
            }

            val botMsg = AiChatItem(
                "a_${System.currentTimeMillis() + 1}",
                replyText,
                false,
                "Сейчас"
            )
            _uiState.update { it.copy(aiMessages = it.aiMessages + botMsg, isAiThinking = false) }
        }
    }

    private fun buildLocalAiFallback(prompt: String, state: NexoUiState): String {
        val q = prompt.lowercase()
        return when {
            q.contains("покуп") || q.contains("продукт") || q.contains("ужин") -> {
                val openShop = state.shoppingList.filter { !it.isBought }.map { it.title }
                if (openShop.isNotEmpty()) {
                    "Сейчас в вашем списке покупок: ${openShop.joinToString(", ")}. Для ужина могу предложить добавить хлеб, овощи, напитки и десерт."
                } else {
                    "Список покупок сейчас пуст. Для семейного ужина отлично подойдут: мясо или рыба, свежие овощи, гарнир, хлеб и фрукты."
                }
            }
            q.contains("задач") || q.contains("план") || q.contains("поездк") -> {
                val openTasks = state.tasks.filter { !it.isDone }.map { it.title }
                val evs = state.events.take(3).map { "${it.title} (${it.dateLabel}, ${it.timeLabel})" }
                buildString {
                    if (evs.isNotEmpty()) append("Ближайшие события: ${evs.joinToString("; ")}. ")
                    if (openTasks.isNotEmpty()) append("Открытые задачи: ${openTasks.joinToString("; ")}.")
                    if (isEmpty()) append("Напишите, какое событие или поездку планируем — разберём по шагам.")
                }
            }
            else -> "Я готов помочь с семейными списками покупок, задачами и планированием встреч. Задайте вопрос или выберите быстрый сценарий выше."
        }
    }

    fun toggleBiometric(enabled: Boolean) {
        storage.setBiometricEnabled(enabled)
        _uiState.update { it.copy(biometricEnabled = enabled) }
    }

    fun togglePin(enabled: Boolean) {
        if (enabled) {
            _uiState.update { it.copy(showSetPinDialog = true) }
        } else {
            storage.clearPin()
            _uiState.update { it.copy(pinEnabled = false) }
        }
    }

    fun saveNewPin(pin: String) {
        if (pin.length == 4 && pin.all { it.isDigit() }) {
            storage.savePin(pin)
            _uiState.update { it.copy(pinEnabled = true, showSetPinDialog = false) }
        }
    }

    fun dismissSetPinDialog() {
        _uiState.update { it.copy(showSetPinDialog = false) }
    }

    fun verifyPin(pin: String): Boolean = storage.verifyPin(pin)

    fun unlockApp() {
        _uiState.update { it.copy(isAppLocked = false) }
    }


    fun startCall(chatId: String, chatTitle: String, isVideo: Boolean) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val famId = _uiState.value.familyId ?: return
        val callType = if (isVideo) "video" else "audio"
        val starter = _uiState.value.currentUserDisplayName
        val roomHash = CryptoHelper.sha256Hex("$famId:$chatId").take(14)
        val roomCode = "nexo-family-$roomHash"

        viewModelScope.launch {
            // Check if there's already an active call in this chat
            val existing = when (val res = client.fetchActiveCalls(config, session.accessToken, famId)) {
                is ApiResult.Success -> res.data.firstOrNull { it.chatId == chatId }
                is ApiResult.Error -> null
            }
            if (existing != null) {
                _uiState.update {
                    it.copy(
                        activeCall = ActiveCallSession(
                            id = existing.id,
                            chatId = existing.chatId,
                            chatTitle = chatTitle,
                            starterName = existing.starterName,
                            callType = callType,
                            roomCode = existing.roomCode
                        ),
                        incomingCall = null
                    )
                }
                return@launch
            }

            when (val res = client.startCallSession(config, session.accessToken, chatId, famId, session.userId, starter, callType, roomCode)) {
                is ApiResult.Success -> {
                    val created = res.data
                    notifiedCallIds.add(created.id)
                    _uiState.update {
                        it.copy(
                            activeCall = ActiveCallSession(
                                id = created.id,
                                chatId = chatId,
                                chatTitle = chatTitle,
                                starterName = starter,
                                callType = callType,
                                roomCode = created.roomCode
                            ),
                            incomingCall = null
                        )
                    }
                    val callNote = if (isVideo) "📹 Начат видеозвонок" else "📞 Начат аудиозвонок"
                    val encNote = CryptoHelper.encryptText(famId, callNote)
                    client.sendChatMessage(config, session.accessToken, chatId, session.userId, encNote, "text")
                }
                is ApiResult.Error -> showInfoDialog("Звонок", res.message)
            }
        }
    }

    fun joinIncomingCall() {
        val incoming = _uiState.value.incomingCall ?: return
        _uiState.update { it.copy(activeCall = incoming, incomingCall = null) }
    }

    fun dismissIncomingCall() {
        _uiState.update { it.copy(incomingCall = null) }
    }

    fun endActiveCall() {
        val current = _uiState.value.activeCall ?: return
        _uiState.update { it.copy(activeCall = null) }
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            client.endCallSession(config, session.accessToken, current.id)
        }
    }

    private suspend fun checkActiveCallsSuspend(config: ServerConfig, session: StoredSession) {
        val famId = _uiState.value.familyId ?: return
        if (_uiState.value.activeCall != null) return
        when (val res = client.fetchActiveCalls(config, session.accessToken, famId)) {
            is ApiResult.Success -> {
                val incomingRemote = res.data.firstOrNull { it.startedBy != session.userId }
                if (incomingRemote != null) {
                    val chatTitle = _uiState.value.chats.firstOrNull { it.id == incomingRemote.chatId }?.title ?: "Семейный чат"
                    val sessionModel = ActiveCallSession(
                        id = incomingRemote.id,
                        chatId = incomingRemote.chatId,
                        chatTitle = chatTitle,
                        starterName = incomingRemote.starterName,
                        callType = incomingRemote.callType,
                        roomCode = incomingRemote.roomCode
                    )
                    _uiState.update { it.copy(incomingCall = sessionModel) }
                    if (notifiedCallIds.add(incomingRemote.id)) {
                        val label = if (incomingRemote.callType == "video") "Входящий видеозвонок" else "Входящий аудиозвонок"
                        notificationHelper.showMessageNotification(
                            chatTitle = "$label • $chatTitle",
                            messagePreview = "${incomingRemote.starterName} приглашает в звонок",
                            notificationId = incomingRemote.id.hashCode()
                        )
                    }
                } else {
                    _uiState.update { it.copy(incomingCall = null) }
                }
            }
            is ApiResult.Error -> Unit
        }
    }

    fun toggleLocationSharing(enabled: Boolean) {
        _uiState.update { it.copy(locationSharingEnabled = enabled) }
    }

    fun showInfoDialog(title: String, body: String) {
        _uiState.update { it.copy(infoDialogTitle = title, infoDialogBody = body) }
    }

    fun dismissInfoDialog() {
        _uiState.update { it.copy(infoDialogTitle = null, infoDialogBody = null) }
    }

    private fun createBaseState(): NexoUiState {
        return NexoUiState(
            events = listOf(
                FamilyEvent("e1", "Семейный ужин", "Воскресенье, 29 ноя", "15:00", "Дом родителей", "Семья", 1, true)
            ),
            shoppingList = listOf(
                ShoppingItem("s1", "Молоко и творог", "Молочное", false),
                ShoppingItem("s2", "Фрукты к ужину", "Фрукты", false)
            ),
            tasks = listOf(
                FamilyTask("t1", "Пригласить участников семьи", "Владелец", "Сегодня", false)
            ),
            albums = listOf(
                GalleryAlbum("g1", "Семейные встречи", 0, "2026", "Вся семья", true, false)
            ),
            aiTools = listOf(
                AiTool("ai1", "Сводка переписки", "Кратко о главном за день", "Сделай краткую сводку обсуждения"),
                AiTool("ai2", "Список покупок", "Собрать и сгруппировать", "Составь список продуктов для семейного ужина"),
                AiTool("ai3", "Планировщик", "Поездки и праздники", "Помоги спланировать семейную поездку")
            ),
            aiMessages = listOf(
                AiChatItem(
                    "ai_welcome",
                    "Привет! Я NEXO AI — помощник вашей семьи. Помогу собрать список покупок, сверить задачи и спланировать встречу.",
                    false,
                    "Сегодня"
                )
            )
        )
    }
}
