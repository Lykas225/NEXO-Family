-- NEXO Family: v1.0.0 — Message editing and soft deletion.
-- Run in Supabase SQL Editor after Stage 1-8 migrations.

drop policy if exists "senders can update own messages" on public.messages;
create policy "senders can update own messages"
on public.messages for update
to authenticated
using (sender_id = auth.uid() and public.is_chat_member(chat_id))
with check (sender_id = auth.uid() and public.is_chat_member(chat_id));

create or replace function public.edit_chat_message(
  p_message_id uuid,
  p_new_ciphertext text
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  if pg_catalog.btrim(coalesce(p_new_ciphertext, '')) = '' then
    raise exception using errcode = '22023', message = 'Message cannot be empty';
  end if;

  update public.messages
     set ciphertext = p_new_ciphertext,
         edited_at = now()
   where id = p_message_id
     and sender_id = v_user_id
     and deleted_at is null;

  return found;
end;
$function$;

create or replace function public.delete_chat_message(
  p_message_id uuid
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  update public.messages
     set deleted_at = now()
   where id = p_message_id
     and sender_id = v_user_id
     and deleted_at is null;

  return found;
end;
$function$;

revoke all on function public.edit_chat_message(uuid, text) from public, anon;
grant execute on function public.edit_chat_message(uuid, text) to authenticated;

revoke all on function public.delete_chat_message(uuid) from public, anon;
grant execute on function public.delete_chat_message(uuid) to authenticated;
