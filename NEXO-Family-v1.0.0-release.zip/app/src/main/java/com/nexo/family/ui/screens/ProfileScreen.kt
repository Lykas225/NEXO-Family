package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.MemberRole
import com.nexo.family.ui.components.NexoAvatar
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

@Composable
fun ProfileScreen(
    displayName: String,
    email: String,
    role: MemberRole,
    biometricEnabled: Boolean,
    pinEnabled: Boolean,
    onBack: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onTogglePin: (Boolean) -> Unit,
    onRefreshServer: () -> Unit,
    onSignOut: () -> Unit,
    onCheckUpdate: () -> Unit = {},
    onActionInfo: (String, String) -> Unit
) {
    val initials = displayName.trim().take(2).uppercase().ifEmpty { "ВЫ" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
    ) {
        Surface(color = NexoColors.SurfaceBar) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = NexoColors.TextPrimary)
                    }
                    Text("Профиль и настройки", color = NexoColors.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.55f))
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                NexoCard {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NexoAvatar(
                            initials = initials,
                            accentColor = NexoColors.Turquoise,
                            size = 68.dp,
                            isOnline = true
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(displayName, color = NexoColors.TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(2.dp))
                            Text(email.ifEmpty { "Аккаунт Supabase" }, color = NexoColors.Turquoise, fontSize = 13.sp)
                            Text("Роль: ${role.label} • Версия 1.0.0 (Релиз)", color = NexoColors.TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }

            item { SectionLabel("Безопасность и вход") }

            item {
                NexoCard {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        SettingSwitchRow(
                            icon = Icons.Rounded.Fingerprint,
                            title = "Биометрическая блокировка",
                            subtitle = "Вход по отпечатку или лицу",
                            checked = biometricEnabled,
                            onCheckedChange = onToggleBiometric
                        )
                        HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))
                        SettingSwitchRow(
                            icon = Icons.Rounded.Key,
                            title = "PIN-код приложения",
                            subtitle = "Дополнительная защита экрана",
                            checked = pinEnabled,
                            onCheckedChange = onTogglePin
                        )
                    }
                }
            }

            item { SectionLabel("Аккаунт и сервер") }

            item {
                NexoCard {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        SettingActionRow(
                            icon = Icons.Rounded.Sync,
                            title = "Обновить данные с сервера",
                            subtitle = "Синхронизировать семью, участников и чаты",
                            onClick = onRefreshServer
                        )
                        HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))
                        SettingActionRow(
                            icon = Icons.Rounded.SystemUpdate,
                            title = "Проверить обновления",
                            subtitle = "Текущая сборка v1.0.0",
                            onClick = onCheckUpdate
                        )
                        HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))
                        SettingActionRow(
                            icon = Icons.Rounded.Lock,
                            title = "Сквозное шифрование (E2EE)",
                            subtitle = "Активно: AES-256-GCM шифрование сообщений на устройстве",
                            onClick = {
                                onActionInfo(
                                    "Сквозное шифрование E2EE",
                                    "Все новые сообщения и метаданные вложений шифруются на устройстве алгоритмом AES-256-GCM (формат ENC1) перед отправкой в Supabase."
                                )
                            }
                        )
                        HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))
                        SettingActionRow(
                            icon = Icons.AutoMirrored.Rounded.Logout,
                            title = "Выйти из аккаунта",
                            subtitle = "Завершить текущую сессию на этом устройстве",
                            tint = NexoColors.DangerRed,
                            onClick = onSignOut
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(subtitle, color = NexoColors.TextSecondary, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = NexoColors.DeepNavy,
                checkedTrackColor = NexoColors.Turquoise
            )
        )
    }
}

@Composable
private fun SettingActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: androidx.compose.ui.graphics.Color = NexoColors.Purple,
    onClick: () -> Unit
) {
    Surface(
        color = NexoColors.GraphiteCard,
        onClick = onClick,
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(subtitle, color = NexoColors.TextSecondary, fontSize = 12.sp)
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = NexoColors.TextSecondary)
        }
    }
}
