package com.nexo.family

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexo.family.model.AppGate
import com.nexo.family.model.NexoTab
import com.nexo.family.ui.components.NexoBottomBar
import com.nexo.family.ui.components.NexoTopBar
import com.nexo.family.ui.screens.*
import com.nexo.family.ui.theme.NexoColors
import com.nexo.family.ui.theme.NexoTheme
import com.nexo.family.viewmodel.NexoViewModel

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            NexoTheme {
                NexoFamilyApp(activity = this)
            }
        }
    }

    fun showBiometricPrompt(onSuccess: () -> Unit, onError: (String) -> Unit) {
        val biometricManager = BiometricManager.from(this)
        val canAuth = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            onError("Биометрия недоступна на этом устройстве")
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    onError(errString.toString())
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Вход в NEXO Family")
            .setSubtitle("Подтвердите личность для доступа к семейным чатам")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(info)
    }
}

@Composable
fun NexoFamilyApp(activity: MainActivity, vm: NexoViewModel = viewModel()) {
    val state by vm.uiState.collectAsState()
    val context = LocalContext.current

    val notifPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(state.gate) {
        if (state.gate == AppGate.MAIN && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
    ) {
        if (state.isAppLocked && (state.pinEnabled || state.biometricEnabled)) {
            LockScreen(
                pinEnabled = state.pinEnabled,
                biometricEnabled = state.biometricEnabled,
                onVerifyPin = { vm.verifyPin(it) },
                onUnlockSuccess = { vm.unlockApp() },
                onTriggerBiometric = {
                    activity.showBiometricPrompt(
                        onSuccess = { vm.unlockApp() },
                        onError = { }
                    )
                }
            )
            return@Box
        }

        if (state.activeCall != null) {
            CallScreen(
                call = state.activeCall!!,
                displayName = state.currentUserDisplayName,
                onEndCall = { vm.endActiveCall() }
            )
            return@Box
        }

        when (state.gate) {
            AppGate.CHECKING_SESSION -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = NexoColors.Turquoise)
                    Spacer(Modifier.height(14.dp))
                    Text("Проверка сессии NEXO Family…", color = NexoColors.TextSecondary, fontSize = 14.sp)
                }
            }

            AppGate.AUTH -> {
                AuthScreen(
                    supabaseUrl = state.supabaseUrl,
                    supabaseAnonKey = state.supabaseAnonKey,
                    isServerConfigured = state.isServerConfigured,
                    isLoading = state.isLoading,
                    errorMessage = state.authError,
                    noticeMessage = state.authNotice,
                    onSaveServerConfig = { url, key -> vm.saveServerConfig(url, key) },
                    onSignIn = { email, pass -> vm.signIn(email, pass) },
                    onSignUp = { email, pass -> vm.signUp(email, pass) }
                )
            }

            AppGate.CREATE_FAMILY -> {
                CreateFamilyScreen(
                    userEmail = state.currentUserEmail,
                    isLoading = state.isLoading,
                    errorMessage = state.authError,
                    onCreateFamily = { displayName, familyName -> vm.createFamily(displayName, familyName) },
                    onRedeemInvite = { code, name -> vm.redeemInvite(code, name) },
                    onRefreshCheck = { vm.refreshFamilyFromServer() },
                    onSignOut = { vm.signOut() }
                )
            }

            AppGate.MAIN -> {
                val activeChat = state.selectedChatId?.let { id ->
                    state.chats.firstOrNull { it.id == id }
                }

                when {
                    activeChat != null -> {
                        ChatDetailScreen(
                            chat = activeChat,
                            messages = state.messagesByChat[activeChat.id].orEmpty(),
                            mediaCache = state.mediaCache,
                            playingVoiceId = state.playingVoiceId,
                            voicePlaybackSpeed = state.voicePlaybackSpeed,
                            isUploadingMedia = state.isUploadingMedia,
                            voiceHelper = vm.voiceHelper,
                            onBack = { vm.closeChat() },
                            onSendMessage = { vm.sendMessage(activeChat.id, it) },
                            onSendPhoto = { uri -> vm.sendMediaFromUri(activeChat.id, uri, isPhoto = true) },
                            onSendFile = { uri -> vm.sendMediaFromUri(activeChat.id, uri, isPhoto = false) },
                            onSendVoice = { bytes, dur -> vm.sendVoiceBytes(activeChat.id, bytes, dur) },
                            onToggleVoicePlay = { msg -> vm.toggleVoicePlayback(msg) },
                            onCycleVoiceSpeed = { vm.cycleVoiceSpeed() },
                            onOpenFile = { msg -> vm.openFileAttachment(msg) },
                            onEditMessage = { id, newTxt -> vm.editMessage(activeChat.id, id, newTxt) },
                            onDeleteMessage = { id -> vm.deleteMessage(activeChat.id, id) },
                            onCallClick = { vm.startCall(activeChat.id, activeChat.title, isVideo = false) },
                            onVideoCallClick = { vm.startCall(activeChat.id, activeChat.title, isVideo = true) }
                        )
                    }

                    state.showProfile -> {
                        ProfileScreen(
                            displayName = state.currentUserDisplayName,
                            email = state.currentUserEmail,
                            role = state.currentUserRole,
                            biometricEnabled = state.biometricEnabled,
                            pinEnabled = state.pinEnabled,
                            onBack = { vm.closeProfile() },
                            onToggleBiometric = { vm.toggleBiometric(it) },
                            onTogglePin = { vm.togglePin(it) },
                            onRefreshServer = { vm.refreshFamilyFromServer() },
                            onSignOut = { vm.signOut() },
                            onCheckUpdate = { vm.checkReleaseUpdateOnce(manual = true) },
                            onActionInfo = { title, body -> vm.showInfoDialog(title, body) }
                        )
                    }

                    else -> {
                        Scaffold(
                            containerColor = NexoColors.DeepNavy,
                            topBar = {
                                NexoTopBar(
                                    familyName = state.familyName,
                                    onlineCount = state.onlineCount,
                                    unreadNotifications = state.unreadNotificationsCount,
                                    onNotificationsClick = {
                                        vm.showInfoDialog(
                                            "Уведомления NEXO Family",
                                            "Системные уведомления о новых сообщениях активны. Разрешите уведомления в настройках Android, если не видите их в шторке."
                                        )
                                    },
                                    onProfileClick = { vm.openProfile() }
                                )
                            },
                            bottomBar = {
                                NexoBottomBar(
                                    currentTab = state.currentTab,
                                    onTabSelected = { vm.selectTab(it) }
                                )
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                AnimatedContent(
                                    targetState = state.currentTab,
                                    transitionSpec = {
                                        fadeIn(animationSpec = tween(200)) togetherWith fadeOut(animationSpec = tween(160))
                                    },
                                    label = "NexoTabTransition"
                                ) { tab ->
                                    when (tab) {
                                        NexoTab.CHATS -> ChatsScreen(
                                            chats = state.chats,
                                            searchQuery = state.searchQuery,
                                            onSearchChange = { vm.updateSearchQuery(it) },
                                            onChatClick = { vm.openChat(it) }
                                        )

                                        NexoTab.FAMILY -> FamilyScreen(
                                            familyName = state.familyName,
                                            currentUserRole = state.currentUserRole,
                                            members = state.members,
                                            invites = state.invites,
                                            memberLimit = state.memberLimit,
                                            freeSlots = state.freeSlots,
                                            canManageInvites = state.canManageInvites,
                                            showInviteDialog = state.showInviteDialog,
                                            lastGeneratedInviteCode = state.lastGeneratedInviteCode,
                                            isLoading = state.isLoading,
                                            onOpenInviteDialog = { vm.openInviteDialog() },
                                            onCloseInviteDialog = { vm.closeInviteDialog() },
                                            onGenerateInvite = { vm.generateOneTimeInvite(24) },
                                            onRevokeInvite = { vm.revokeInvite(it) },
                                            onToggleAdminRole = { vm.toggleMemberAdminRole(it) },
                                            onRemoveMember = { vm.removeFamilyMember(it) },
                                            onStartDirectChat = { vm.startDirectChat(it) },
                                            onRefresh = { vm.refreshFamilyFromServer() }
                                        )

                                        NexoTab.EVENTS -> EventsScreen(
                                            events = state.events,
                                            shoppingList = state.shoppingList,
                                            tasks = state.tasks,
                                            locationSharingEnabled = state.locationSharingEnabled,
                                            onAddEvent = { t, d, tm, loc -> vm.addEvent(t, d, tm, loc) },
                                            onToggleEventConfirm = { vm.toggleEventConfirmation(it) },
                                            onToggleShopping = { vm.toggleShoppingItem(it) },
                                            onAddShopping = { vm.addShoppingItem(it) },
                                            onDeleteShopping = { vm.deleteShoppingItem(it) },
                                            onAddTask = { t, a, dl -> vm.addTask(t, a, dl) },
                                            onToggleTask = { vm.toggleTask(it) },
                                            onDeleteTask = { vm.deleteTask(it) },
                                            onToggleLocationSharing = { vm.toggleLocationSharing(it) },
                                            onRefresh = { vm.refreshFamilyHubData() }
                                        )

                                        NexoTab.GALLERY -> GalleryScreen(
                                            photos = state.galleryPhotos,
                                            galleryCache = state.galleryCache,
                                            isUploading = state.isUploadingGallery,
                                            onUploadPhoto = { uri, album -> vm.uploadGalleryPhoto(uri, album) },
                                            onRefresh = { vm.refreshFamilyHubData() }
                                        )

                                        NexoTab.AI -> AiScreen(
                                            tools = state.aiTools,
                                            messages = state.aiMessages,
                                            isThinking = state.isAiThinking,
                                            onSendPrompt = { vm.sendAiPreviewPrompt(it) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (state.incomingCall != null && state.activeCall == null) {
            val inc = state.incomingCall!!
            AlertDialog(
                onDismissRequest = { vm.dismissIncomingCall() },
                containerColor = NexoColors.GraphiteCard,
                shape = RoundedCornerShape(22.dp),
                title = {
                    Text(
                        text = if (inc.callType == "video") "📹 Входящий видеозвонок" else "📞 Входящий аудиозвонок",
                        color = NexoColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Text(
                        text = "${inc.starterName} зовёт вас в звонок (${inc.chatTitle}).",
                        color = NexoColors.TextSecondary,
                        fontSize = 14.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { vm.joinIncomingCall() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexoColors.SuccessGreen,
                            contentColor = NexoColors.DeepNavy
                        )
                    ) {
                        Text("Присоединиться", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { vm.dismissIncomingCall() }) {
                        Text("Отклонить", color = NexoColors.DangerRed)
                    }
                }
            )
        }

        if (state.showSetPinDialog) {
            var pinInput by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { vm.dismissSetPinDialog() },
                containerColor = NexoColors.GraphiteCard,
                shape = RoundedCornerShape(22.dp),
                title = {
                    Text("Установить PIN-код", color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Введите 4 цифры для защиты входа в NEXO Family:", color = NexoColors.TextSecondary, fontSize = 13.sp)
                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { if (it.length <= 4 && it.all { ch -> ch.isDigit() }) pinInput = it },
                            singleLine = true,
                            label = { Text("4-значный PIN") },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { vm.saveNewPin(pinInput) },
                        enabled = pinInput.length == 4,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexoColors.Turquoise,
                            contentColor = NexoColors.DeepNavy
                        )
                    ) {
                        Text("Сохранить", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { vm.dismissSetPinDialog() }) {
                        Text("Отмена", color = NexoColors.TextSecondary)
                    }
                }
            )
        }

        if (state.updateNoticeTag != null && state.updateNoticeUrl != null) {
            val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
            AlertDialog(
                onDismissRequest = { vm.dismissUpdateNotice() },
                containerColor = NexoColors.GraphiteCard,
                shape = RoundedCornerShape(22.dp),
                title = { Text("Доступна новая версия ${state.updateNoticeTag}", color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                text = { Text("Вышла новая версия NEXO Family. Открыть страницу загрузки на GitHub?", color = NexoColors.TextSecondary, fontSize = 14.sp) },
                confirmButton = {
                    Button(
                        onClick = {
                            val u = state.updateNoticeUrl!!
                            vm.dismissUpdateNotice()
                            uriHandler.openUri(u)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexoColors.Turquoise,
                            contentColor = NexoColors.DeepNavy
                        )
                    ) {
                        Text("Открыть", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { vm.dismissUpdateNotice() }) {
                        Text("Позже", color = NexoColors.TextSecondary)
                    }
                }
            )
        }

        if (state.infoDialogTitle != null && state.infoDialogBody != null) {
            AlertDialog(
                onDismissRequest = { vm.dismissInfoDialog() },
                containerColor = NexoColors.GraphiteCard,
                shape = RoundedCornerShape(22.dp),
                title = {
                    Text(
                        text = state.infoDialogTitle!!,
                        color = NexoColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Text(
                        text = state.infoDialogBody!!,
                        color = NexoColors.TextSecondary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { vm.dismissInfoDialog() }) {
                        Text("Понятно", color = NexoColors.Turquoise, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}
