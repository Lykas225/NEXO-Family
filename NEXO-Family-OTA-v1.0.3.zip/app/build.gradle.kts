plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val supabaseUrlEnv = System.getenv("SUPABASE_URL") ?: ""
val supabaseAnonKeyEnv = System.getenv("SUPABASE_ANON_KEY") ?: ""
val githubRepoEnv = System.getenv("GITHUB_REPOSITORY") ?: ""
val fbProjectIdEnv = System.getenv("FIREBASE_PROJECT_ID") ?: ""
val fbAppIdEnv = System.getenv("FIREBASE_APP_ID") ?: ""
val fbApiKeyEnv = System.getenv("FIREBASE_API_KEY") ?: ""
val fbSenderIdEnv = System.getenv("FIREBASE_SENDER_ID") ?: ""

android {
    namespace = "com.nexo.family"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexo.family"
        minSdk = 26
        targetSdk = 35
        versionCode = 1000003
        versionName = "1.0.3"

        buildConfigField("String", "SUPABASE_URL", "\"$supabaseUrlEnv\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"$supabaseAnonKeyEnv\"")
        buildConfigField("String", "GITHUB_REPO", "\"$githubRepoEnv\"")
        buildConfigField("String", "FIREBASE_PROJECT_ID", "\"$fbProjectIdEnv\"")
        buildConfigField("String", "FIREBASE_APP_ID", "\"$fbAppIdEnv\"")
        buildConfigField("String", "FIREBASE_API_KEY", "\"$fbApiKeyEnv\"")
        buildConfigField("String", "FIREBASE_SENDER_ID", "\"$fbSenderIdEnv\"")
    }

    signingConfigs {
        create("release") {
            storeFile = file(System.getenv("KEYSTORE_PATH") ?: "nexo-upload.jks")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
            keyAlias = System.getenv("KEY_ALIAS") ?: "nexo"
            keyPassword = System.getenv("KEY_PASSWORD") ?: ""
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.firebase:firebase-messaging:24.1.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
