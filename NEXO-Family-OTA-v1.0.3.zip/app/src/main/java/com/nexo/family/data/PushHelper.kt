package com.nexo.family.data

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.nexo.family.BuildConfig

/** Push-уведомления (FCM). Если Firebase не настроен при сборке — тихо отключается. */
object PushHelper {
    private const val PREFS = "nexo_family_push_v1"
    private const val KEY_TOKEN = "fcm_token"

    val isConfigured: Boolean
        get() = BuildConfig.FIREBASE_PROJECT_ID.isNotBlank() &&
            BuildConfig.FIREBASE_APP_ID.isNotBlank() &&
            BuildConfig.FIREBASE_API_KEY.isNotBlank() &&
            BuildConfig.FIREBASE_SENDER_ID.isNotBlank()

    fun initFirebase(context: Context) {
        if (!isConfigured) return
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setProjectId(BuildConfig.FIREBASE_PROJECT_ID)
                    .setApplicationId(BuildConfig.FIREBASE_APP_ID)
                    .setApiKey(BuildConfig.FIREBASE_API_KEY)
                    .setGcmSenderId(BuildConfig.FIREBASE_SENDER_ID)
                    .build()
                FirebaseApp.initializeApp(context, options)
            }
        } catch (_: Exception) {
        }
    }

    fun savedToken(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TOKEN, null)

    fun saveToken(context: Context, token: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TOKEN, token).apply()
    }

    /** Получает актуальный FCM-токен (нужны Google Play Services). */
    fun fetchToken(context: Context, onToken: (String) -> Unit) {
        if (!isConfigured) return
        try {
            initFirebase(context)
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                if (!token.isNullOrBlank()) {
                    saveToken(context, token)
                    onToken(token)
                }
            }
        } catch (_: Exception) {
        }
    }
}
