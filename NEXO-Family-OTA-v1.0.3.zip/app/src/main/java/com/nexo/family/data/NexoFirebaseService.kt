package com.nexo.family.data

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NexoFirebaseService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        PushHelper.saveToken(this, token)
        val storage = SessionStorage(this)
        val session = storage.getSession() ?: return
        val config = storage.getServerConfig()
        if (!config.isConfigured) return
        CoroutineScope(Dispatchers.IO).launch {
            SupabaseClient().registerDeviceToken(config, session.accessToken, token)
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        // Приложение открыто — уведомления и звонки уже обрабатывает опрос внутри приложения
        if (NotificationHelper.appInForeground) return
        val data = message.data
        val title = data["title"].orEmpty().ifBlank { "NEXO Family" }
        val body = data["body"].orEmpty().ifBlank { "Новое сообщение" }
        val key = data["chat_id"].orEmpty().ifBlank { data["id"].orEmpty() }
        NotificationHelper(this).showMessageNotification(
            chatTitle = title,
            messagePreview = body,
            notificationId = if (key.isNotEmpty()) key.hashCode() else System.currentTimeMillis().toInt()
        )
    }
}
