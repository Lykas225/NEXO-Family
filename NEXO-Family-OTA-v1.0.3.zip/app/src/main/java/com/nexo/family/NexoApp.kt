package com.nexo.family

import android.app.Application
import com.nexo.family.data.PushHelper

class NexoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PushHelper.initFirebase(this)
    }
}
