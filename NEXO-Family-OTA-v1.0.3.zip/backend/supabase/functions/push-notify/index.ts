import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Секреты функции: PUSH_SECRET, FCM_SERVICE_ACCOUNT (JSON сервисного аккаунта Firebase целиком)
// SUPABASE_URL и SUPABASE_SERVICE_ROLE_KEY Supabase подставляет сам.

const admin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

function b64url(input: ArrayBuffer | string): string {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : new Uint8Array(input);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function getAccessToken(sa: any): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64url(JSON.stringify({
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  }));
  const pem = String(sa.private_key).replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"],
  );
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(`${header}.${claim}`));
  const jwt = `${header}.${claim}.${b64url(sig)}`;
  const resp = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt }),
  });
  const json = await resp.json();
  if (!json.access_token) throw new Error("FCM auth failed: " + JSON.stringify(json));
  return json.access_token;
}

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  if (req.headers.get("x-push-secret") !== Deno.env.get("PUSH_SECRET")) {
    return new Response("Unauthorized", { status: 401 });
  }

  const p = await req.json();
  const chatId: string = p.chat_id;
  const senderId: string = p.sender_id;
  const isCall = p.type === "call";

  // Получатели: участники чата, кроме отправителя
  const { data: members } = await admin.from("chat_members").select("user_id").eq("chat_id", chatId);
  const recipientIds = (members ?? []).map((m: any) => m.user_id).filter((id: string) => id !== senderId);
  if (recipientIds.length === 0) return new Response("no recipients");

  const { data: chat } = await admin.from("chats").select("family_id,title,kind").eq("id", chatId).single();
  const { data: sender } = await admin.from("family_members").select("display_name")
    .eq("family_id", chat?.family_id).eq("user_id", senderId).maybeSingle();
  const senderName = sender?.display_name || p.starter_name || "Участник";

  const { data: tokens } = await admin.from("device_tokens").select("token").in("user_id", recipientIds);
  if (!tokens || tokens.length === 0) return new Response("no tokens");

  let title: string;
  let body: string;
  if (isCall) {
    title = p.call_type === "video" ? "Входящий видеозвонок" : "Входящий аудиозвонок";
    body = `${senderName} зовёт вас в звонок`;
  } else {
    title = chat?.kind === "direct" ? senderName : (chat?.title || "NEXO Family");
    const t = p.message_type;
    const what = t === "photo" ? "отправил(а) фото" : t === "voice" ? "отправил(а) голосовое"
      : t === "file" ? "отправил(а) файл" : "новое сообщение";
    // Текст сообщений зашифрован на устройствах, поэтому сервер показывает только общий текст
    body = chat?.kind === "direct" ? what : `${senderName}: ${what}`;
  }

  const sa = JSON.parse(Deno.env.get("FCM_SERVICE_ACCOUNT")!);
  const accessToken = await getAccessToken(sa);
  const url = `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`;

  let sent = 0;
  for (const { token } of tokens) {
    const r = await fetch(url, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        message: {
          token,
          data: { title, body, chat_id: String(chatId), kind: isCall ? "call" : "message" },
          android: { priority: "HIGH" },
        },
      }),
    });
    if (r.ok) {
      sent++;
    } else {
      const err = await r.text();
      if (err.includes("UNREGISTERED") || err.includes("NOT_FOUND") || err.includes("INVALID_ARGUMENT")) {
        await admin.from("device_tokens").delete().eq("token", token);
      }
    }
  }
  return new Response(JSON.stringify({ sent }), { headers: { "Content-Type": "application/json" } });
});
