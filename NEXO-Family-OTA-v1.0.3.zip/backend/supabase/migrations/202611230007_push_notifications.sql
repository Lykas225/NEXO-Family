-- NEXO Family: Stage 10 — Push-уведомления (FCM) при закрытом приложении.
-- Выполните в Supabase SQL Editor ПОСЛЕ предыдущих миграций.

create extension if not exists pg_net with schema extensions;

-- 1. Токены устройств
create table if not exists public.device_tokens (
  token text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  platform text not null default 'android',
  updated_at timestamptz not null default now()
);
create index if not exists device_tokens_user_idx on public.device_tokens(user_id);
alter table public.device_tokens enable row level security;
-- Прямого доступа с клиента нет: только через RPC ниже и service role в Edge Function.

create or replace function public.register_device_token(p_token text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or p_token is null or length(p_token) < 20 then return; end if;
  insert into public.device_tokens(token, user_id, updated_at)
  values (p_token, auth.uid(), now())
  on conflict (token) do update set user_id = auth.uid(), updated_at = now();
end $$;

create or replace function public.unregister_device_token(p_token text)
returns void language plpgsql security definer set search_path = public as $$
begin
  delete from public.device_tokens where token = p_token and user_id = auth.uid();
end $$;

revoke all on function public.register_device_token(text) from public, anon;
revoke all on function public.unregister_device_token(text) from public, anon;
grant execute on function public.register_device_token(text) to authenticated;
grant execute on function public.unregister_device_token(text) to authenticated;

-- 2. Настройки вызова Edge Function (читаются только триггерами)
create table if not exists public.push_settings (
  id integer primary key default 1 check (id = 1),
  function_url text not null,
  secret text not null
);
alter table public.push_settings enable row level security;

-- 3. Триггеры: новое сообщение / новый звонок -> Edge Function push-notify
create or replace function public.push_dispatch(payload jsonb)
returns void language plpgsql security definer set search_path = public, extensions as $$
declare s public.push_settings;
begin
  select * into s from public.push_settings where id = 1;
  if s.function_url is null then return; end if;
  perform net.http_post(
    url := s.function_url,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', s.secret),
    body := payload
  );
exception when others then
  null; -- push никогда не должен ломать отправку сообщения/звонка
end $$;

create or replace function public.push_on_message()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.push_dispatch(jsonb_build_object(
    'type', 'message', 'chat_id', new.chat_id, 'sender_id', new.sender_id,
    'message_type', new.message_type, 'message_id', new.id));
  return new;
end $$;

create or replace function public.push_on_call()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.push_dispatch(jsonb_build_object(
    'type', 'call', 'chat_id', new.chat_id, 'sender_id', new.started_by,
    'call_type', new.call_type, 'starter_name', new.starter_name, 'call_id', new.id));
  return new;
end $$;

drop trigger if exists trg_push_on_message on public.messages;
create trigger trg_push_on_message after insert on public.messages
for each row execute function public.push_on_message();

drop trigger if exists trg_push_on_call on public.call_sessions;
create trigger trg_push_on_call after insert on public.call_sessions
for each row execute function public.push_on_call();

-- 4. ПОСЛЕ деплоя Edge Function выполните ОДИН раз (подставьте свои значения):
-- insert into public.push_settings(id, function_url, secret)
-- values (1, 'https://ВАШ_PROJECT_REF.supabase.co/functions/v1/push-notify', 'ПРИДУМАЙТЕ_ДЛИННЫЙ_СЕКРЕТ')
-- on conflict (id) do update set function_url = excluded.function_url, secret = excluded.secret;
