package com.nexo.family

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

 data class OtaUpdateInfo(
    val tag: String,
    val versionCode: Long,
    val notes: String,
    val downloadUrl: String
)

object OtaUpdater {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun check(context: Context): OtaUpdateInfo? = withContext(Dispatchers.IO) {
        val repo = BuildConfig.GITHUB_REPO.trim()
        if (!repo.matches(Regex("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))) return@withContext null
        try {
            val request = Request.Builder()
                .url("https://api.github.com/repos/$repo/releases/latest")
                .header("Accept", "application/vnd.github+json")
                .header("User-Agent", "NEXO-Family-Android")
                .build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val json = JSONObject(response.body?.string().orEmpty())
                val tag = json.optString("tag_name", "")
                val notes = json.optString("body", "Новые исправления и улучшения.")
                val assets = json.optJSONArray("assets") ?: return@withContext null
                var apkUrl: String? = null
                for (i in 0 until assets.length()) {
                    val asset = assets.optJSONObject(i) ?: continue
                    if (asset.optString("name") == "NEXO-Family.apk") {
                        apkUrl = asset.optString("browser_download_url")
                        break
                    }
                }
                val versionParts = Regex("v?(\\d+)\\.(\\d+)\\.(\\d+)").find(tag)
                val code = versionParts?.let {
                    val major = it.groupValues[1].toLong()
                    val minor = it.groupValues[2].toLong()
                    val patch = it.groupValues[3].toLong()
                    major * 1_000_000L + minor * 1_000L + patch
                } ?: 0L
                val installed = if (Build.VERSION.SDK_INT >= 28) {
                    context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    context.packageManager.getPackageInfo(context.packageName, 0).versionCode.toLong()
                }
                if (code > installed && !apkUrl.isNullOrBlank()) {
                    OtaUpdateInfo(tag, code, notes, apkUrl)
                } else null
            }
        } catch (_: Exception) { null }
    }

    suspend fun download(context: Context, info: OtaUpdateInfo): File? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(info.downloadUrl)
                .header("User-Agent", "NEXO-Family-Android").build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body ?: return@withContext null
                val dir = File(context.cacheDir, "updates").apply { mkdirs() }
                val apk = File(dir, "NEXO-Family-update.apk")
                body.byteStream().use { input -> apk.outputStream().use { output -> input.copyTo(output) } }
                if (apk.length() < 100_000) { apk.delete(); return@withContext null }
                apk
            }
        } catch (_: Exception) { null }
    }

    fun install(context: Context, apk: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", apk
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
