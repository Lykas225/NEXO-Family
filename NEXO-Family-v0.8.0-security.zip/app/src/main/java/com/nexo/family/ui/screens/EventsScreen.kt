package com.nexo.family.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.FamilyEvent
import com.nexo.family.model.FamilyTask
import com.nexo.family.model.ShoppingItem
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

private enum class EventsSubTab(val label: String) {
    CALENDAR("Календарь"),
    SHOPPING("Покупки"),
    TASKS("Задачи"),
    TOOLS("Инструменты")
}

@Composable
fun EventsScreen(
    events: List<FamilyEvent>,
    shoppingList: List<ShoppingItem>,
    tasks: List<FamilyTask>,
    locationSharingEnabled: Boolean,
    onToggleEventConfirm: (String) -> Unit,
    onToggleShopping: (String) -> Unit,
    onAddShopping: (String) -> Unit,
    onToggleTask: (String) -> Unit,
    onToggleLocationSharing: (Boolean) -> Unit
) {
    var activeSubTab by remember { mutableStateOf(EventsSubTab.CALENDAR) }
    var newProductText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(EventsSubTab.entries) { subTab ->
                    val selected = activeSubTab == subTab
                    FilterChip(
                        selected = selected,
                        onClick = { activeSubTab = subTab },
                        label = {
                            Text(
                                text = subTab.label,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NexoColors.TurquoiseDim,
                            selectedLabelColor = NexoColors.Turquoise,
                            containerColor = NexoColors.GraphiteCard,
                            labelColor = NexoColors.TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = NexoColors.CardBorder,
                            selectedBorderColor = NexoColors.Turquoise
                        )
                    )
                }
            }
        }

        when (activeSubTab) {
            EventsSubTab.CALENDAR -> {
                item { SectionLabel("Ближайшие события", "${events.size}") }
                items(events, key = { it.id }) { event ->
                    NexoCard {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.CalendarMonth, contentDescription = null, tint = NexoColors.Turquoise)
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(event.title, color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text("${event.dateLabel} • ${event.timeLabel}", color = NexoColors.Turquoise, fontSize = 12.sp)
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("Место: ${event.location}", color = NexoColors.TextSecondary, fontSize = 13.sp)
                            Text("Организатор: ${event.organizer} • Идут: ${event.confirmedCount}", color = NexoColors.TextSecondary, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { onToggleEventConfirm(event.id) },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (event.isConfirmedByMe) NexoColors.SuccessGreen.copy(alpha = 0.2f) else NexoColors.GraphiteElevated,
                                    contentColor = if (event.isConfirmedByMe) NexoColors.SuccessGreen else NexoColors.TextPrimary
                                )
                            ) {
                                Icon(
                                    imageVector = if (event.isConfirmedByMe) Icons.Rounded.CheckCircle else Icons.Rounded.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(if (event.isConfirmedByMe) "Участие подтверждено" else "Подтвердить участие", fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            EventsSubTab.SHOPPING -> {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newProductText,
                            onValueChange = { newProductText = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Добавить в список покупок…", color = NexoColors.TextSecondary, fontSize = 14.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = NexoColors.GraphiteCard,
                                unfocusedContainerColor = NexoColors.GraphiteCard,
                                focusedBorderColor = NexoColors.Turquoise,
                                unfocusedBorderColor = NexoColors.CardBorder,
                                focusedTextColor = NexoColors.TextPrimary,
                                unfocusedTextColor = NexoColors.TextPrimary
                            )
                        )
                        Spacer(Modifier.width(8.dp))
                        FilledIconButton(
                            onClick = {
                                onAddShopping(newProductText)
                                newProductText = ""
                            },
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = NexoColors.Turquoise,
                                contentColor = NexoColors.DeepNavy
                            )
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Добавить")
                        }
                    }
                }
                item { SectionLabel("Общий список покупок", "${shoppingList.count { !it.isBought }} осталось") }
                items(shoppingList, key = { it.id }) { item ->
                    NexoCard(onClick = { onToggleShopping(item.id) }) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = item.isBought,
                                onCheckedChange = { onToggleShopping(item.id) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = NexoColors.SuccessGreen,
                                    checkmarkColor = NexoColors.DeepNavy
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    color = if (item.isBought) NexoColors.TextSecondary else NexoColors.TextPrimary,
                                    textDecoration = if (item.isBought) TextDecoration.LineThrough else TextDecoration.None,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(item.category, color = NexoColors.TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            EventsSubTab.TASKS -> {
                item { SectionLabel("Семейные задачи", "${tasks.count { !it.isDone }} в работе") }
                items(tasks, key = { it.id }) { task ->
                    NexoCard(onClick = { onToggleTask(task.id) }) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (task.isDone) Icons.Rounded.TaskAlt else Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = if (task.isDone) NexoColors.SuccessGreen else NexoColors.TextSecondary
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.title,
                                    color = if (task.isDone) NexoColors.TextSecondary else NexoColors.TextPrimary,
                                    textDecoration = if (task.isDone) TextDecoration.LineThrough else TextDecoration.None,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp
                                )
                                Text("Ответственный: ${task.assignee} • до ${task.deadline}", color = NexoColors.TextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            EventsSubTab.TOOLS -> {
                item { SectionLabel("Семейные объявления") }
                item {
                    NexoCard(borderColor = NexoColors.Purple.copy(alpha = 0.45f)) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Campaign, contentDescription = null, tint = NexoColors.Purple, modifier = Modifier.size(26.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Закреплённое объявление", color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Spacer(Modifier.height(4.dp))
                                Text("В воскресенье встречаемся в 15:00. Подтвердите участие в календаре.", color = NexoColors.TextSecondary, fontSize = 13.sp)
                            }
                        }
                    }
                }
                item { SectionLabel("Добровольная геолокация") }
                item {
                    NexoCard {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.LocationOn, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(26.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Делиться местоположением", color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text("Только по вашему желанию, можно отключить в любой момент", color = NexoColors.TextSecondary, fontSize = 12.sp)
                            }
                            Switch(
                                checked = locationSharingEnabled,
                                onCheckedChange = onToggleLocationSharing,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = NexoColors.DeepNavy,
                                    checkedTrackColor = NexoColors.Turquoise
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
