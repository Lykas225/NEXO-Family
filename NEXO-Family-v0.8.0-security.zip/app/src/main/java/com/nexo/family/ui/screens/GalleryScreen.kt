package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.GalleryAlbum
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

@Composable
fun GalleryScreen(
    albums: List<GalleryAlbum>,
    onUploadClick: () -> Unit
) {
    val filters = listOf("Все альбомы", "Избранное", "Видео", "По датам")
    var selectedFilter by remember { mutableStateOf(filters.first()) }

    val displayed = when (selectedFilter) {
        "Избранное" -> albums.filter { it.isFavorite }
        else -> albums
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Семейная галерея", color = NexoColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Общие воспоминания и альбомы", color = NexoColors.TextSecondary, fontSize = 12.sp)
                }
                Button(
                    onClick = onUploadClick,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexoColors.Turquoise,
                        contentColor = NexoColors.DeepNavy
                    )
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Добавить", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filters) { filter ->
                    val selected = filter == selectedFilter
                    FilterChip(
                        selected = selected,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NexoColors.TurquoiseDim,
                            selectedLabelColor = NexoColors.Turquoise,
                            containerColor = NexoColors.GraphiteCard,
                            labelColor = NexoColors.TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = NexoColors.CardBorder,
                            selectedBorderColor = NexoColors.Turquoise
                        )
                    )
                }
            }
        }

        item { SectionLabel("Альбомы семьи", "${displayed.size}") }

        items(displayed, key = { it.id }) { album ->
            NexoCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.linearGradient(
                                    if (album.isPurpleAccent) {
                                        listOf(NexoColors.PurpleDim, NexoColors.Purple.copy(alpha = 0.55f))
                                    } else {
                                        listOf(NexoColors.TurquoiseDim, NexoColors.Turquoise.copy(alpha = 0.45f))
                                    }
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PhotoLibrary,
                            contentDescription = null,
                            tint = NexoColors.TextPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(album.title, color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            if (album.isFavorite) {
                                Spacer(Modifier.width(6.dp))
                                Icon(Icons.Rounded.Star, contentDescription = null, tint = NexoColors.WarningAmber, modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(Modifier.height(3.dp))
                        Text("${album.itemsCount} файлов • ${album.dateRange}", color = NexoColors.TextSecondary, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            color = NexoColors.GraphiteElevated,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Доступ: ${album.accessLabel}",
                                color = NexoColors.Turquoise,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = NexoColors.TextSecondary)
                }
            }
        }
    }
}
