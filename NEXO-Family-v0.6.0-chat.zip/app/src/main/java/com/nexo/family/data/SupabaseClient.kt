package com.nexo.family.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String, val code: Int = 0) : ApiResult<Nothing>()
}

data class AuthOutcome(
    val session: StoredSession?,
    val requiresEmailConfirmation: Boolean = false
)

data class RemoteFamilyMember(
    val userId: String,
    val displayName: String,
    val role: String,
    val joinedAt: String
)

data class RemoteChat(
    val id: String,
    val title: String,
    val kind: String,
    val lastMessage: String = "",
    val lastMessageAt: String = ""
)

data class RemoteMessage(
    val id: String,
    val chatId: String,
    val senderId: String,
    val senderName: String,
    val ciphertext: String,
    val messageType: String,
    val createdAt: String
)

data class RemoteInvite(
    val id: String,
    val expiresAt: String,
    val maxUses: Int,
    val uses: Int,
    val revokedAt: String?,
    val createdAt: String
)

data class CreatedInviteResult(
    val id: String,
    val code: String,
    val expiresAt: String
)

data class RemoteFamilyBundle(
    val familyId: String,
    val familyName: String,
    val memberLimit: Int,
    val myDisplayName: String,
    val myRole: String,
    val members: List<RemoteFamilyMember>,
    val chats: List<RemoteChat>
)

class SupabaseClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun signUp(config: ServerConfig, email: String, password: String): ApiResult<AuthOutcome> =
        withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject()
                    .put("email", email.trim())
                    .put("password", password)
                val req = Request.Builder()
                    .url("${config.url}/auth/v1/signup")
                    .addHeader("apikey", config.anonKey)
                    .addHeader("Content-Type", "application/json")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                http.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext ApiResult.Error(parseError(raw, "Ошибка регистрации (${resp.code})"), resp.code)
                    }
                    val obj = JSONObject(raw)
                    val accessToken = obj.optString("access_token", "")
                    val refreshToken = obj.optString("refresh_token", "")
                    val userObj = obj.optJSONObject("user")
                    val userId = userObj?.optString("id", "").orEmpty()
                    val userEmail = userObj?.optString("email", email).orEmpty()

                    if (accessToken.isNotEmpty() && refreshToken.isNotEmpty() && userId.isNotEmpty()) {
                        ApiResult.Success(
                            AuthOutcome(
                                session = StoredSession(accessToken, refreshToken, userId, userEmail),
                                requiresEmailConfirmation = false
                            )
                        )
                    } else {
                        ApiResult.Success(AuthOutcome(session = null, requiresEmailConfirmation = true))
                    }
                }
            } catch (e: Exception) {
                ApiResult.Error("Нет связи с сервером: ${e.localizedMessage ?: "ошибка сети"}")
            }
        }

    suspend fun signIn(config: ServerConfig, email: String, password: String): ApiResult<StoredSession> =
        withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject()
                    .put("email", email.trim())
                    .put("password", password)
                val req = Request.Builder()
                    .url("${config.url}/auth/v1/token?grant_type=password")
                    .addHeader("apikey", config.anonKey)
                    .addHeader("Content-Type", "application/json")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                http.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext ApiResult.Error(parseError(raw, "Неверный email или пароль"), resp.code)
                    }
                    parseSessionResponse(raw, email)
                }
            } catch (e: Exception) {
                ApiResult.Error("Нет связи с сервером: ${e.localizedMessage ?: "ошибка сети"}")
            }
        }

    suspend fun refreshSession(config: ServerConfig, refreshToken: String): ApiResult<StoredSession> =
        withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject().put("refresh_token", refreshToken)
                val req = Request.Builder()
                    .url("${config.url}/auth/v1/token?grant_type=refresh_token")
                    .addHeader("apikey", config.anonKey)
                    .addHeader("Content-Type", "application/json")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                http.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext ApiResult.Error(parseError(raw, "Сессия истекла"), resp.code)
                    }
                    parseSessionResponse(raw, "")
                }
            } catch (e: Exception) {
                ApiResult.Error("Ошибка сети при проверке сессии: ${e.localizedMessage ?: "нет связи"}")
            }
        }

    suspend fun signOut(config: ServerConfig, accessToken: String) = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("${config.url}/auth/v1/logout")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().close()
        } catch (_: Exception) {
        }
    }

    suspend fun createFamily(
        config: ServerConfig,
        accessToken: String,
        displayName: String,
        familyName: String
    ): ApiResult<String> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject()
                .put("p_display_name", displayName.trim())
                .put("p_family_name", familyName.trim())

            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/create_family_for_current_user")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Не удалось создать семью (${resp.code})"), resp.code)
                }
                val familyId = raw.trim().trim('"')
                if (familyId.isEmpty()) ApiResult.Error("Сервер не вернул ID семьи") else ApiResult.Success(familyId)
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети при создании семьи: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun createInvite(
        config: ServerConfig,
        accessToken: String,
        expiresHours: Int = 24
    ): ApiResult<CreatedInviteResult> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().put("p_expires_hours", expiresHours)
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/create_family_invite")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Не удалось создать приглашение (${resp.code})"), resp.code)
                }
                val obj = JSONObject(raw)
                ApiResult.Success(
                    CreatedInviteResult(
                        id = obj.optString("id", ""),
                        code = obj.optString("code", ""),
                        expiresAt = obj.optString("expires_at", "").take(16).replace("T", " ")
                    )
                )
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun listInvites(
        config: ServerConfig,
        accessToken: String
    ): ApiResult<List<RemoteInvite>> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/list_family_invites")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post("{}".toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Ошибка загрузки приглашений"), resp.code)
                }
                val arr = JSONArray(raw)
                val result = mutableListOf<RemoteInvite>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val revoked = if (obj.isNull("revoked_at")) null else obj.optString("revoked_at", "")
                    result.add(
                        RemoteInvite(
                            id = obj.optString("id", ""),
                            expiresAt = obj.optString("expires_at", "").take(16).replace("T", " "),
                            maxUses = obj.optInt("max_uses", 1),
                            uses = obj.optInt("uses", 0),
                            revokedAt = revoked?.ifEmpty { null },
                            createdAt = obj.optString("created_at", "").take(10)
                        )
                    )
                }
                ApiResult.Success(result)
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun revokeInvite(
        config: ServerConfig,
        accessToken: String,
        inviteId: String
    ): ApiResult<Boolean> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().put("p_invite_id", inviteId)
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/revoke_family_invite")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Не удалось отозвать приглашение"), resp.code)
                }
                ApiResult.Success(true)
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun redeemInvite(
        config: ServerConfig,
        accessToken: String,
        code: String,
        displayName: String
    ): ApiResult<String> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject()
                .put("p_code", code.trim())
                .put("p_display_name", displayName.trim())
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/redeem_family_invite")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Недействительный или использованный код"), resp.code)
                }
                ApiResult.Success(raw.trim().trim('"'))
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun updateMemberRole(
        config: ServerConfig,
        accessToken: String,
        targetUserId: String,
        newRole: String
    ): ApiResult<Boolean> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject()
                .put("p_target_user_id", targetUserId)
                .put("p_new_role", newRole)
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/update_family_member_role")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Не удалось изменить роль"), resp.code)
                }
                ApiResult.Success(true)
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun removeMember(
        config: ServerConfig,
        accessToken: String,
        targetUserId: String
    ): ApiResult<Boolean> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().put("p_target_user_id", targetUserId)
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/remove_family_member")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Не удалось удалить участника"), resp.code)
                }
                ApiResult.Success(true)
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }


    suspend fun listMyChatsWithPreview(
        config: ServerConfig,
        accessToken: String
    ): ApiResult<List<RemoteChat>> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/list_my_chats_with_preview")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post("{}".toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Ошибка загрузки чатов"), resp.code)
                }
                val arr = JSONArray(raw)
                val chats = mutableListOf<RemoteChat>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    chats.add(
                        RemoteChat(
                            id = obj.optString("id", ""),
                            title = obj.optString("title", "Чат"),
                            kind = obj.optString("kind", "family"),
                            lastMessage = obj.optString("last_message", ""),
                            lastMessageAt = obj.optString("last_message_at", "")
                        )
                    )
                }
                ApiResult.Success(chats)
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun getOrCreateDirectChat(
        config: ServerConfig,
        accessToken: String,
        otherUserId: String
    ): ApiResult<String> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().put("p_other_user_id", otherUserId)
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/get_or_create_direct_chat")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Не удалось открыть личный чат"), resp.code)
                }
                ApiResult.Success(raw.trim().trim('"'))
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun listChatMessages(
        config: ServerConfig,
        accessToken: String,
        chatId: String
    ): ApiResult<List<RemoteMessage>> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject()
                .put("p_chat_id", chatId)
                .put("p_limit", 100)
            val req = Request.Builder()
                .url("${config.url}/rest/v1/rpc/list_chat_messages")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Ошибка загрузки сообщений"), resp.code)
                }
                val arr = JSONArray(raw)
                val list = mutableListOf<RemoteMessage>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        RemoteMessage(
                            id = obj.optString("id", ""),
                            chatId = obj.optString("chat_id", chatId),
                            senderId = obj.optString("sender_id", ""),
                            senderName = obj.optString("sender_name", "Участник"),
                            ciphertext = obj.optString("ciphertext", ""),
                            messageType = obj.optString("message_type", "text"),
                            createdAt = obj.optString("created_at", "")
                        )
                    )
                }
                ApiResult.Success(list)
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun sendChatMessage(
        config: ServerConfig,
        accessToken: String,
        chatId: String,
        senderId: String,
        text: String
    ): ApiResult<Boolean> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject()
                .put("chat_id", chatId)
                .put("sender_id", senderId)
                .put("ciphertext", text.trim())
                .put("message_type", "text")
            val req = Request.Builder()
                .url("${config.url}/rest/v1/messages")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=minimal")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Не удалось отправить сообщение (${resp.code})"), resp.code)
                }
                ApiResult.Success(true)
            }
        } catch (e: Exception) {
            ApiResult.Error("Ошибка сети: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    suspend fun fetchMyFamilyBundle(
        config: ServerConfig,
        session: StoredSession
    ): ApiResult<RemoteFamilyBundle?> = withContext(Dispatchers.IO) {
        try {
            val membershipUrl =
                "${config.url}/rest/v1/family_members?select=family_id,display_name,role,joined_at&user_id=eq.${session.userId}&limit=1"
            val memReq = Request.Builder()
                .url(membershipUrl)
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer ${session.accessToken}")
                .get()
                .build()

            val membershipArray = http.newCall(memReq).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext ApiResult.Error(parseError(raw, "Ошибка загрузки профиля (${resp.code})"), resp.code)
                }
                JSONArray(raw)
            }

            if (membershipArray.length() == 0) {
                return@withContext ApiResult.Success(null)
            }

            val myRow = membershipArray.getJSONObject(0)
            val familyId = myRow.getString("family_id")
            val myDisplayName = myRow.optString("display_name", "Участник")
            val myRole = myRow.optString("role", "member")

            val familyReq = Request.Builder()
                .url("${config.url}/rest/v1/families?select=id,name,member_limit&id=eq.$familyId&limit=1")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer ${session.accessToken}")
                .get()
                .build()

            var familyName = "NEXO Family"
            var memberLimit = 20
            http.newCall(familyReq).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val arr = JSONArray(raw)
                    if (arr.length() > 0) {
                        val f = arr.getJSONObject(0)
                        familyName = f.optString("name", "NEXO Family")
                        memberLimit = f.optInt("member_limit", 20)
                    }
                }
            }

            val allMembersReq = Request.Builder()
                .url("${config.url}/rest/v1/family_members?select=user_id,display_name,role,joined_at&family_id=eq.$familyId&order=joined_at.asc")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer ${session.accessToken}")
                .get()
                .build()

            val members = mutableListOf<RemoteFamilyMember>()
            http.newCall(allMembersReq).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        members.add(
                            RemoteFamilyMember(
                                userId = obj.optString("user_id", ""),
                                displayName = obj.optString("display_name", "Участник"),
                                role = obj.optString("role", "member"),
                                joinedAt = obj.optString("joined_at", "").take(10)
                            )
                        )
                    }
                }
            }

            val chatsReq = Request.Builder()
                .url("${config.url}/rest/v1/chats?select=id,title,kind&family_id=eq.$familyId&order=created_at.asc")
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer ${session.accessToken}")
                .get()
                .build()

            val chats = mutableListOf<RemoteChat>()
            http.newCall(chatsReq).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        chats.add(
                            RemoteChat(
                                id = obj.optString("id", ""),
                                title = obj.optString("title", "Чат"),
                                kind = obj.optString("kind", "family")
                            )
                        )
                    }
                }
            }

            ApiResult.Success(
                RemoteFamilyBundle(
                    familyId = familyId,
                    familyName = familyName,
                    memberLimit = memberLimit,
                    myDisplayName = myDisplayName,
                    myRole = myRole,
                    members = members,
                    chats = chats
                )
            )
        } catch (e: Exception) {
            ApiResult.Error("Ошибка загрузки семьи: ${e.localizedMessage ?: "нет связи"}")
        }
    }

    private fun parseSessionResponse(raw: String, fallbackEmail: String): ApiResult<StoredSession> {
        val obj = JSONObject(raw)
        val accessToken = obj.optString("access_token", "")
        val refreshToken = obj.optString("refresh_token", "")
        val userObj = obj.optJSONObject("user")
        val userId = userObj?.optString("id", "").orEmpty()
        val email = userObj?.optString("email", fallbackEmail).orEmpty()
        return if (accessToken.isNotEmpty() && refreshToken.isNotEmpty() && userId.isNotEmpty()) {
            ApiResult.Success(StoredSession(accessToken, refreshToken, userId, email))
        } else {
            ApiResult.Error("Сервер вернул неполную сессию")
        }
    }

    private fun parseError(raw: String, fallback: String): String {
        return try {
            val obj = JSONObject(raw)
            obj.optString("msg")
                .ifEmpty { obj.optString("error_description") }
                .ifEmpty { obj.optString("error") }
                .ifEmpty { obj.optString("message") }
                .ifEmpty { fallback }
        } catch (_: Exception) {
            fallback
        }
    }
}
