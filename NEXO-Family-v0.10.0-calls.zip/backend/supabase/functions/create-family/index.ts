import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

Deno.serve(async (request: Request): Promise<Response> => {
  if (request.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }

  const authorization = request.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) {
    return jsonResponse({ error: "Authentication required" }, 401);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const publicKey = Deno.env.get("SUPABASE_ANON_KEY") ??
    Deno.env.get("SUPABASE_PUBLISHABLE_KEY");

  if (!supabaseUrl || !publicKey) {
    console.error("create-family is missing Supabase URL or public key configuration");
    return jsonResponse({ error: "Server configuration error" }, 500);
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonResponse({ error: "Invalid JSON body" }, 400);
  }

  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    return jsonResponse({ error: "Invalid request body" }, 400);
  }

  const input = body as Record<string, unknown>;
  const displayName = typeof input.displayName === "string"
    ? input.displayName.trim()
    : "";
  const familyName = typeof input.familyName === "string"
    ? input.familyName.trim()
    : "NEXO Family";

  if (displayName.length < 1 || displayName.length > 60) {
    return jsonResponse({ error: "displayName must contain 1 to 60 characters" }, 400);
  }
  if (familyName.length < 1 || familyName.length > 80) {
    return jsonResponse({ error: "familyName must contain 1 to 80 characters" }, 400);
  }

  const accessToken = authorization.slice("Bearer ".length);
  const supabase = createClient(supabaseUrl, publicKey, {
    global: { headers: { Authorization: authorization } },
    auth: {
      autoRefreshToken: false,
      persistSession: false,
      detectSessionInUrl: false,
    },
  });

  const { data: userData, error: authError } = await supabase.auth.getUser(accessToken);
  if (authError || !userData.user) {
    return jsonResponse({ error: "Invalid or expired session" }, 401);
  }

  const { data: familyId, error: rpcError } = await supabase.rpc(
    "create_family_for_current_user",
    {
      p_display_name: displayName,
      p_family_name: familyName,
    },
  );

  if (rpcError) {
    if (rpcError.code === "23505") {
      return jsonResponse({ error: "This account already owns a family group" }, 409);
    }
    if (rpcError.code === "22023") {
      return jsonResponse({ error: "Invalid family details" }, 400);
    }
    console.error("create-family RPC failed", rpcError.code ?? "unknown error");
    return jsonResponse({ error: "Could not create family group" }, 500);
  }

  return jsonResponse({ familyId }, 201);
});
