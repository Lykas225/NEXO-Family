-- NEXO Family: Stage 3 — One-time invites (SHA-256 hashed), atomic redemption with 20-member cap, and role management.
-- Run in Supabase SQL Editor after schema.sql and 202611220001_create_family_rpc.sql.

create or replace function public.create_family_invite(
  p_expires_hours integer default 24
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_role text;
  v_member_count integer;
  v_member_limit integer;
  v_hours integer := greatest(1, least(coalesce(p_expires_hours, 24), 168));
  v_raw_hex text;
  v_code text;
  v_token_hash text;
  v_invite_id uuid;
  v_expires_at timestamptz := now() + make_interval(hours => v_hours);
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  select fm.family_id, fm.role
    into v_family_id, v_role
  from public.family_members as fm
  where fm.user_id = v_user_id
  limit 1;

  if v_family_id is null or v_role not in ('owner', 'admin') then
    raise exception using errcode = '42501', message = 'Only owner or admin can create invites';
  end if;

  select f.member_count, f.member_limit
    into v_member_count, v_member_limit
  from public.families as f
  where f.id = v_family_id;

  if v_member_count >= v_member_limit then
    raise exception using errcode = '23514', message = 'Family member limit (20) reached';
  end if;

  v_raw_hex := upper(encode(extensions.gen_random_bytes(5), 'hex'));
  v_code := 'NEXO-' || substr(v_raw_hex, 1, 5) || '-' || substr(v_raw_hex, 6, 5);
  v_token_hash := encode(extensions.digest(v_code, 'sha256'), 'hex');

  insert into public.invites (family_id, token_hash, created_by, expires_at, max_uses, uses)
  values (v_family_id, v_token_hash, v_user_id, v_expires_at, 1, 0)
  returning id into v_invite_id;

  return jsonb_build_object(
    'id', v_invite_id,
    'code', v_code,
    'expires_at', v_expires_at
  );
end;
$function$;

create or replace function public.list_family_invites()
returns table (
  id uuid,
  expires_at timestamptz,
  max_uses integer,
  uses integer,
  revoked_at timestamptz,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_role text;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  select fm.family_id, fm.role
    into v_family_id, v_role
  from public.family_members as fm
  where fm.user_id = v_user_id
  limit 1;

  if v_family_id is null or v_role not in ('owner', 'admin') then
    return;
  end if;

  return query
  select i.id, i.expires_at, i.max_uses, i.uses, i.revoked_at, i.created_at
  from public.invites as i
  where i.family_id = v_family_id
  order by i.created_at desc
  limit 20;
end;
$function$;

create or replace function public.revoke_family_invite(p_invite_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_role text;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  select fm.family_id, fm.role
    into v_family_id, v_role
  from public.family_members as fm
  where fm.user_id = v_user_id
  limit 1;

  if v_family_id is null or v_role not in ('owner', 'admin') then
    raise exception using errcode = '42501', message = 'Only owner or admin can revoke invites';
  end if;

  update public.invites
     set revoked_at = now()
   where id = p_invite_id
     and family_id = v_family_id
     and revoked_at is null;

  return found;
end;
$function$;

create or replace function public.redeem_family_invite(
  p_code text,
  p_display_name text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_code text := upper(pg_catalog.btrim(coalesce(p_code, '')));
  v_display_name text := pg_catalog.btrim(coalesce(p_display_name, ''));
  v_token_hash text;
  v_invite record;
  v_family_chat_id uuid;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  if v_code = '' then
    raise exception using errcode = '22023', message = 'Invite code is required';
  end if;

  if v_display_name = '' or pg_catalog.char_length(v_display_name) > 60 then
    raise exception using errcode = '22023', message = 'Display name must contain 1 to 60 characters';
  end if;

  if exists (select 1 from public.family_members as fm where fm.user_id = v_user_id) then
    raise exception using errcode = '23505', message = 'You are already a member of a family group';
  end if;

  v_token_hash := encode(extensions.digest(v_code, 'sha256'), 'hex');

  select *
    into v_invite
  from public.invites as i
  where i.token_hash = v_token_hash
  for update;

  if not found then
    raise exception using errcode = 'P0002', message = 'Invalid invite code';
  end if;

  if v_invite.revoked_at is not null then
    raise exception using errcode = '22023', message = 'Invite code has been revoked';
  end if;

  if v_invite.expires_at <= now() then
    raise exception using errcode = '22023', message = 'Invite code has expired';
  end if;

  if v_invite.uses >= v_invite.max_uses then
    raise exception using errcode = '22023', message = 'Invite code has already been used';
  end if;

  -- Insert member (trigger family_members_count_guard atomically enforces the 20-member cap)
  insert into public.family_members (family_id, user_id, display_name, role)
  values (v_invite.family_id, v_user_id, v_display_name, 'member');

  -- Mark invite as used
  update public.invites
     set uses = uses + 1
   where id = v_invite.id;

  -- Add member to the main family chat
  select c.id
    into v_family_chat_id
  from public.chats as c
  where c.family_id = v_invite.family_id
    and c.kind = 'family'
  order by c.created_at asc
  limit 1;

  if v_family_chat_id is not null then
    insert into public.chat_members (chat_id, user_id)
    values (v_family_chat_id, v_user_id)
    on conflict do nothing;
  end if;

  return v_invite.family_id;
end;
$function$;

create or replace function public.update_family_member_role(
  p_target_user_id uuid,
  p_new_role text
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_my_role text;
  v_target_role text;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  if p_new_role not in ('admin', 'member') then
    raise exception using errcode = '22023', message = 'Role must be admin or member';
  end if;

  select fm.family_id, fm.role
    into v_family_id, v_my_role
  from public.family_members as fm
  where fm.user_id = v_user_id
  limit 1;

  if v_family_id is null or v_my_role <> 'owner' then
    raise exception using errcode = '42501', message = 'Only the family owner can change roles';
  end if;

  select fm.role
    into v_target_role
  from public.family_members as fm
  where fm.family_id = v_family_id and fm.user_id = p_target_user_id;

  if v_target_role is null or v_target_role = 'owner' then
    raise exception using errcode = '42501', message = 'Cannot change owner role';
  end if;

  update public.family_members
     set role = p_new_role
   where family_id = v_family_id and user_id = p_target_user_id;

  return found;
end;
$function$;

create or replace function public.remove_family_member(p_target_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_my_role text;
  v_target_role text;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  select fm.family_id, fm.role
    into v_family_id, v_my_role
  from public.family_members as fm
  where fm.user_id = v_user_id
  limit 1;

  if v_family_id is null or v_my_role not in ('owner', 'admin') then
    raise exception using errcode = '42501', message = 'Insufficient permissions';
  end if;

  if p_target_user_id = v_user_id then
    raise exception using errcode = '42501', message = 'Cannot remove yourself';
  end if;

  select fm.role
    into v_target_role
  from public.family_members as fm
  where fm.family_id = v_family_id and fm.user_id = p_target_user_id;

  if v_target_role is null or v_target_role = 'owner' then
    raise exception using errcode = '42501', message = 'Cannot remove the family owner';
  end if;

  if v_my_role = 'admin' and v_target_role = 'admin' then
    raise exception using errcode = '42501', message = 'Admins cannot remove other admins';
  end if;

  delete from public.chat_members as cm
  using public.chats as c
  where cm.chat_id = c.id
    and c.family_id = v_family_id
    and cm.user_id = p_target_user_id;

  delete from public.family_members
   where family_id = v_family_id
     and user_id = p_target_user_id;

  return found;
end;
$function$;

revoke all on function public.create_family_invite(integer) from public, anon;
grant execute on function public.create_family_invite(integer) to authenticated;

revoke all on function public.list_family_invites() from public, anon;
grant execute on function public.list_family_invites() to authenticated;

revoke all on function public.revoke_family_invite(uuid) from public, anon;
grant execute on function public.revoke_family_invite(uuid) to authenticated;

revoke all on function public.redeem_family_invite(text, text) from public, anon;
grant execute on function public.redeem_family_invite(text, text) to authenticated;

revoke all on function public.update_family_member_role(uuid, text) from public, anon;
grant execute on function public.update_family_member_role(uuid, text) to authenticated;

revoke all on function public.remove_family_member(uuid) from public, anon;
grant execute on function public.remove_family_member(uuid) to authenticated;
