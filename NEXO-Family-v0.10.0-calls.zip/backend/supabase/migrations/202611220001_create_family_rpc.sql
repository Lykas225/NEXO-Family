-- NEXO Family: secure, atomic family creation and a database-enforced 20-member cap.
-- Apply after backend/supabase/schema.sql in the same Supabase project.

-- One account may own only one NEXO family group.
create unique index if not exists families_one_owned_group_per_owner_idx
  on public.families (owner_id);

-- Keep the counter in the parent row so concurrent joins cannot exceed the cap.
alter table public.families
  add column if not exists member_count integer not null default 0;

update public.families as f
set member_count = (
  select pg_catalog.count(*)::integer
  from public.family_members as fm
  where fm.family_id = f.id
);

do $migration$
begin
  if not exists (
    select 1
    from pg_catalog.pg_constraint
    where conname = 'families_member_count_range_check'
      and conrelid = 'public.families'::pg_catalog.regclass
  ) then
    alter table public.families
      add constraint families_member_count_range_check
      check (member_count >= 0 and member_count <= member_limit);
  end if;
end;
$migration$;

-- Harden the existing RLS helpers against search_path substitution.
create or replace function public.is_family_member(target_family uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $function$
  select exists (
    select 1
    from public.family_members as fm
    where fm.family_id = target_family
      and fm.user_id = auth.uid()
  );
$function$;

create or replace function public.is_chat_member(target_chat uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $function$
  select exists (
    select 1
    from public.chat_members as cm
    where cm.chat_id = target_chat
      and cm.user_id = auth.uid()
  );
$function$;

-- Atomically reserve/release one member slot by updating the family row.
-- UPDATE ... WHERE member_count < member_limit is safe under concurrent joins.
create or replace function public.adjust_family_member_count()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  if tg_op = 'INSERT' then
    update public.families
       set member_count = member_count + 1
     where id = new.family_id
       and member_count < member_limit;

    if not found then
      raise exception using
        errcode = '23514',
        message = 'Family member limit reached or family does not exist';
    end if;

    return new;
  elsif tg_op = 'DELETE' then
    update public.families
       set member_count = greatest(member_count - 1, 0)
     where id = old.family_id;

    return old;
  end if;

  return null;
end;
$function$;

drop trigger if exists family_members_count_guard on public.family_members;
create trigger family_members_count_guard
before insert or delete on public.family_members
for each row execute function public.adjust_family_member_count();

-- Create the family, owner membership and initial family chat in one transaction.
create or replace function public.create_family_for_current_user(
  p_display_name text,
  p_family_name text default 'NEXO Family'
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_display_name text := pg_catalog.btrim(coalesce(p_display_name, ''));
  v_family_name text := pg_catalog.btrim(coalesce(p_family_name, 'NEXO Family'));
  v_family_id uuid;
  v_family_chat_id uuid;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  if v_display_name = '' or pg_catalog.char_length(v_display_name) > 60 then
    raise exception using errcode = '22023', message = 'Display name must contain 1 to 60 characters';
  end if;

  if v_family_name = '' or pg_catalog.char_length(v_family_name) > 80 then
    raise exception using errcode = '22023', message = 'Family name must contain 1 to 80 characters';
  end if;

  -- Serialize simultaneous create requests for the same authenticated account.
  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(v_user_id::text, 0)
  );

  if exists (
    select 1 from public.families as f where f.owner_id = v_user_id
  ) then
    raise exception using errcode = '23505', message = 'This account already owns a family group';
  end if;

  insert into public.families (name, owner_id, member_limit)
  values (v_family_name, v_user_id, 20)
  returning id into v_family_id;

  insert into public.family_members (family_id, user_id, display_name, role)
  values (v_family_id, v_user_id, v_display_name, 'owner');

  insert into public.chats (family_id, title, kind)
  values (v_family_id, 'Семейный чат', 'family')
  returning id into v_family_chat_id;

  insert into public.chat_members (chat_id, user_id)
  values (v_family_chat_id, v_user_id);

  return v_family_id;
end;
$function$;

-- Only authenticated clients may call the RPC. The trigger function is not an API.
revoke all on function public.is_family_member(uuid) from public, anon;
revoke all on function public.is_chat_member(uuid) from public, anon;
grant execute on function public.is_family_member(uuid) to authenticated;
grant execute on function public.is_chat_member(uuid) to authenticated;

revoke all on function public.adjust_family_member_count() from public, anon, authenticated;
revoke all on function public.create_family_for_current_user(text, text) from public, anon;
grant execute on function public.create_family_for_current_user(text, text) to authenticated;

-- Prevent client-side writes around the trusted creation/join flows.
revoke insert, update, delete on table public.families from anon, authenticated;
revoke insert, update, delete on table public.family_members from anon, authenticated;
revoke insert, update, delete on table public.invites from anon, authenticated;

comment on column public.families.member_count is
  'Maintained by family_members_count_guard; never set directly from the Android client.';
comment on function public.create_family_for_current_user(text, text) is
  'Atomically creates one family group, owner membership and the initial family chat for auth.uid().';
