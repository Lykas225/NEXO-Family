-- NEXO Family: Stage 7 — Shared Events, Shopping List, Tasks, and Family Gallery.
-- Run in Supabase SQL Editor after Stage 1-5 migrations.

create table if not exists public.family_events (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  title text not null,
  date_label text not null default 'Скоро',
  time_label text not null default '18:00',
  location text not null default 'Дом',
  organizer_name text not null default 'Семья',
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.family_event_rsvps (
  event_id uuid not null references public.family_events(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (event_id, user_id)
);

create table if not exists public.shopping_items (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  title text not null,
  category text not null default 'Семейное',
  is_bought boolean not null default false,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.family_tasks (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  title text not null,
  assignee text not null default 'Семья',
  deadline text not null default 'На этой неделе',
  is_done boolean not null default false,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.gallery_photos (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  album_name text not null default 'Семейные встречи',
  storage_path text not null,
  caption text not null default '',
  uploaded_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.family_events enable row level security;
alter table public.family_event_rsvps enable row level security;
alter table public.shopping_items enable row level security;
alter table public.family_tasks enable row level security;
alter table public.gallery_photos enable row level security;

-- Events policies
drop policy if exists "family members manage events" on public.family_events;
create policy "family members manage events"
on public.family_events for all
to authenticated
using (public.is_family_member(family_id))
with check (public.is_family_member(family_id));

-- Event RSVPs policies
drop policy if exists "family members view rsvps" on public.family_event_rsvps;
create policy "family members view rsvps"
on public.family_event_rsvps for select
to authenticated
using (
  exists (
    select 1 from public.family_events as e
    where e.id = event_id and public.is_family_member(e.family_id)
  )
);

drop policy if exists "family members toggle own rsvp" on public.family_event_rsvps;
create policy "family members toggle own rsvp"
on public.family_event_rsvps for insert
to authenticated
with check (
  user_id = auth.uid()
  and exists (
    select 1 from public.family_events as e
    where e.id = event_id and public.is_family_member(e.family_id)
  )
);

drop policy if exists "family members delete own rsvp" on public.family_event_rsvps;
create policy "family members delete own rsvp"
on public.family_event_rsvps for delete
to authenticated
using (user_id = auth.uid());

-- Shopping policies
drop policy if exists "family members manage shopping" on public.shopping_items;
create policy "family members manage shopping"
on public.shopping_items for all
to authenticated
using (public.is_family_member(family_id))
with check (public.is_family_member(family_id));

-- Tasks policies
drop policy if exists "family members manage tasks" on public.family_tasks;
create policy "family members manage tasks"
on public.family_tasks for all
to authenticated
using (public.is_family_member(family_id))
with check (public.is_family_member(family_id));

-- Gallery photos policies
drop policy if exists "family members manage gallery" on public.gallery_photos;
create policy "family members manage gallery"
on public.gallery_photos for all
to authenticated
using (public.is_family_member(family_id))
with check (public.is_family_member(family_id));

-- Private Storage bucket for Family Gallery
insert into storage.buckets (id, name, public, file_size_limit)
values ('family-gallery', 'family-gallery', false, 26214400)
on conflict (id) do update
  set public = false,
      file_size_limit = 26214400;

drop policy if exists "family members can upload gallery photos" on storage.objects;
create policy "family members can upload gallery photos"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'family-gallery'
  and public.is_family_member((storage.foldername(name))[1]::uuid)
);

drop policy if exists "family members can read gallery photos" on storage.objects;
create policy "family members can read gallery photos"
on storage.objects for select
to authenticated
using (
  bucket_id = 'family-gallery'
  and public.is_family_member((storage.foldername(name))[1]::uuid)
);
