-- NEXO Family: restrict chat visibility strictly to chat members so direct chats remain private.
drop policy if exists "members can view chats" on public.chats;

create policy "chat members can view their chats"
on public.chats for select
using (public.is_chat_member(id));
