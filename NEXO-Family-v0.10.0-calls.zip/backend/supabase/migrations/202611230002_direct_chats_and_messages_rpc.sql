-- NEXO Family: Stage 4 — Direct 1-on-1 chats, chat list with last message preview, and message loading.
-- Run in Supabase SQL Editor after Stage 1-3 migrations.

create or replace function public.get_or_create_direct_chat(
  p_other_user_id uuid
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_other_family_id uuid;
  v_chat_id uuid;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  if p_other_user_id is null or p_other_user_id = v_user_id then
    raise exception using errcode = '22023', message = 'Invalid recipient';
  end if;

  select fm.family_id into v_family_id
  from public.family_members as fm
  where fm.user_id = v_user_id
  limit 1;

  select fm.family_id into v_other_family_id
  from public.family_members as fm
  where fm.user_id = p_other_user_id
  limit 1;

  if v_family_id is null or v_family_id <> v_other_family_id then
    raise exception using errcode = '42501', message = 'Users must belong to the same family';
  end if;

  -- Check if a direct chat already exists between these two users
  select c.id into v_chat_id
  from public.chats as c
  join public.chat_members as cm1 on cm1.chat_id = c.id and cm1.user_id = v_user_id
  join public.chat_members as cm2 on cm2.chat_id = c.id and cm2.user_id = p_other_user_id
  where c.family_id = v_family_id
    and c.kind = 'direct'
  limit 1;

  if v_chat_id is not null then
    return v_chat_id;
  end if;

  insert into public.chats (family_id, title, kind)
  values (v_family_id, 'Личный чат', 'direct')
  returning id into v_chat_id;

  insert into public.chat_members (chat_id, user_id)
  values (v_chat_id, v_user_id), (v_chat_id, p_other_user_id)
  on conflict do nothing;

  return v_chat_id;
end;
$function$;

create or replace function public.list_my_chats_with_preview()
returns table (
  id uuid,
  title text,
  kind text,
  last_message text,
  last_message_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  return query
  select
    c.id,
    case
      when c.kind = 'direct' then coalesce(
        (
          select fm.display_name
          from public.chat_members as cm_other
          join public.family_members as fm
            on fm.family_id = c.family_id and fm.user_id = cm_other.user_id
          where cm_other.chat_id = c.id
            and cm_other.user_id <> v_user_id
          limit 1
        ),
        c.title
      )
      else c.title
    end as title,
    c.kind,
    coalesce(
      (
        select m.ciphertext
        from public.messages as m
        where m.chat_id = c.id and m.deleted_at is null
        order by m.created_at desc
        limit 1
      ),
      ''
    ) as last_message,
    coalesce(
      (
        select m.created_at
        from public.messages as m
        where m.chat_id = c.id and m.deleted_at is null
        order by m.created_at desc
        limit 1
      ),
      c.created_at
    ) as last_message_at
  from public.chats as c
  join public.chat_members as cm on cm.chat_id = c.id and cm.user_id = v_user_id
  order by (c.kind = 'family') desc, last_message_at desc;
end;
$function$;

create or replace function public.list_chat_messages(
  p_chat_id uuid,
  p_limit integer default 100
)
returns table (
  id uuid,
  chat_id uuid,
  sender_id uuid,
  sender_name text,
  ciphertext text,
  message_type text,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
  v_lim integer := greatest(1, least(coalesce(p_limit, 100), 200));
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  if not public.is_chat_member(p_chat_id) then
    raise exception using errcode = '42501', message = 'Not a member of this chat';
  end if;

  return query
  select
    sub.id,
    sub.chat_id,
    sub.sender_id,
    sub.sender_name,
    sub.ciphertext,
    sub.message_type,
    sub.created_at
  from (
    select
      m.id,
      m.chat_id,
      m.sender_id,
      coalesce(fm.display_name, 'Участник') as sender_name,
      m.ciphertext,
      m.message_type,
      m.created_at
    from public.messages as m
    join public.chats as c on c.id = m.chat_id
    left join public.family_members as fm
      on fm.family_id = c.family_id and fm.user_id = m.sender_id
    where m.chat_id = p_chat_id
      and m.deleted_at is null
    order by m.created_at desc
    limit v_lim
  ) as sub
  order by sub.created_at asc;
end;
$function$;

revoke all on function public.get_or_create_direct_chat(uuid) from public, anon;
grant execute on function public.get_or_create_direct_chat(uuid) to authenticated;

revoke all on function public.list_my_chats_with_preview() from public, anon;
grant execute on function public.list_my_chats_with_preview() to authenticated;

revoke all on function public.list_chat_messages(uuid, integer) from public, anon;
grant execute on function public.list_chat_messages(uuid, integer) to authenticated;
