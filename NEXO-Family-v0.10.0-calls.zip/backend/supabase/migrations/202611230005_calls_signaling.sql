-- NEXO Family: Stage 8 — Audio & Video Call Signaling.
-- Run in Supabase SQL Editor after Stage 1-7 migrations.

create table if not exists public.call_sessions (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references public.chats(id) on delete cascade,
  family_id uuid not null references public.families(id) on delete cascade,
  started_by uuid not null references auth.users(id) on delete cascade,
  starter_name text not null default 'Участник',
  call_type text not null check (call_type in ('audio', 'video')),
  room_code text not null,
  status text not null default 'active' check (status in ('active', 'ended')),
  created_at timestamptz not null default now(),
  ended_at timestamptz
);

create index if not exists call_sessions_family_status_idx
  on public.call_sessions(family_id, status, created_at desc);

alter table public.call_sessions enable row level security;

drop policy if exists "chat members can view call sessions" on public.call_sessions;
create policy "chat members can view call sessions"
on public.call_sessions for select
to authenticated
using (public.is_chat_member(chat_id));

drop policy if exists "chat members can start call sessions" on public.call_sessions;
create policy "chat members can start call sessions"
on public.call_sessions for insert
to authenticated
with check (
  started_by = auth.uid()
  and public.is_chat_member(chat_id)
);

drop policy if exists "chat members can update call sessions" on public.call_sessions;
create policy "chat members can update call sessions"
on public.call_sessions for update
to authenticated
using (public.is_chat_member(chat_id))
with check (public.is_chat_member(chat_id));
