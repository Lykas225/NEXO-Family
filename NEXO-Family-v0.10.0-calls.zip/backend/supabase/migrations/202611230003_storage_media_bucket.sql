-- NEXO Family: Stage 5 — Private Supabase Storage bucket for chat photos, files, and voice messages.
-- Run in Supabase SQL Editor after Stage 1-4 migrations.

insert into storage.buckets (id, name, public, file_size_limit)
values ('chat-media', 'chat-media', false, 26214400)
on conflict (id) do update
  set public = false,
      file_size_limit = 26214400;

drop policy if exists "chat members can upload chat media" on storage.objects;
create policy "chat members can upload chat media"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'chat-media'
  and public.is_chat_member((storage.foldername(name))[1]::uuid)
);

drop policy if exists "chat members can read chat media" on storage.objects;
create policy "chat members can read chat media"
on storage.objects for select
to authenticated
using (
  bucket_id = 'chat-media'
  and public.is_chat_member((storage.foldername(name))[1]::uuid)
);

-- Update chat list preview so media messages show friendly labels instead of JSON
create or replace function public.list_my_chats_with_preview()
returns table (
  id uuid,
  title text,
  kind text,
  last_message text,
  last_message_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication required';
  end if;

  return query
  select
    c.id,
    case
      when c.kind = 'direct' then coalesce(
        (
          select fm.display_name
          from public.chat_members as cm_other
          join public.family_members as fm
            on fm.family_id = c.family_id and fm.user_id = cm_other.user_id
          where cm_other.chat_id = c.id
            and cm_other.user_id <> v_user_id
          limit 1
        ),
        c.title
      )
      else c.title
    end as title,
    c.kind,
    coalesce(
      (
        select
          case m.message_type
            when 'photo' then '📷 Фото'
            when 'voice' then '🎤 Голосовое сообщение'
            when 'file' then '📎 Файл'
            else m.ciphertext
          end
        from public.messages as m
        where m.chat_id = c.id and m.deleted_at is null
        order by m.created_at desc
        limit 1
      ),
      ''
    ) as last_message,
    coalesce(
      (
        select m.created_at
        from public.messages as m
        where m.chat_id = c.id and m.deleted_at is null
        order by m.created_at desc
        limit 1
      ),
      c.created_at
    ) as last_message_at
  from public.chats as c
  join public.chat_members as cm on cm.chat_id = c.id and cm.user_id = v_user_id
  order by (c.kind = 'family') desc, last_message_at desc;
end;
$function$;
