-- NEXO Family: initial Supabase schema
-- Run in a NEW private Supabase project. Review policies before production.
create extension if not exists pgcrypto;

create table if not exists public.families (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'NEXO Family',
  owner_id uuid not null references auth.users(id) on delete cascade,
  member_limit integer not null default 20 check (member_limit = 20),
  created_at timestamptz not null default now()
);
create table if not exists public.family_members (
  family_id uuid not null references public.families(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  role text not null default 'member' check (role in ('owner','admin','member')),
  joined_at timestamptz not null default now(),
  primary key (family_id, user_id)
);
create table if not exists public.invites (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  token_hash text not null unique,
  created_by uuid not null references auth.users(id),
  expires_at timestamptz not null,
  max_uses integer not null default 1,
  uses integer not null default 0,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.chats (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  title text not null,
  kind text not null check (kind in ('family','direct')),
  created_at timestamptz not null default now()
);
create table if not exists public.chat_members (
  chat_id uuid not null references public.chats(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (chat_id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references public.chats(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  ciphertext text not null,
  message_type text not null default 'text',
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted_at timestamptz
);
create index if not exists messages_chat_created_idx on public.messages(chat_id, created_at desc);

-- SECURITY DEFINER helpers avoid recursive RLS policies.
create or replace function public.is_family_member(target_family uuid)
returns boolean language sql stable security definer
set search_path = public
as $$ select exists (
  select 1 from public.family_members
  where family_id = target_family and user_id = auth.uid()
); $$;

create or replace function public.is_chat_member(target_chat uuid)
returns boolean language sql stable security definer
set search_path = public
as $$ select exists (
  select 1 from public.chat_members
  where chat_id = target_chat and user_id = auth.uid()
); $$;

alter table public.families enable row level security;
alter table public.family_members enable row level security;
alter table public.invites enable row level security;
alter table public.chats enable row level security;
alter table public.chat_members enable row level security;
alter table public.messages enable row level security;

create policy "members can view their family"
on public.families for select
using (public.is_family_member(id));

create policy "members can view family members"
on public.family_members for select
using (public.is_family_member(family_id));

create policy "members can view chats"
on public.chats for select
using (public.is_family_member(family_id));

create policy "chat members can view membership"
on public.chat_members for select
using (public.is_chat_member(chat_id));

create policy "chat members can read messages"
on public.messages for select
using (public.is_chat_member(chat_id));

create policy "chat members can send messages as themselves"
on public.messages for insert
with check (sender_id = auth.uid() and public.is_chat_member(chat_id));

-- Deliberately no client-side INSERT policies for families/members/invites.
-- Implement trusted Edge Functions for family creation and invite redemption.
-- They must hash invite tokens, enforce expiry/uses, and enforce the 20-member
-- cap inside one database transaction. Never put the service-role key in Android.
