package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.theme.NexoColors

@Composable
fun CreateFamilyScreen(
    userEmail: String,
    isLoading: Boolean,
    errorMessage: String?,
    onCreateFamily: (displayName: String, familyName: String) -> Unit,
    onRedeemInvite: (code: String, displayName: String) -> Unit,
    onRefreshCheck: () -> Unit,
    onSignOut: () -> Unit
) {
    var displayName by remember { mutableStateOf("") }
    var familyName by remember { mutableStateOf("NEXO Family") }
    var inviteCode by remember { mutableStateOf("") }
    var joinDisplayName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Добро пожаловать", color = NexoColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(userEmail, color = NexoColors.Turquoise, fontSize = 13.sp, maxLines = 1)
            }
            TextButton(onClick = onSignOut) {
                Text("Выйти", color = NexoColors.DangerRed, maxLines = 1, softWrap = false)
            }
        }

        if (!errorMessage.isNullOrBlank()) {
            Surface(
                color = NexoColors.DangerRed.copy(alpha = 0.14f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = errorMessage,
                    color = NexoColors.DangerRed,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        // Card 1: Join by Invite Code
        NexoCard(borderColor = NexoColors.Purple.copy(alpha = 0.5f)) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(NexoColors.PurpleDim),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.QrCode, contentDescription = null, tint = NexoColors.Purple)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Вступить по приглашению", color = NexoColors.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Одноразовый код от владельца семьи", color = NexoColors.TextSecondary, fontSize = 12.sp)
                    }
                }

                OutlinedTextField(
                    value = inviteCode,
                    onValueChange = { inviteCode = it.uppercase() },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Код приглашения") },
                    placeholder = { Text("NEXO-XXXXX-XXXXX", color = NexoColors.TextSecondary) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                OutlinedTextField(
                    value = joinDisplayName,
                    onValueChange = { if (it.length <= 60) joinDisplayName = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Ваше имя в семье") },
                    placeholder = { Text("Например: Мама", color = NexoColors.TextSecondary) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                Button(
                    onClick = { onRedeemInvite(inviteCode, joinDisplayName) },
                    enabled = !isLoading && inviteCode.trim().length >= 8 && joinDisplayName.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexoColors.Purple,
                        contentColor = NexoColors.TextPrimary
                    )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.5.dp, color = NexoColors.TextPrimary)
                    } else {
                        Text("Вступить в семью", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }

        // Card 2: Create New Family
        NexoCard(borderColor = NexoColors.Turquoise.copy(alpha = 0.45f)) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(Brush.linearGradient(listOf(NexoColors.Turquoise, NexoColors.Purple))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Groups, contentDescription = null, tint = NexoColors.DeepNavy)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Создать новую семью", color = NexoColors.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("До 20 участников • Вы станете владельцем", color = NexoColors.TextSecondary, fontSize = 12.sp)
                    }
                }

                OutlinedTextField(
                    value = displayName,
                    onValueChange = { if (it.length <= 60) displayName = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Ваше имя в семье") },
                    placeholder = { Text("Например: Алексей", color = NexoColors.TextSecondary) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                OutlinedTextField(
                    value = familyName,
                    onValueChange = { if (it.length <= 80) familyName = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Название семьи") },
                    placeholder = { Text("NEXO Family", color = NexoColors.TextSecondary) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                Button(
                    onClick = { onCreateFamily(displayName, familyName) },
                    enabled = !isLoading && displayName.isNotBlank() && familyName.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexoColors.Turquoise,
                        contentColor = NexoColors.DeepNavy
                    )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.5.dp, color = NexoColors.DeepNavy)
                    } else {
                        Text("Создать семью", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }

        OutlinedButton(
            onClick = onRefreshCheck,
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Проверить статус семьи")
        }
    }
}
