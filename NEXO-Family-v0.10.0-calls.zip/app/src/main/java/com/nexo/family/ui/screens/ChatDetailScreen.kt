package com.nexo.family.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.nexo.family.data.VoiceMediaHelper
import com.nexo.family.model.ChatMessage
import com.nexo.family.model.ChatPreview
import com.nexo.family.model.MessageKind
import com.nexo.family.ui.components.NexoAvatar
import com.nexo.family.ui.theme.NexoColors
import kotlinx.coroutines.delay

@Composable
fun ChatDetailScreen(
    chat: ChatPreview,
    messages: List<ChatMessage>,
    mediaCache: Map<String, ByteArray>,
    playingVoiceId: String?,
    voicePlaybackSpeed: Float,
    isUploadingMedia: Boolean,
    voiceHelper: VoiceMediaHelper,
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit,
    onSendPhoto: (Uri) -> Unit,
    onSendFile: (Uri) -> Unit,
    onSendVoice: (ByteArray, String) -> Unit,
    onToggleVoicePlay: (ChatMessage) -> Unit,
    onCycleVoiceSpeed: () -> Unit,
    onOpenFile: (ChatMessage) -> Unit,
    onCallClick: () -> Unit,
    onVideoCallClick: () -> Unit
) {
    val context = LocalContext.current
    var draft by remember { mutableStateOf("") }
    var showAttachDialog by remember { mutableStateOf(false) }
    var isRecording by remember { mutableStateOf(false) }
    var recordSeconds by remember { mutableIntStateOf(0) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onSendPhoto(uri)
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onSendFile(uri)
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            if (voiceHelper.startRecording()) {
                recordSeconds = 0
                isRecording = true
            }
        }
    }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            while (isRecording) {
                delay(1000)
                recordSeconds += 1
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            if (isRecording) {
                voiceHelper.stopRecording(deleteFile = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
    ) {
        // Chat Top Bar
        Surface(color = NexoColors.SurfaceBar) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Назад",
                            tint = NexoColors.TextPrimary
                        )
                    }
                    NexoAvatar(
                        initials = chat.initials,
                        accentColor = chat.accentColor,
                        size = 42.dp,
                        isOnline = chat.isOnline
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = chat.title,
                            color = NexoColors.TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (chat.isFamilyChat) "Общий семейный чат" else "Личная переписка",
                            color = if (chat.isOnline) NexoColors.SuccessGreen else NexoColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onCallClick) {
                        Icon(Icons.Rounded.Call, contentDescription = "Аудиозвонок", tint = NexoColors.Turquoise)
                    }
                    IconButton(onClick = onVideoCallClick) {
                        Icon(Icons.Rounded.Videocam, contentDescription = "Видеозвонок", tint = NexoColors.Purple)
                    }
                }
                HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.55f))
            }
        }

        if (isUploadingMedia) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = NexoColors.Turquoise,
                trackColor = NexoColors.GraphiteCard
            )
        }

        val listState = rememberLazyListState()
        LaunchedEffect(messages.size) {
            if (messages.isNotEmpty()) {
                listState.animateScrollToItem(messages.size - 1)
            }
        }

        // Messages list
        if (messages.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Сообщений пока нет. Напишите первым!",
                    color = NexoColors.TextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    MessageBubbleItem(
                        msg = msg,
                        showSender = chat.isFamilyChat && !msg.isMine,
                        cachedBytes = msg.mediaPath?.let { mediaCache[it] },
                        isPlayingVoice = playingVoiceId == msg.id,
                        playbackSpeed = voicePlaybackSpeed,
                        onToggleVoicePlay = { onToggleVoicePlay(msg) },
                        onCycleVoiceSpeed = onCycleVoiceSpeed,
                        onOpenFile = { onOpenFile(msg) }
                    )
                }
            }
        }

        // Input Bar or Voice Recording Bar
        Surface(color = NexoColors.SurfaceBar) {
            Column {
                HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.55f))
                if (isRecording) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(NexoColors.DangerRed)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = "Запись: %d:%02d".format(recordSeconds / 60, recordSeconds % 60),
                                color = NexoColors.TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = {
                                isRecording = false
                                voiceHelper.stopRecording(deleteFile = true)
                            }) {
                                Text("Отмена", color = NexoColors.DangerRed)
                            }
                            Button(
                                onClick = {
                                    isRecording = false
                                    val result = voiceHelper.stopRecording(deleteFile = false)
                                    if (result != null) {
                                        onSendVoice(result.first, result.second)
                                    }
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NexoColors.Turquoise,
                                    contentColor = NexoColors.DeepNavy
                                )
                            ) {
                                Text("Отправить", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .imePadding()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showAttachDialog = true }) {
                            Icon(Icons.Rounded.AttachFile, contentDescription = "Вложение", tint = NexoColors.TextSecondary)
                        }
                        OutlinedTextField(
                            value = draft,
                            onValueChange = { draft = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Сообщение…", color = NexoColors.TextSecondary, fontSize = 14.sp) },
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = NexoColors.GraphiteCard,
                                unfocusedContainerColor = NexoColors.GraphiteCard,
                                focusedBorderColor = NexoColors.Turquoise,
                                unfocusedBorderColor = NexoColors.CardBorder,
                                focusedTextColor = NexoColors.TextPrimary,
                                unfocusedTextColor = NexoColors.TextPrimary
                            )
                        )
                        Spacer(Modifier.width(8.dp))
                        if (draft.isBlank()) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(NexoColors.PurpleDim),
                                contentAlignment = Alignment.Center
                            ) {
                                IconButton(onClick = {
                                    val hasPerm = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.RECORD_AUDIO
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasPerm) {
                                        if (voiceHelper.startRecording()) {
                                            recordSeconds = 0
                                            isRecording = true
                                        }
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }) {
                                    Icon(Icons.Rounded.Mic, contentDescription = "Голосовое", tint = NexoColors.Purple)
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(NexoColors.Turquoise),
                                contentAlignment = Alignment.Center
                            ) {
                                IconButton(onClick = {
                                    onSendMessage(draft)
                                    draft = ""
                                }) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.Send,
                                        contentDescription = "Отправить",
                                        tint = NexoColors.DeepNavy
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAttachDialog) {
        AlertDialog(
            onDismissRequest = { showAttachDialog = false },
            containerColor = NexoColors.GraphiteCard,
            shape = RoundedCornerShape(22.dp),
            title = {
                Text("Отправить вложение", color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            showAttachDialog = false
                            photoPicker.launch("image/*")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexoColors.Turquoise,
                            contentColor = NexoColors.DeepNavy
                        )
                    ) {
                        Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Фото из галереи", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            showAttachDialog = false
                            filePicker.launch("*/*")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Rounded.Description, contentDescription = null, tint = NexoColors.Purple, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Файл (PDF, документ, архив)", color = NexoColors.TextPrimary)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAttachDialog = false }) {
                    Text("Отмена", color = NexoColors.TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun MessageBubbleItem(
    msg: ChatMessage,
    showSender: Boolean,
    cachedBytes: ByteArray?,
    isPlayingVoice: Boolean,
    playbackSpeed: Float,
    onToggleVoicePlay: () -> Unit,
    onCycleVoiceSpeed: () -> Unit,
    onOpenFile: () -> Unit
) {
    val bubbleColor = if (msg.isMine) NexoColors.TurquoiseDim else NexoColors.GraphiteCard
    val bubbleShape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = if (msg.isMine) 18.dp else 4.dp,
        bottomEnd = if (msg.isMine) 4.dp else 18.dp
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isMine) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 295.dp)
                .clip(bubbleShape)
                .background(bubbleColor)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            if (showSender) {
                Text(
                    text = msg.senderName,
                    color = NexoColors.Turquoise,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(3.dp))
            }

            when (msg.kind) {
                MessageKind.PHOTO -> {
                    val bitmap = remember(cachedBytes) {
                        cachedBytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
                    }
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap,
                            contentDescription = msg.mediaName ?: "Фото",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 140.dp, max = 240.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(220.dp, 140.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NexoColors.GraphiteElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = NexoColors.Turquoise, strokeWidth = 2.dp)
                        }
                    }
                }

                MessageKind.FILE -> {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexoColors.GraphiteElevated.copy(alpha = 0.65f))
                            .clickable { onOpenFile() }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Description, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f, fill = false)) {
                            Text(
                                text = msg.mediaName ?: "Документ",
                                color = NexoColors.TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text("Нажмите, чтобы открыть", color = NexoColors.Turquoise, fontSize = 11.sp)
                        }
                    }
                }

                MessageKind.VOICE -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(NexoColors.Purple.copy(alpha = 0.25f))
                                .clickable { onToggleVoicePlay() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlayingVoice) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = "Воспроизвести",
                                tint = NexoColors.Purple
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = msg.voiceDuration ?: "0:05",
                                    color = NexoColors.TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(Modifier.width(10.dp))
                                Surface(
                                    color = NexoColors.GraphiteElevated,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.clickable { onCycleVoiceSpeed() }
                                ) {
                                    val speedLabel = if (playbackSpeed == 1.0f) "1×" else if (playbackSpeed == 1.5f) "1.5×" else "2×"
                                    Text(
                                        text = speedLabel,
                                        color = NexoColors.Turquoise,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = if (isPlayingVoice) "Воспроизводится…" else "Голосовое сообщение",
                                color = NexoColors.TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                MessageKind.TEXT -> {
                    Text(
                        text = msg.text,
                        color = NexoColors.TextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.align(Alignment.End),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = msg.time,
                    color = NexoColors.TextSecondary,
                    fontSize = 10.sp
                )
                if (msg.isMine) {
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        imageVector = if (msg.isRead) Icons.Rounded.DoneAll else Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = if (msg.isRead) NexoColors.SuccessGreen else NexoColors.TextSecondary,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}
