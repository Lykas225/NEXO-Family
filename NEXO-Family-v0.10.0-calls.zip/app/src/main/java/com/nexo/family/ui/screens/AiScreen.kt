package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.AiChatItem
import com.nexo.family.model.AiTool
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

@Composable
fun AiScreen(
    tools: List<AiTool>,
    messages: List<AiChatItem>,
    onSendPrompt: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                NexoCard(
                    borderColor = NexoColors.Purple.copy(alpha = 0.5f),
                    containerColor = NexoColors.PurpleDim.copy(alpha = 0.35f)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(NexoColors.Purple, NexoColors.Turquoise)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = NexoColors.DeepNavy, modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("NEXO AI • Семейный помощник", color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = "Не читает личные чаты без вашего выбора • Серверный AI Gateway",
                                color = NexoColors.TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            item { SectionLabel("Быстрые сценарии") }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(tools, key = { it.id }) { tool ->
                        NexoCard(
                            modifier = Modifier.width(195.dp),
                            onClick = { onSendPrompt(tool.samplePrompt) }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = NexoColors.Purple, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.height(8.dp))
                                Text(tool.title, color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Spacer(Modifier.height(3.dp))
                                Text(tool.subtitle, color = NexoColors.TextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            item { SectionLabel("Диалог с помощником") }

            items(messages, key = { it.id }) { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (item.isUser) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 300.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (item.isUser) NexoColors.PurpleDim else NexoColors.GraphiteCard)
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(item.text, color = NexoColors.TextPrimary, fontSize = 14.sp, lineHeight = 20.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(item.time, color = NexoColors.TextSecondary, fontSize = 10.sp, modifier = Modifier.align(Alignment.End))
                        }
                    }
                }
            }
        }

        // AI input bar
        Surface(color = NexoColors.SurfaceBar) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Спросить NEXO AI…", color = NexoColors.TextSecondary, fontSize = 14.sp) },
                    shape = RoundedCornerShape(22.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = NexoColors.GraphiteCard,
                        unfocusedContainerColor = NexoColors.GraphiteCard,
                        focusedBorderColor = NexoColors.Purple,
                        unfocusedBorderColor = NexoColors.CardBorder,
                        focusedTextColor = NexoColors.TextPrimary,
                        unfocusedTextColor = NexoColors.TextPrimary
                    )
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(NexoColors.Purple),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = {
                            onSendPrompt(input)
                            input = ""
                        },
                        enabled = input.isNotBlank()
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Отправить", tint = NexoColors.TextPrimary)
                    }
                }
            }
        }
    }
}
