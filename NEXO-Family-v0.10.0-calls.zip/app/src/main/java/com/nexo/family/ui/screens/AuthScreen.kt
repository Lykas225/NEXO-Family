package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.theme.NexoColors

@Composable
fun AuthScreen(
    supabaseUrl: String,
    supabaseAnonKey: String,
    isServerConfigured: Boolean,
    isLoading: Boolean,
    errorMessage: String?,
    noticeMessage: String?,
    onSaveServerConfig: (String, String) -> Unit,
    onSignIn: (String, String) -> Unit,
    onSignUp: (String, String) -> Unit
) {
    var isRegisterMode by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }

    var showServerConfig by remember { mutableStateOf(!isServerConfigured) }
    var urlInput by remember(supabaseUrl) { mutableStateOf(supabaseUrl) }
    var keyInput by remember(supabaseAnonKey) { mutableStateOf(supabaseAnonKey) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(8.dp))

        // Brand Header
        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(NexoColors.Turquoise, NexoColors.Purple))),
                contentAlignment = Alignment.Center
            ) {
                Text("N", color = NexoColors.DeepNavy, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("NEXO Family", color = NexoColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Связь семьи. Общие моменты. Личное пространство.", color = NexoColors.TextSecondary, fontSize = 12.sp)
            }
        }

        // Server Config Card
        NexoCard(
            borderColor = if (isServerConfigured) NexoColors.SuccessGreen.copy(alpha = 0.4f) else NexoColors.WarningAmber.copy(alpha = 0.5f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isServerConfigured) Icons.Rounded.CloudDone else Icons.Rounded.CloudOff,
                            contentDescription = null,
                            tint = if (isServerConfigured) NexoColors.SuccessGreen else NexoColors.WarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (isServerConfigured) "Supabase подключён" else "Настройте сервер Supabase",
                            color = NexoColors.TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                    TextButton(onClick = { showServerConfig = !showServerConfig }) {
                        Text(
                            text = if (showServerConfig) "Скрыть" else "Изменить",
                            color = NexoColors.Turquoise,
                            fontSize = 12.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                if (showServerConfig) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Supabase Project URL") },
                        placeholder = { Text("https://xxxxx.supabase.co", color = NexoColors.TextSecondary) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Anon / Publishable Key") },
                        placeholder = { Text("eyJ... или sb_publishable_...", color = NexoColors.TextSecondary) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Вводите только публичный anon/publishable key. Серверный service_role key запрещено использовать в приложении.",
                        color = NexoColors.TextSecondary,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            onSaveServerConfig(urlInput, keyInput)
                            showServerConfig = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexoColors.GraphiteElevated,
                            contentColor = NexoColors.Turquoise
                        )
                    ) {
                        Text("Сохранить параметры сервера", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Auth Card
        NexoCard {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = !isRegisterMode,
                        onClick = { isRegisterMode = false },
                        label = { Text("Вход") },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NexoColors.TurquoiseDim,
                            selectedLabelColor = NexoColors.Turquoise
                        )
                    )
                    FilterChip(
                        selected = isRegisterMode,
                        onClick = { isRegisterMode = true },
                        label = { Text("Регистрация") },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NexoColors.PurpleDim,
                            selectedLabelColor = NexoColors.Purple
                        )
                    )
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Email") },
                    leadingIcon = { Icon(Icons.Rounded.Email, contentDescription = null, tint = NexoColors.TextSecondary) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Пароль (от 6 символов)") },
                    leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, tint = NexoColors.TextSecondary) },
                    trailingIcon = {
                        IconButton(onClick = { showPassword = !showPassword }) {
                            Icon(
                                imageVector = if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = null,
                                tint = NexoColors.TextSecondary
                            )
                        }
                    },
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                if (!errorMessage.isNullOrBlank()) {
                    Surface(
                        color = NexoColors.DangerRed.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = errorMessage,
                            color = NexoColors.DangerRed,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                if (!noticeMessage.isNullOrBlank()) {
                    Surface(
                        color = NexoColors.SuccessGreen.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = noticeMessage,
                            color = NexoColors.SuccessGreen,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                Button(
                    onClick = {
                        if (isRegisterMode) onSignUp(email, password) else onSignIn(email, password)
                    },
                    enabled = !isLoading && isServerConfigured && email.isNotBlank() && password.length >= 6,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRegisterMode) NexoColors.Purple else NexoColors.Turquoise,
                        contentColor = if (isRegisterMode) NexoColors.TextPrimary else NexoColors.DeepNavy
                    )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp,
                            color = NexoColors.DeepNavy
                        )
                    } else {
                        Text(
                            text = if (isRegisterMode) "Создать аккаунт" else "Войти в NEXO Family",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}
