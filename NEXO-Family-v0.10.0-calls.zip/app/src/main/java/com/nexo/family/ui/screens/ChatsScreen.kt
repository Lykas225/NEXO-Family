package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.ChatPreview
import com.nexo.family.ui.components.NexoAvatar
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

@Composable
fun ChatsScreen(
    chats: List<ChatPreview>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onChatClick: (String) -> Unit
) {
    val filtered = if (searchQuery.isBlank()) {
        chats
    } else {
        chats.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                it.lastMessage.contains(searchQuery, ignoreCase = true)
        }
    }
    val pinned = filtered.filter { it.isPinned }
    val others = filtered.filterNot { it.isPinned }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text("Поиск по чатам и сообщениям", color = NexoColors.TextSecondary, fontSize = 14.sp)
                },
                leadingIcon = {
                    Icon(Icons.Rounded.Search, contentDescription = null, tint = NexoColors.TextSecondary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Очистить", tint = NexoColors.TextSecondary)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = NexoColors.GraphiteCard,
                    unfocusedContainerColor = NexoColors.GraphiteCard,
                    focusedBorderColor = NexoColors.Turquoise,
                    unfocusedBorderColor = NexoColors.CardBorder,
                    focusedTextColor = NexoColors.TextPrimary,
                    unfocusedTextColor = NexoColors.TextPrimary
                )
            )
        }

        val missedCount = chats.count { it.hasMissedCall }
        if (missedCount > 0 && searchQuery.isBlank()) {
            item {
                NexoCard(
                    containerColor = NexoColors.DangerRed.copy(alpha = 0.12f),
                    borderColor = NexoColors.DangerRed.copy(alpha = 0.35f),
                    onClick = {
                        chats.firstOrNull { it.hasMissedCall }?.let { onChatClick(it.id) }
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(NexoColors.DangerRed.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.PhoneMissed, contentDescription = null, tint = NexoColors.DangerRed, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Пропущенный вызов", color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("Мама • сегодня в 09:15", color = NexoColors.TextSecondary, fontSize = 12.sp)
                        }
                        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = NexoColors.TextSecondary)
                    }
                }
            }
        }

        if (pinned.isNotEmpty()) {
            item { SectionLabel("Закреплённые", "${pinned.size}") }
            items(pinned, key = { it.id }) { chat ->
                ChatRowCard(chat = chat, onClick = { onChatClick(chat.id) })
            }
        }

        if (others.isNotEmpty()) {
            item { SectionLabel("Личные беседы", "${others.size}") }
            items(others, key = { it.id }) { chat ->
                ChatRowCard(chat = chat, onClick = { onChatClick(chat.id) })
            }
        }

        item {
            Spacer(Modifier.height(4.dp))
            NexoCard(
                containerColor = NexoColors.TurquoiseDim.copy(alpha = 0.35f),
                borderColor = NexoColors.Turquoise.copy(alpha = 0.3f)
            ) {
                Row(
                    modifier = Modifier.padding(15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Личное семейное пространство",
                            color = NexoColors.TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "Только приглашённые близкие • без рекламы и открытых чатов",
                            color = NexoColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatRowCard(
    chat: ChatPreview,
    onClick: () -> Unit
) {
    NexoCard(onClick = onClick) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NexoAvatar(
                initials = chat.initials,
                accentColor = chat.accentColor,
                size = 54.dp,
                isOnline = chat.isOnline
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = chat.title,
                        color = NexoColors.TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (chat.isFamilyChat) {
                        Spacer(Modifier.width(6.dp))
                        Surface(
                            color = NexoColors.TurquoiseDim,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Семья",
                                color = NexoColors.Turquoise,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (chat.isPinned) {
                        Spacer(Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Rounded.PushPin,
                            contentDescription = "Закреплён",
                            tint = NexoColors.TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = chat.lastMessage,
                    color = if (chat.hasMissedCall) NexoColors.DangerRed else NexoColors.TextSecondary,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = chat.time,
                    color = if (chat.unreadCount > 0) NexoColors.Turquoise else NexoColors.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = if (chat.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal
                )
                Spacer(Modifier.height(8.dp))
                if (chat.unreadCount > 0) {
                    Box(
                        modifier = Modifier
                            .defaultMinSize(minWidth = 22.dp, minHeight = 22.dp)
                            .clip(CircleShape)
                            .background(NexoColors.Turquoise)
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = chat.unreadCount.toString(),
                            color = NexoColors.DeepNavy,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Icon(
                        imageVector = Icons.Rounded.DoneAll,
                        contentDescription = "Прочитано",
                        tint = NexoColors.SuccessGreen,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
