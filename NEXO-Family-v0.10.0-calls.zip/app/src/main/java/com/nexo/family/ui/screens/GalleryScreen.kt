package com.nexo.family.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.GalleryPhoto
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

@Composable
fun GalleryScreen(
    photos: List<GalleryPhoto>,
    galleryCache: Map<String, ByteArray>,
    isUploading: Boolean,
    onUploadPhoto: (Uri, String) -> Unit,
    onRefresh: () -> Unit
) {
    val albums = listOf("Все фото", "Семейные встречи", "Поездки", "Праздники")
    var selectedAlbum by remember { mutableStateOf(albums.first()) }

    val targetAlbumForUpload = if (selectedAlbum == "Все фото") "Семейные встречи" else selectedAlbum
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onUploadPhoto(uri, targetAlbumForUpload)
    }

    val displayed = if (selectedAlbum == "Все фото") {
        photos
    } else {
        photos.filter { it.albumName == selectedAlbum }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Семейная галерея", color = NexoColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Общие фотоальбомы в облаке", color = NexoColors.TextSecondary, fontSize = 12.sp)
                }
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Обновить", tint = NexoColors.Turquoise)
                }
                Button(
                    onClick = { photoPicker.launch("image/*") },
                    enabled = !isUploading,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexoColors.Turquoise,
                        contentColor = NexoColors.DeepNavy
                    )
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Фото", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        if (isUploading) {
            item {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = NexoColors.Turquoise,
                    trackColor = NexoColors.GraphiteCard
                )
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(albums) { album ->
                    val selected = album == selectedAlbum
                    FilterChip(
                        selected = selected,
                        onClick = { selectedAlbum = album },
                        label = { Text(album) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NexoColors.TurquoiseDim,
                            selectedLabelColor = NexoColors.Turquoise,
                            containerColor = NexoColors.GraphiteCard,
                            labelColor = NexoColors.TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = NexoColors.CardBorder,
                            selectedBorderColor = NexoColors.Turquoise
                        )
                    )
                }
            }
        }

        item { SectionLabel("Фотографии семьи", "${displayed.size}") }

        if (displayed.isEmpty()) {
            item {
                NexoCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(40.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("В этом альбоме пока нет фото", color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text("Нажмите «+ Фото», чтобы загрузить первое воспоминание", color = NexoColors.TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            val rows = displayed.chunked(2)
            items(rows) { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pair.forEach { photo ->
                        val bytes = galleryCache[photo.storagePath]
                        val bitmap = remember(bytes) {
                            bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
                        }
                        NexoCard(modifier = Modifier.weight(1f)) {
                            Column {
                                if (bitmap != null) {
                                    Image(
                                        bitmap = bitmap,
                                        contentDescription = photo.albumName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(150.dp)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(150.dp)
                                            .background(NexoColors.GraphiteElevated),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(modifier = Modifier.size(22.dp), color = NexoColors.Turquoise, strokeWidth = 2.dp)
                                    }
                                }
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(photo.albumName, color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1)
                                    Text("${photo.caption.ifBlank { "Семья" }} • ${photo.createdAt}", color = NexoColors.TextSecondary, fontSize = 10.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                    if (pair.size == 1) {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
