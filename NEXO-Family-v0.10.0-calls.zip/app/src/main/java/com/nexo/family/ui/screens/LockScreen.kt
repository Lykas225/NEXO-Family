package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.ui.theme.NexoColors

@Composable
fun LockScreen(
    pinEnabled: Boolean,
    biometricEnabled: Boolean,
    onVerifyPin: (String) -> Boolean,
    onUnlockSuccess: () -> Unit,
    onTriggerBiometric: () -> Unit
) {
    var enteredPin by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(biometricEnabled) {
        if (biometricEnabled) {
            onTriggerBiometric()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(24.dp))
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(NexoColors.Turquoise, NexoColors.Purple))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Lock, contentDescription = null, tint = NexoColors.DeepNavy, modifier = Modifier.size(34.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("NEXO Family защищён", color = NexoColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                text = if (pinEnabled) "Введите 4-значный PIN-код" else "Подтвердите вход биометрией",
                color = NexoColors.TextSecondary,
                fontSize = 14.sp
            )

            if (pinEnabled) {
                Spacer(Modifier.height(28.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    repeat(4) { idx ->
                        val filled = idx < enteredPin.length
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(if (filled) NexoColors.Turquoise else NexoColors.GraphiteElevated)
                        )
                    }
                }
            }

            if (errorText != null) {
                Spacer(Modifier.height(14.dp))
                Text(errorText!!, color = NexoColors.DangerRed, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        if (pinEnabled) {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9")
                )
                rows.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                        row.forEach { digit ->
                            PinKeyButton(label = digit) {
                                if (enteredPin.length < 4) {
                                    errorText = null
                                    val next = enteredPin + digit
                                    enteredPin = next
                                    if (next.length == 4) {
                                        if (onVerifyPin(next)) {
                                            onUnlockSuccess()
                                        } else {
                                            errorText = "Неверный PIN-код"
                                            enteredPin = ""
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (biometricEnabled) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(NexoColors.PurpleDim)
                                .clickable { onTriggerBiometric() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Fingerprint, contentDescription = "Биометрия", tint = NexoColors.Purple, modifier = Modifier.size(32.dp))
                        }
                    } else {
                        Spacer(Modifier.size(72.dp))
                    }

                    PinKeyButton(label = "0") {
                        if (enteredPin.length < 4) {
                            errorText = null
                            val next = enteredPin + "0"
                            enteredPin = next
                            if (next.length == 4) {
                                if (onVerifyPin(next)) {
                                    onUnlockSuccess()
                                } else {
                                    errorText = "Неверный PIN-код"
                                    enteredPin = ""
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(NexoColors.GraphiteCard)
                            .clickable {
                                if (enteredPin.isNotEmpty()) {
                                    enteredPin = enteredPin.dropLast(1)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Backspace, contentDescription = "Удалить", tint = NexoColors.TextSecondary)
                    }
                }
            }
        } else {
            Button(
                onClick = onTriggerBiometric,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NexoColors.Turquoise,
                    contentColor = NexoColors.DeepNavy
                )
            ) {
                Icon(Icons.Rounded.Fingerprint, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text("Разблокировать по отпечатку / лицу", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun PinKeyButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(NexoColors.GraphiteCard)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = NexoColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
    }
}
