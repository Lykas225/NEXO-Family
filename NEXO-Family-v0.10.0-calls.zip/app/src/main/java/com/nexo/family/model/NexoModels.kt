package com.nexo.family.model

import androidx.compose.ui.graphics.Color

enum class AppGate {
    CHECKING_SESSION,
    AUTH,
    CREATE_FAMILY,
    MAIN
}

enum class NexoTab(val title: String) {
    CHATS("Чаты"),
    FAMILY("Семья"),
    EVENTS("События"),
    GALLERY("Галерея"),
    AI("ИИ")
}

enum class MemberRole(val label: String) {
    OWNER("Владелец"),
    ADMIN("Админ"),
    MEMBER("Участник")
}

enum class MessageKind {
    TEXT,
    VOICE,
    PHOTO,
    FILE
}

data class ChatPreview(
    val id: String,
    val title: String,
    val lastMessage: String,
    val time: String,
    val unreadCount: Int = 0,
    val initials: String,
    val accentColor: Color,
    val isFamilyChat: Boolean = false,
    val isPinned: Boolean = false,
    val isOnline: Boolean = false,
    val hasMissedCall: Boolean = false
)

data class ChatMessage(
    val id: String,
    val chatId: String,
    val senderName: String,
    val text: String,
    val time: String,
    val isMine: Boolean,
    val isRead: Boolean = true,
    val kind: MessageKind = MessageKind.TEXT,
    val voiceDuration: String? = null,
    val mediaPath: String? = null,
    val mediaName: String? = null,
    val mediaMime: String? = null
)

data class FamilyMember(
    val id: String,
    val name: String,
    val role: MemberRole,
    val isOnline: Boolean,
    val status: String,
    val joinedDate: String,
    val initials: String,
    val avatarColor: Color,
    val isCurrentUser: Boolean = false
)

data class FamilyInvite(
    val id: String,
    val expiresAt: String,
    val uses: Int,
    val maxUses: Int,
    val revokedAt: String?,
    val createdAt: String
) {
    val isActive: Boolean get() = revokedAt == null && uses < maxUses
    val statusLabel: String
        get() = when {
            revokedAt != null -> "Отозвано"
            uses >= maxUses -> "Использовано"
            else -> "Активно"
        }
}

data class FamilyEvent(
    val id: String,
    val title: String,
    val dateLabel: String,
    val timeLabel: String,
    val location: String,
    val organizer: String,
    val confirmedCount: Int,
    val isConfirmedByMe: Boolean
)

data class ShoppingItem(
    val id: String,
    val title: String,
    val category: String,
    val isBought: Boolean
)

data class FamilyTask(
    val id: String,
    val title: String,
    val assignee: String,
    val deadline: String,
    val isDone: Boolean
)

data class GalleryAlbum(
    val id: String,
    val title: String,
    val itemsCount: Int,
    val dateRange: String,
    val accessLabel: String,
    val isFavorite: Boolean,
    val isPurpleAccent: Boolean
)

data class GalleryPhoto(
    val id: String,
    val albumName: String,
    val storagePath: String,
    val caption: String,
    val createdAt: String
)

data class AiTool(
    val id: String,
    val title: String,
    val subtitle: String,
    val samplePrompt: String
)

data class AiChatItem(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val time: String
)


data class ActiveCallSession(
    val id: String,
    val chatId: String,
    val chatTitle: String,
    val starterName: String,
    val callType: String, // "audio" or "video"
    val roomCode: String
)

data class NexoUiState(
    val gate: AppGate = AppGate.CHECKING_SESSION,
    val isLoading: Boolean = false,
    val authError: String? = null,
    val authNotice: String? = null,
    val supabaseUrl: String = "",
    val supabaseAnonKey: String = "",
    val isServerConfigured: Boolean = false,
    val currentUserId: String = "",
    val currentUserEmail: String = "",
    val currentUserDisplayName: String = "Участник",
    val currentUserRole: MemberRole = MemberRole.MEMBER,
    val currentTab: NexoTab = NexoTab.CHATS,
    val showProfile: Boolean = false,
    val selectedChatId: String? = null,
    val searchQuery: String = "",
    val familyId: String? = null,
    val familyName: String = "NEXO Family",
    val memberLimit: Int = 20,
    val chats: List<ChatPreview> = emptyList(),
    val messagesByChat: Map<String, List<ChatMessage>> = emptyMap(),
    val mediaCache: Map<String, ByteArray> = emptyMap(),
    val playingVoiceId: String? = null,
    val voicePlaybackSpeed: Float = 1.0f,
    val isUploadingMedia: Boolean = false,
    val members: List<FamilyMember> = emptyList(),
    val invites: List<FamilyInvite> = emptyList(),
    val lastGeneratedInviteCode: String? = null,
    val showInviteDialog: Boolean = false,
    val events: List<FamilyEvent> = emptyList(),
    val shoppingList: List<ShoppingItem> = emptyList(),
    val tasks: List<FamilyTask> = emptyList(),
    val albums: List<GalleryAlbum> = emptyList(),
    val galleryPhotos: List<GalleryPhoto> = emptyList(),
    val galleryCache: Map<String, ByteArray> = emptyMap(),
    val isUploadingGallery: Boolean = false,
    val activeCall: ActiveCallSession? = null,
    val incomingCall: ActiveCallSession? = null,
    val aiTools: List<AiTool> = emptyList(),
    val aiMessages: List<AiChatItem> = emptyList(),
    val infoDialogTitle: String? = null,
    val infoDialogBody: String? = null,
    val biometricEnabled: Boolean = false,
    val pinEnabled: Boolean = false,
    val isAppLocked: Boolean = false,
    val showSetPinDialog: Boolean = false,
    val locationSharingEnabled: Boolean = false
) {
    val onlineCount: Int get() = members.count { it.isOnline }.coerceAtLeast(1)
    val freeSlots: Int get() = (memberLimit - members.size).coerceAtLeast(0)
    val unreadNotificationsCount: Int get() = chats.sumOf { it.unreadCount }
    val canManageInvites: Boolean get() = currentUserRole == MemberRole.OWNER || currentUserRole == MemberRole.ADMIN
}
