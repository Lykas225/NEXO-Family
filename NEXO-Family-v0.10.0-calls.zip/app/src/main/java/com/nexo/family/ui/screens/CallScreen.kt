package com.nexo.family.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.net.Uri
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.nexo.family.model.ActiveCallSession
import com.nexo.family.ui.theme.NexoColors

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CallScreen(
    call: ActiveCallSession,
    displayName: String,
    onEndCall: () -> Unit
) {
    val context = LocalContext.current
    val isVideo = call.callType == "video"

    var permissionsGranted by remember {
        val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val cam = !isVideo || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        mutableStateOf(mic && cam)
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val micOk = result[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val camOk = !isVideo || result[Manifest.permission.CAMERA] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        permissionsGranted = micOk && camOk
    }

    LaunchedEffect(Unit) {
        if (!permissionsGranted) {
            val perms = if (isVideo) {
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
            } else {
                arrayOf(Manifest.permission.RECORD_AUDIO)
            }
            permLauncher.launch(perms)
        }
    }

    val encodedName = Uri.encode(displayName.ifBlank { "Участник" })
    val videoMutedFlag = if (isVideo) "false" else "true"
    val callUrl = "https://meet.ffmuc.net/${call.roomCode}" +
        "#userInfo.displayName=%22$encodedName%22" +
        "&config.prejoinPageEnabled=false" +
        "&config.startWithVideoMuted=$videoMutedFlag" +
        "&config.startWithAudioMuted=false" +
        "&config.disableDeepLinking=true" +
        "&interfaceConfig.SHOW_JITSI_WATERMARK=false" +
        "&interfaceConfig.MOBILE_APP_PROMO=false"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
    ) {
        // Top native NEXO bar
        Surface(color = NexoColors.SurfaceBar) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isVideo) Icons.Rounded.Videocam else Icons.Rounded.Mic,
                        contentDescription = null,
                        tint = if (isVideo) NexoColors.Purple else NexoColors.Turquoise,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = call.chatTitle,
                            color = NexoColors.TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (isVideo) "Видеозвонок WebRTC" else "Аудиозвонок WebRTC",
                            color = NexoColors.SuccessGreen,
                            fontSize = 11.sp
                        )
                    }
                }

                Button(
                    onClick = onEndCall,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NexoColors.DangerRed,
                        contentColor = NexoColors.TextPrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Rounded.CallEnd, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Завершить", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        if (!permissionsGranted) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (isVideo) "Нужен доступ к камере и микрофону" else "Нужен доступ к микрофону",
                        color = NexoColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Button(
                        onClick = {
                            val perms = if (isVideo) {
                                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                            } else {
                                arrayOf(Manifest.permission.RECORD_AUDIO)
                            }
                            permLauncher.launch(perms)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexoColors.Turquoise,
                            contentColor = NexoColors.DeepNavy
                        )
                    ) {
                        Text("Разрешить доступ", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            var webViewRef by remember { mutableStateOf<WebView?>(null) }

            DisposableEffect(Unit) {
                onDispose {
                    webViewRef?.apply {
                        loadUrl("about:blank")
                        stopLoading()
                        destroy()
                    }
                }
            }

            AndroidView(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        settings.userAgentString =
                            "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        webViewClient = WebViewClient()
                        webChromeClient = object : WebChromeClient() {
                            override fun onPermissionRequest(request: PermissionRequest) {
                                request.grant(request.resources)
                            }
                        }
                        loadUrl(callUrl)
                        webViewRef = this
                    }
                }
            )
        }
    }
}
