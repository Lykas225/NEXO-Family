package com.nexo.family.data

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import java.io.File

class VoiceMediaHelper(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var recordStartMs: Long = 0L

    private var player: MediaPlayer? = null

    fun startRecording(): Boolean {
        stopRecording(deleteFile = true)
        return try {
            val outFile = File(context.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
            @Suppress("DEPRECATION")
            val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                MediaRecorder()
            }
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioEncodingBitRate(64000)
            mr.setAudioSamplingRate(22050)
            mr.setOutputFile(outFile.absolutePath)
            mr.prepare()
            mr.start()
            recorder = mr
            currentFile = outFile
            recordStartMs = System.currentTimeMillis()
            true
        } catch (_: Exception) {
            stopRecording(deleteFile = true)
            false
        }
    }

    fun stopRecording(deleteFile: Boolean = false): Pair<ByteArray, String>? {
        val elapsedSec = ((System.currentTimeMillis() - recordStartMs) / 1000L).coerceAtLeast(1L)
        val durationStr = "%d:%02d".format(elapsedSec / 60, elapsedSec % 60)
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        try {
            recorder?.release()
        } catch (_: Exception) {
        }
        recorder = null

        val file = currentFile
        currentFile = null
        if (file == null || !file.exists()) return null
        if (deleteFile) {
            file.delete()
            return null
        }
        val bytes = try {
            file.readBytes()
        } catch (_: Exception) {
            null
        } finally {
            file.delete()
        }
        return if (bytes != null && bytes.isNotEmpty()) bytes to durationStr else null
    }

    fun playAudio(bytes: ByteArray, speed: Float = 1.0f, onComplete: () -> Unit) {
        stopPlayback()
        try {
            val tempFile = File(context.cacheDir, "play_${System.currentTimeMillis()}.m4a")
            tempFile.writeBytes(bytes)
            val mp = MediaPlayer().apply {
                setDataSource(tempFile.absolutePath)
                prepare()
                try {
                    playbackParams = playbackParams.setSpeed(speed)
                } catch (_: Exception) {
                }
                setOnCompletionListener {
                    stopPlayback()
                    tempFile.delete()
                    onComplete()
                }
                start()
            }
            player = mp
        } catch (_: Exception) {
            stopPlayback()
            onComplete()
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        try {
            player?.let { mp ->
                if (mp.isPlaying) {
                    mp.playbackParams = mp.playbackParams.setSpeed(speed)
                }
            }
        } catch (_: Exception) {
        }
    }

    fun stopPlayback() {
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
    }

    fun releaseAll() {
        stopRecording(deleteFile = true)
        stopPlayback()
    }
}
