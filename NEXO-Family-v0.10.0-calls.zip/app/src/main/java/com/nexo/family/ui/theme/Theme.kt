package com.nexo.family.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object NexoColors {
    val DeepNavy = Color(0xFF0A101F)
    val SurfaceBar = Color(0xFF10182B)
    val GraphiteCard = Color(0xFF172136)
    val GraphiteElevated = Color(0xFF202D47)
    val CardBorder = Color(0xFF2A3956)

    val Turquoise = Color(0xFF2DD4BF)
    val TurquoiseDim = Color(0xFF134E4A)
    val Purple = Color(0xFF8B5CF6)
    val PurpleDim = Color(0xFF2D1E57)

    val TextPrimary = Color(0xFFF8FAFC)
    val TextSecondary = Color(0xFF94A3B8)
    val SuccessGreen = Color(0xFF34D399)
    val WarningAmber = Color(0xFFFBBF24)
    val DangerRed = Color(0xFFF87171)
}

private val NexoDarkScheme = darkColorScheme(
    primary = NexoColors.Turquoise,
    onPrimary = NexoColors.DeepNavy,
    primaryContainer = NexoColors.TurquoiseDim,
    onPrimaryContainer = NexoColors.Turquoise,
    secondary = NexoColors.Purple,
    onSecondary = Color.White,
    secondaryContainer = NexoColors.PurpleDim,
    onSecondaryContainer = Color(0xFFDDD6FE),
    background = NexoColors.DeepNavy,
    onBackground = NexoColors.TextPrimary,
    surface = NexoColors.GraphiteCard,
    onSurface = NexoColors.TextPrimary,
    surfaceVariant = NexoColors.GraphiteElevated,
    onSurfaceVariant = NexoColors.TextSecondary,
    outline = NexoColors.CardBorder,
    error = NexoColors.DangerRed
)

private val NexoTypography = Typography(
    headlineMedium = TextStyle(
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-0.3).sp,
        color = NexoColors.TextPrimary
    ),
    titleLarge = TextStyle(
        fontSize = 19.sp,
        fontWeight = FontWeight.Bold,
        color = NexoColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        color = NexoColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = NexoColors.TextPrimary
    ),
    bodySmall = TextStyle(
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = NexoColors.TextSecondary
    ),
    labelMedium = TextStyle(
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.8.sp,
        color = NexoColors.TextSecondary
    )
)

@Composable
fun NexoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NexoDarkScheme,
        typography = NexoTypography,
        content = content
    )
}
