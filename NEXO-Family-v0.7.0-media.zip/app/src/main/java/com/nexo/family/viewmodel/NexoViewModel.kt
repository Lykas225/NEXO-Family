package com.nexo.family.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexo.family.data.*
import com.nexo.family.model.*
import com.nexo.family.ui.theme.NexoColors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class NexoViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = SessionStorage(application)
    private val client = SupabaseClient()
    val voiceHelper = VoiceMediaHelper(application)
    private val loadingMediaPaths = mutableSetOf<String>()
    private var chatPollingJob: Job? = null
    private var listPollingJob: Job? = null

    private val _uiState = MutableStateFlow(createBaseState())
    val uiState: StateFlow<NexoUiState> = _uiState.asStateFlow()

    init {
        restoreSessionOnStart()
    }

    override fun onCleared() {
        super.onCleared()
        voiceHelper.releaseAll()
    }

    private fun restoreSessionOnStart() {
        val config = storage.getServerConfig()
        _uiState.update {
            it.copy(
                supabaseUrl = config.url,
                supabaseAnonKey = config.anonKey,
                isServerConfigured = config.isConfigured
            )
        }

        val saved = storage.getSession()
        if (!config.isConfigured || saved == null) {
            _uiState.update { it.copy(gate = AppGate.AUTH) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(gate = AppGate.CHECKING_SESSION, isLoading = true) }
            when (val refreshed = client.refreshSession(config, saved.refreshToken)) {
                is ApiResult.Success -> {
                    storage.saveSession(refreshed.data)
                    loadFamilyAndRoute(config, refreshed.data)
                }
                is ApiResult.Error -> {
                    storage.clearSession()
                    _uiState.update {
                        it.copy(
                            gate = AppGate.AUTH,
                            isLoading = false,
                            authNotice = "Сессия завершена. Войдите снова."
                        )
                    }
                }
            }
        }
    }

    fun saveServerConfig(url: String, anonKey: String) {
        storage.saveServerConfig(url, anonKey)
        val updated = storage.getServerConfig()
        _uiState.update {
            it.copy(
                supabaseUrl = updated.url,
                supabaseAnonKey = updated.anonKey,
                isServerConfigured = updated.isConfigured,
                authError = if (updated.isConfigured) null else "Проверьте формат URL (https://...) и публичный ключ.",
                authNotice = if (updated.isConfigured) "Параметры сервера сохранены." else null
            )
        }
    }

    fun signIn(email: String, password: String) {
        val config = storage.getServerConfig()
        if (!config.isConfigured) {
            _uiState.update { it.copy(authError = "Сначала укажите Project URL и Anon Key в настройках Supabase.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null, authNotice = null) }
            when (val res = client.signIn(config, email, password)) {
                is ApiResult.Success -> {
                    storage.saveSession(res.data)
                    loadFamilyAndRoute(config, res.data)
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, authError = res.message) }
                }
            }
        }
    }

    fun signUp(email: String, password: String) {
        val config = storage.getServerConfig()
        if (!config.isConfigured) {
            _uiState.update { it.copy(authError = "Сначала укажите Project URL и Anon Key в настройках Supabase.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null, authNotice = null) }
            when (val res = client.signUp(config, email, password)) {
                is ApiResult.Success -> {
                    val outcome = res.data
                    if (outcome.session != null) {
                        storage.saveSession(outcome.session)
                        loadFamilyAndRoute(config, outcome.session)
                    } else {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                authNotice = "Аккаунт создан! Подтвердите email по ссылке из письма и нажмите «Войти»."
                            )
                        }
                    }
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, authError = res.message) }
                }
            }
        }
    }

    fun createFamily(displayName: String, familyName: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession()
        if (!config.isConfigured || session == null) {
            _uiState.update { it.copy(gate = AppGate.AUTH, authError = "Требуется вход в аккаунт.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null) }
            when (val res = client.createFamily(config, session.accessToken, displayName, familyName)) {
                is ApiResult.Success -> loadFamilyAndRoute(config, session)
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, authError = res.message) }
            }
        }
    }

    fun redeemInvite(code: String, displayName: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession()
        if (!config.isConfigured || session == null) {
            _uiState.update { it.copy(gate = AppGate.AUTH, authError = "Требуется вход в аккаунт.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null) }
            when (val res = client.redeemInvite(config, session.accessToken, code, displayName)) {
                is ApiResult.Success -> loadFamilyAndRoute(config, session)
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, authError = res.message) }
            }
        }
    }

    fun openInviteDialog() {
        _uiState.update { it.copy(showInviteDialog = true) }
        loadInvitesFromServer()
    }

    fun closeInviteDialog() {
        _uiState.update { it.copy(showInviteDialog = false, lastGeneratedInviteCode = null) }
    }

    fun generateOneTimeInvite(expiresHours: Int = 24) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val res = client.createInvite(config, session.accessToken, expiresHours)) {
                is ApiResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            lastGeneratedInviteCode = res.data.code
                        )
                    }
                    loadInvitesFromServer()
                }
                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            infoDialogTitle = "Не удалось создать приглашение",
                            infoDialogBody = res.message
                        )
                    }
                }
            }
        }
    }

    fun revokeInvite(inviteId: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            when (val res = client.revokeInvite(config, session.accessToken, inviteId)) {
                is ApiResult.Success -> loadInvitesFromServer()
                is ApiResult.Error -> showInfoDialog("Ошибка", res.message)
            }
        }
    }

    fun toggleMemberAdminRole(member: FamilyMember) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val targetRole = if (member.role == MemberRole.ADMIN) "member" else "admin"
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val res = client.updateMemberRole(config, session.accessToken, member.id, targetRole)) {
                is ApiResult.Success -> loadFamilyAndRoute(config, session)
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false) }
                    showInfoDialog("Изменение роли", res.message)
                }
            }
        }
    }

    fun removeFamilyMember(member: FamilyMember) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val res = client.removeMember(config, session.accessToken, member.id)) {
                is ApiResult.Success -> loadFamilyAndRoute(config, session)
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false) }
                    showInfoDialog("Удаление участника", res.message)
                }
            }
        }
    }

    private fun loadInvitesFromServer() {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            when (val res = client.listInvites(config, session.accessToken)) {
                is ApiResult.Success -> {
                    val mapped = res.data.map {
                        FamilyInvite(
                            id = it.id,
                            expiresAt = it.expiresAt,
                            uses = it.uses,
                            maxUses = it.maxUses,
                            revokedAt = it.revokedAt,
                            createdAt = it.createdAt
                        )
                    }
                    _uiState.update { it.copy(invites = mapped) }
                }
                is ApiResult.Error -> Unit
            }
        }
    }

    fun refreshFamilyFromServer() {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authError = null) }
            loadFamilyAndRoute(config, session)
        }
    }

    fun signOut() {
        chatPollingJob?.cancel()
        listPollingJob?.cancel()
        val config = storage.getServerConfig()
        val session = storage.getSession()
        viewModelScope.launch {
            if (config.isConfigured && session != null) {
                client.signOut(config, session.accessToken)
            }
            storage.clearSession()
            _uiState.update {
                createBaseState().copy(
                    gate = AppGate.AUTH,
                    supabaseUrl = config.url,
                    supabaseAnonKey = config.anonKey,
                    isServerConfigured = config.isConfigured,
                    authNotice = "Вы вышли из аккаунта."
                )
            }
        }
    }

    private suspend fun loadFamilyAndRoute(config: ServerConfig, session: StoredSession) {
        when (val bundleRes = client.fetchMyFamilyBundle(config, session)) {
            is ApiResult.Success -> {
                val bundle = bundleRes.data
                if (bundle == null) {
                    _uiState.update {
                        it.copy(
                            gate = AppGate.CREATE_FAMILY,
                            isLoading = false,
                            currentUserId = session.userId,
                            currentUserEmail = session.email,
                            authError = null
                        )
                    }
                } else {
                    val palette = listOf(
                        NexoColors.Turquoise,
                        NexoColors.Purple,
                        Color(0xFF38BDF8),
                        Color(0xFFA78BFA),
                        Color(0xFF34D399)
                    )
                    val uiMembers = bundle.members.mapIndexed { idx, m ->
                        val role = when (m.role) {
                            "owner" -> MemberRole.OWNER
                            "admin" -> MemberRole.ADMIN
                            else -> MemberRole.MEMBER
                        }
                        val isMe = m.userId == session.userId
                        FamilyMember(
                            id = m.userId,
                            name = if (isMe) "${m.displayName} (Вы)" else m.displayName,
                            role = role,
                            isOnline = isMe,
                            status = if (isMe) "В сети" else "Участник семьи",
                            joinedDate = m.joinedAt.ifEmpty { "Сегодня" },
                            initials = m.displayName.trim().take(2).uppercase().ifEmpty { "Н" },
                            avatarColor = palette[idx % palette.size],
                            isCurrentUser = isMe
                        )
                    }
                    val previewChats = when (val pRes = client.listMyChatsWithPreview(config, session.accessToken)) {
                        is ApiResult.Success -> pRes.data
                        is ApiResult.Error -> bundle.chats
                    }
                    val uiChats = mapRemoteChats(previewChats, palette)
                    val myRoleEnum = when (bundle.myRole) {
                        "owner" -> MemberRole.OWNER
                        "admin" -> MemberRole.ADMIN
                        else -> MemberRole.MEMBER
                    }
                    _uiState.update {
                        it.copy(
                            gate = AppGate.MAIN,
                            isLoading = false,
                            authError = null,
                            currentUserId = session.userId,
                            currentUserEmail = session.email,
                            currentUserDisplayName = bundle.myDisplayName,
                            currentUserRole = myRoleEnum,
                            familyId = bundle.familyId,
                            familyName = bundle.familyName,
                            memberLimit = bundle.memberLimit,
                            members = uiMembers,
                            chats = uiChats
                        )
                    }
                    if (myRoleEnum == MemberRole.OWNER || myRoleEnum == MemberRole.ADMIN) {
                        loadInvitesFromServer()
                    }
                    startChatListPolling()
                }
            }
            is ApiResult.Error -> {
                _uiState.update {
                    it.copy(
                        gate = AppGate.CREATE_FAMILY,
                        isLoading = false,
                        currentUserId = session.userId,
                        currentUserEmail = session.email,
                        authError = bundleRes.message
                    )
                }
            }
        }
    }

    fun selectTab(tab: NexoTab) {
        _uiState.update { it.copy(currentTab = tab, showProfile = false, selectedChatId = null) }
    }

    fun openProfile() {
        _uiState.update { it.copy(showProfile = true, selectedChatId = null) }
    }

    fun closeProfile() {
        _uiState.update { it.copy(showProfile = false) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun openChat(chatId: String) {
        _uiState.update { state ->
            val updatedChats = state.chats.map { chat ->
                if (chat.id == chatId) chat.copy(unreadCount = 0, hasMissedCall = false) else chat
            }
            state.copy(selectedChatId = chatId, chats = updatedChats)
        }
        startChatPolling(chatId)
    }

    fun closeChat() {
        chatPollingJob?.cancel()
        _uiState.update { it.copy(selectedChatId = null) }
        refreshChatsOnly()
    }

    fun startDirectChat(member: FamilyMember) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val res = client.getOrCreateDirectChat(config, session.accessToken, member.id)) {
                is ApiResult.Success -> {
                    val chatId = res.data
                    refreshChatsOnlySuspend(config, session)
                    _uiState.update { it.copy(isLoading = false, currentTab = NexoTab.CHATS) }
                    openChat(chatId)
                }
                is ApiResult.Error -> {
                    _uiState.update { it.copy(isLoading = false) }
                    showInfoDialog("Личный чат", res.message)
                }
            }
        }
    }

    fun sendMessage(chatId: String, rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return

        // Optimistic UI append
        _uiState.update { state ->
            val currentList = state.messagesByChat[chatId].orEmpty()
            val optimistic = ChatMessage(
                id = "temp_${System.currentTimeMillis()}",
                chatId = chatId,
                senderName = state.currentUserDisplayName,
                text = text,
                time = "Отправка…",
                isMine = true,
                isRead = false
            )
            val updatedMap = state.messagesByChat.toMutableMap().apply {
                put(chatId, currentList + optimistic)
            }
            val updatedChats = state.chats.map { chat ->
                if (chat.id == chatId) chat.copy(lastMessage = text, time = "Сейчас") else chat
            }
            state.copy(messagesByChat = updatedMap, chats = updatedChats)
        }

        viewModelScope.launch {
            when (val res = client.sendChatMessage(config, session.accessToken, chatId, session.userId, text)) {
                is ApiResult.Success -> {
                    loadMessagesOnce(config, session, chatId)
                    refreshChatsOnlySuspend(config, session)
                }
                is ApiResult.Error -> {
                    showInfoDialog("Ошибка отправки", res.message)
                    loadMessagesOnce(config, session, chatId)
                }
            }
        }
    }

    private fun startChatPolling(chatId: String) {
        chatPollingJob?.cancel()
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        chatPollingJob = viewModelScope.launch {
            while (isActive) {
                loadMessagesOnce(config, session, chatId)
                delay(3000)
            }
        }
    }

    private fun startChatListPolling() {
        listPollingJob?.cancel()
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        listPollingJob = viewModelScope.launch {
            while (isActive) {
                delay(8000)
                if (_uiState.value.gate == AppGate.MAIN && _uiState.value.selectedChatId == null) {
                    refreshChatsOnlySuspend(config, session)
                }
            }
        }
    }

    private suspend fun loadMessagesOnce(config: ServerConfig, session: StoredSession, chatId: String) {
        when (val res = client.listChatMessages(config, session.accessToken, chatId)) {
            is ApiResult.Success -> {
                val uiMsgs = res.data.map { m ->
                    val kind = when (m.messageType) {
                        "photo" -> MessageKind.PHOTO
                        "voice" -> MessageKind.VOICE
                        "file" -> MessageKind.FILE
                        else -> MessageKind.TEXT
                    }
                    var displayText = m.ciphertext
                    var mediaPath: String? = null
                    var mediaName: String? = null
                    var mediaMime: String? = null
                    var voiceDuration: String? = null

                    if (kind != MessageKind.TEXT) {
                        try {
                            val json = JSONObject(m.ciphertext)
                            mediaPath = json.optString("path", "").ifEmpty { null }
                            mediaName = json.optString("name", "").ifEmpty { null }
                            mediaMime = json.optString("mime", "").ifEmpty { null }
                            voiceDuration = json.optString("duration", "").ifEmpty { null }
                            displayText = mediaName ?: when (kind) {
                                MessageKind.PHOTO -> "Фото"
                                MessageKind.VOICE -> "Голосовое сообщение"
                                MessageKind.FILE -> "Файл"
                                else -> ""
                            }
                        } catch (_: Exception) {
                        }
                    }

                    ChatMessage(
                        id = m.id,
                        chatId = m.chatId,
                        senderName = m.senderName,
                        text = displayText,
                        time = formatShortTime(m.createdAt),
                        isMine = m.senderId == session.userId,
                        isRead = true,
                        kind = kind,
                        voiceDuration = voiceDuration,
                        mediaPath = mediaPath,
                        mediaName = mediaName,
                        mediaMime = mediaMime
                    )
                }
                _uiState.update { state ->
                    val updatedMap = state.messagesByChat.toMutableMap().apply {
                        put(chatId, uiMsgs)
                    }
                    state.copy(messagesByChat = updatedMap)
                }
                // Pre-download photos that aren't cached yet
                uiMsgs.filter { it.kind == MessageKind.PHOTO && !it.mediaPath.isNullOrBlank() }.forEach { msg ->
                    ensureMediaLoaded(msg.mediaPath!!)
                }
            }
            is ApiResult.Error -> Unit
        }
    }

    fun ensureMediaLoaded(path: String) {
        if (_uiState.value.mediaCache.containsKey(path) || loadingMediaPaths.contains(path)) return
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        loadingMediaPaths.add(path)
        viewModelScope.launch {
            try {
                when (val res = client.downloadChatMedia(config, session.accessToken, path)) {
                    is ApiResult.Success -> {
                        _uiState.update { st ->
                            val newCache = st.mediaCache.toMutableMap().apply { put(path, res.data) }
                            st.copy(mediaCache = newCache)
                        }
                    }
                    is ApiResult.Error -> Unit
                }
            } finally {
                loadingMediaPaths.remove(path)
            }
        }
    }

    fun sendMediaFromUri(chatId: String, uri: Uri, isPhoto: Boolean) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val app = getApplication<Application>()
        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingMedia = true) }
            try {
                val resolver = app.contentResolver
                val mime = resolver.getType(uri) ?: if (isPhoto) "image/jpeg" else "application/octet-stream"
                var fileName = if (isPhoto) "photo.jpg" else "document.bin"
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0 && cursor.moveToFirst()) {
                        val queried = cursor.getString(nameIdx)
                        if (!queried.isNullOrBlank()) fileName = queried
                    }
                }
                val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null || bytes.isEmpty()) {
                    _uiState.update { it.copy(isUploadingMedia = false) }
                    showInfoDialog("Ошибка файла", "Не удалось прочитать выбранный файл.")
                    return@launch
                }
                if (bytes.size > 25 * 1024 * 1024) {
                    _uiState.update { it.copy(isUploadingMedia = false) }
                    showInfoDialog("Файл слишком большой", "Максимальный размер вложения — 25 МБ.")
                    return@launch
                }
                when (val up = client.uploadChatMedia(config, session.accessToken, chatId, fileName, mime, bytes)) {
                    is ApiResult.Success -> {
                        val objectPath = up.data
                        val meta = JSONObject()
                            .put("path", objectPath)
                            .put("name", fileName)
                            .put("mime", mime)
                            .toString()
                        val msgType = if (isPhoto) "photo" else "file"
                        if (isPhoto) {
                            _uiState.update { st ->
                                val newCache = st.mediaCache.toMutableMap().apply { put(objectPath, bytes) }
                                st.copy(mediaCache = newCache)
                            }
                        }
                        when (val sendRes = client.sendChatMessage(config, session.accessToken, chatId, session.userId, meta, msgType)) {
                            is ApiResult.Success -> {
                                loadMessagesOnce(config, session, chatId)
                                refreshChatsOnlySuspend(config, session)
                            }
                            is ApiResult.Error -> showInfoDialog("Ошибка отправки", sendRes.message)
                        }
                    }
                    is ApiResult.Error -> showInfoDialog("Ошибка загрузки", up.message)
                }
            } catch (e: Exception) {
                showInfoDialog("Ошибка", e.localizedMessage ?: "Не удалось отправить файл")
            } finally {
                _uiState.update { it.copy(isUploadingMedia = false) }
            }
        }
    }

    fun sendVoiceBytes(chatId: String, bytes: ByteArray, durationStr: String) {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingMedia = true) }
            try {
                when (val up = client.uploadChatMedia(config, session.accessToken, chatId, "voice.m4a", "audio/mp4", bytes)) {
                    is ApiResult.Success -> {
                        val objectPath = up.data
                        val meta = JSONObject()
                            .put("path", objectPath)
                            .put("name", "voice.m4a")
                            .put("mime", "audio/mp4")
                            .put("duration", durationStr)
                            .toString()
                        _uiState.update { st ->
                            val newCache = st.mediaCache.toMutableMap().apply { put(objectPath, bytes) }
                            st.copy(mediaCache = newCache)
                        }
                        when (val sendRes = client.sendChatMessage(config, session.accessToken, chatId, session.userId, meta, "voice")) {
                            is ApiResult.Success -> {
                                loadMessagesOnce(config, session, chatId)
                                refreshChatsOnlySuspend(config, session)
                            }
                            is ApiResult.Error -> showInfoDialog("Ошибка отправки", sendRes.message)
                        }
                    }
                    is ApiResult.Error -> showInfoDialog("Ошибка загрузки голосового", up.message)
                }
            } finally {
                _uiState.update { it.copy(isUploadingMedia = false) }
            }
        }
    }

    fun toggleVoicePlayback(msg: ChatMessage) {
        val path = msg.mediaPath ?: return
        if (_uiState.value.playingVoiceId == msg.id) {
            voiceHelper.stopPlayback()
            _uiState.update { it.copy(playingVoiceId = null) }
            return
        }
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            val cached = _uiState.value.mediaCache[path]
            val bytes = cached ?: when (val res = client.downloadChatMedia(config, session.accessToken, path)) {
                is ApiResult.Success -> {
                    _uiState.update { st ->
                        val newCache = st.mediaCache.toMutableMap().apply { put(path, res.data) }
                        st.copy(mediaCache = newCache)
                    }
                    res.data
                }
                is ApiResult.Error -> {
                    showInfoDialog("Голосовое сообщение", res.message)
                    return@launch
                }
            }
            _uiState.update { it.copy(playingVoiceId = msg.id) }
            voiceHelper.playAudio(bytes, _uiState.value.voicePlaybackSpeed) {
                _uiState.update { it.copy(playingVoiceId = null) }
            }
        }
    }

    fun cycleVoiceSpeed() {
        val next = when (_uiState.value.voicePlaybackSpeed) {
            1.0f -> 1.5f
            1.5f -> 2.0f
            else -> 1.0f
        }
        _uiState.update { it.copy(voicePlaybackSpeed = next) }
        voiceHelper.setPlaybackSpeed(next)
    }

    fun openFileAttachment(msg: ChatMessage) {
        val path = msg.mediaPath ?: return
        val fileName = msg.mediaName ?: "file.bin"
        val mime = msg.mediaMime ?: "application/octet-stream"
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        val app = getApplication<Application>()

        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingMedia = true) }
            try {
                val cached = _uiState.value.mediaCache[path]
                val bytes = cached ?: when (val res = client.downloadChatMedia(config, session.accessToken, path)) {
                    is ApiResult.Success -> {
                        _uiState.update { st ->
                            val newCache = st.mediaCache.toMutableMap().apply { put(path, res.data) }
                            st.copy(mediaCache = newCache)
                        }
                        res.data
                    }
                    is ApiResult.Error -> {
                        showInfoDialog("Ошибка скачивания", res.message)
                        return@launch
                    }
                }
                val safeName = fileName.replace(Regex("[^a-zA-Z0-9._ -]"), "_").ifEmpty { "attachment.bin" }
                val outFile = File(app.cacheDir, safeName)
                outFile.writeBytes(bytes)
                val contentUri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", outFile)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(contentUri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    app.startActivity(intent)
                } catch (_: Exception) {
                    showInfoDialog("Файл загружен", "Файл «$fileName» сохранён в кэш, но на телефоне нет приложения для его открытия.")
                }
            } finally {
                _uiState.update { it.copy(isUploadingMedia = false) }
            }
        }
    }

    private fun refreshChatsOnly() {
        val config = storage.getServerConfig()
        val session = storage.getSession() ?: return
        viewModelScope.launch {
            refreshChatsOnlySuspend(config, session)
        }
    }

    private suspend fun refreshChatsOnlySuspend(config: ServerConfig, session: StoredSession) {
        when (val res = client.listMyChatsWithPreview(config, session.accessToken)) {
            is ApiResult.Success -> {
                val palette = listOf(
                    NexoColors.Turquoise,
                    NexoColors.Purple,
                    Color(0xFF38BDF8),
                    Color(0xFFA78BFA),
                    Color(0xFF34D399)
                )
                val uiChats = mapRemoteChats(res.data, palette)
                _uiState.update { it.copy(chats = uiChats) }
            }
            is ApiResult.Error -> Unit
        }
    }

    private fun mapRemoteChats(chats: List<RemoteChat>, palette: List<Color>): List<ChatPreview> {
        return chats.mapIndexed { idx, c ->
            val isFam = c.kind == "family"
            val preview = c.lastMessage.ifBlank {
                if (isFam) "Общий чат вашей семьи" else "Начните личную переписку"
            }
            ChatPreview(
                id = c.id,
                title = c.title,
                lastMessage = preview,
                time = formatShortTime(c.lastMessageAt).ifEmpty { "Сейчас" },
                unreadCount = 0,
                initials = if (isFam) "NF" else c.title.trim().take(2).uppercase().ifEmpty { "Ч" },
                accentColor = if (isFam) NexoColors.Turquoise else palette[(idx + 1) % palette.size],
                isFamilyChat = isFam,
                isPinned = isFam,
                isOnline = true
            )
        }
    }

    private fun formatShortTime(iso: String): String {
        val tIndex = iso.indexOf('T')
        if (tIndex != -1 && iso.length >= tIndex + 6) {
            return iso.substring(tIndex + 1, tIndex + 6)
        }
        return ""
    }

    fun toggleEventConfirmation(eventId: String) {
        _uiState.update { state ->
            val updated = state.events.map { event ->
                if (event.id == eventId) {
                    val nowConfirmed = !event.isConfirmedByMe
                    event.copy(
                        isConfirmedByMe = nowConfirmed,
                        confirmedCount = if (nowConfirmed) event.confirmedCount + 1 else (event.confirmedCount - 1).coerceAtLeast(0)
                    )
                } else event
            }
            state.copy(events = updated)
        }
    }

    fun toggleShoppingItem(itemId: String) {
        _uiState.update { state ->
            state.copy(
                shoppingList = state.shoppingList.map {
                    if (it.id == itemId) it.copy(isBought = !it.isBought) else it
                }
            )
        }
    }

    fun addShoppingItem(title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        _uiState.update { state ->
            val item = ShoppingItem("shop_${System.currentTimeMillis()}", clean, "Семейное", false)
            state.copy(shoppingList = listOf(item) + state.shoppingList)
        }
    }

    fun toggleTask(taskId: String) {
        _uiState.update { state ->
            state.copy(
                tasks = state.tasks.map {
                    if (it.id == taskId) it.copy(isDone = !it.isDone) else it
                }
            )
        }
    }

    fun sendAiPreviewPrompt(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        _uiState.update { state ->
            val userMsg = AiChatItem("u_${System.currentTimeMillis()}", text, true, "Сейчас")
            val botMsg = AiChatItem(
                "a_${System.currentTimeMillis() + 1}",
                "Запрос принят в интерфейсе NEXO AI. Подключение защищённого серверного AI Gateway запланировано на Этапе 8.",
                false,
                "Сейчас"
            )
            state.copy(aiMessages = state.aiMessages + userMsg + botMsg)
        }
    }

    fun toggleBiometric(enabled: Boolean) {
        _uiState.update { it.copy(biometricEnabled = enabled) }
    }

    fun togglePin(enabled: Boolean) {
        _uiState.update { it.copy(pinEnabled = enabled) }
    }

    fun toggleLocationSharing(enabled: Boolean) {
        _uiState.update { it.copy(locationSharingEnabled = enabled) }
    }

    fun showInfoDialog(title: String, body: String) {
        _uiState.update { it.copy(infoDialogTitle = title, infoDialogBody = body) }
    }

    fun dismissInfoDialog() {
        _uiState.update { it.copy(infoDialogTitle = null, infoDialogBody = null) }
    }

    private fun createBaseState(): NexoUiState {
        return NexoUiState(
            events = listOf(
                FamilyEvent("e1", "Семейный ужин", "Воскресенье, 29 ноя", "15:00", "Дом родителей", "Семья", 1, true)
            ),
            shoppingList = listOf(
                ShoppingItem("s1", "Молоко и творог", "Молочное", false),
                ShoppingItem("s2", "Фрукты к ужину", "Фрукты", false)
            ),
            tasks = listOf(
                FamilyTask("t1", "Пригласить участников семьи", "Владелец", "Сегодня", false)
            ),
            albums = listOf(
                GalleryAlbum("g1", "Семейные встречи", 0, "2026", "Вся семья", true, false)
            ),
            aiTools = listOf(
                AiTool("ai1", "Сводка переписки", "Кратко о главном за день", "Сделай краткую сводку обсуждения"),
                AiTool("ai2", "Список покупок", "Собрать и сгруппировать", "Составь список продуктов для семейного ужина"),
                AiTool("ai3", "Планировщик", "Поездки и праздники", "Помоги спланировать семейную поездку")
            ),
            aiMessages = listOf(
                AiChatItem(
                    "ai_welcome",
                    "Привет! Я NEXO AI — встроенный помощник вашей семьи. Серверный AI Gateway будет подключён на Этапе 8.",
                    false,
                    "Сегодня"
                )
            )
        )
    }
}
