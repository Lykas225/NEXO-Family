# NEXO Family

Закрытый семейный Android-мессенджер с ограничением до 20 участников.

## Состояние проекта

### Уже реализовано в исходном проекте
- Android-приложение на Kotlin + Jetpack Compose.
- Демонстрационный интерфейс: чаты, семья, календарь, галерея, профиль.
- Начальная схема Supabase/PostgreSQL с RLS.
- GitHub Actions для сборки debug APK.

### Добавлено на текущем этапе — серверное создание семьи
- SQL RPC `create_family_for_current_user`: создаёт семейную группу, владельца, семейный чат и членство владельца одной транзакцией.
- Один аккаунт может владеть только одной семейной группой.
- Имя участника ограничено 60 символами, название группы — 80 символами.
- Серверный счётчик участников и триггер атомарно блокируют вступление участника №21, в том числе при параллельных запросах.
- Удаление участника уменьшает счётчик.
- Edge Function `create-family` проверяет JWT и вызывает только эту RPC-функцию.
- В Android-клиенте нет service-role ключа; функция использует публичный Supabase anon/publishable key вместе с JWT пользователя.
- Усилены `search_path` и права доступа существующих RLS helper-функций.

### Пока не реализовано
- Экран регистрации/входа Android и подключение Supabase Auth.
- Создание семьи из Android-интерфейса.
- Одноразовые приглашения и их погашение.
- Реальная отправка сообщений, доставка и Realtime.
- Вложения и push-уведомления.
- Сквозное шифрование, голосовые/видеозвонки WebRTC и ИИ-шлюз.

Не используйте проект для конфиденциальной переписки до реализации и независимого аудита сквозного шифрования.

## Требования
- Android Studio / Gradle.
- JDK 17.
- Android SDK 35.
- minSdk 26 (Android 8.0).
- Для backend: аккаунт Supabase и Supabase CLI.

## Подготовка Supabase

1. Создайте отдельный приватный проект Supabase.
2. В SQL Editor выполните `backend/supabase/schema.sql` один раз.
3. Затем выполните миграцию `backend/supabase/migrations/202611220001_create_family_rpc.sql`.
4. Установите Supabase CLI и из каталога `backend` выполните:

   ```bash
   supabase login
   supabase link --project-ref YOUR_PROJECT_REF
   supabase functions deploy create-family
   ```

   Конфигурация `backend/supabase/config.toml` включает обязательную JWT-проверку для функции.

5. Android-клиент пока не подключён к Supabase. Для следующего этапа понадобятся Project URL и публичный anon/publishable key. Service-role key не передавайте и не помещайте в APK.

## Проверка серверного создания семьи

После включения Supabase Auth получите access token зарегистрированного пользователя и вызовите функцию:

```bash
curl -X POST "https://YOUR_PROJECT_REF.supabase.co/functions/v1/create-family" \
  -H "Authorization: Bearer USER_ACCESS_TOKEN" \
  -H "apikey: YOUR_ANON_OR_PUBLISHABLE_KEY" \
  -H "Content-Type: application/json" \
  -d '{"displayName":"Имя участника","familyName":"NEXO Family"}'
```

Успешный ответ — HTTP 201 с `familyId`. Повторная попытка создать вторую группу для того же владельца должна вернуть HTTP 409. Лимит 20 участников защищён на уровне PostgreSQL, а не только интерфейса.

## Сборка Android

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

GitHub Actions workflow `.github/workflows/android.yml` собирает debug APK при push в `main`/`master` или вручную через `workflow_dispatch`.

## Следующий этап

Подключить Supabase Auth в Android: экран регистрации/входа, безопасное хранение сессии и вызов `create-family`. После этого реализовать одноразовые приглашения с атомарной проверкой срока действия, использования и лимита 20 участников.
