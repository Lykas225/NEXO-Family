package com.nexo.family

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10191E)
private val Panel = Color(0xFF1B292F)
private val Mint = Color(0xFF65E6B0)
private val Muted = Color(0xFF9BAEB5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexoApp() }
    }
}

data class ChatPreview(val title: String, val message: String, val time: String, val unread: Int = 0, val icon: String)

@Composable
fun NexoApp() {
    var tab by remember { mutableStateOf("Чаты") }
    var selectedChat by remember { mutableStateOf<String?>(null) }
    val chats = listOf(
        ChatPreview("Семья", "Доброе утро всем!", "09:42", 2, "♥"),
        ChatPreview("Мама", "Не забудь позвонить", "Вчера", 1, "М"),
        ChatPreview("Папа", "Фотографии отправил", "Вчера", 0, "П"),
        ChatPreview("Семейные планы", "Встречаемся в воскресенье", "Пт", 0, "⌂")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Mint,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (selectedChat != null) {
                ChatScreen(selectedChat!!, onBack = { selectedChat = null })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("NEXO", color = Mint, fontSize = 27.sp, fontWeight = FontWeight.Black)
                            Text("FAMILY", color = Muted, fontSize = 10.sp, letterSpacing = 3.sp)
                        }
                        IconButton(onClick = { tab = "Профиль" }) {
                            Icon(Icons.Default.AccountCircle, null, tint = Mint, modifier = Modifier.size(30.dp))
                        }
                    }
                    when (tab) {
                        "Чаты" -> ChatsScreen(chats) { selectedChat = it }
                        "Семья" -> SimpleScreen("Моя семья", "Участники семейной группы появятся здесь после подключения сервера.", Icons.Default.Groups)
                        "Календарь" -> SimpleScreen("Семейный календарь", "Дни рождения, встречи и важные события семьи.", Icons.Default.CalendarMonth)
                        "Галерея" -> SimpleScreen("Семейная галерея", "Общие фотографии и видео будут доступны после настройки хранилища.", Icons.Default.PhotoLibrary)
                        else -> SimpleScreen("Профиль и настройки", "Закрытая группа • максимум 20 участников\nПриглашения выдаёт владелец группы.", Icons.Default.Settings)
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationBar(containerColor = Panel) {
                        val destinations = listOf(
                            "Чаты" to Icons.Default.ChatBubble,
                            "Семья" to Icons.Default.Groups,
                            "Календарь" to Icons.Default.CalendarMonth,
                            "Галерея" to Icons.Default.PhotoLibrary,
                            "Профиль" to Icons.Default.Person
                        )
                        destinations.forEach { (label, icon) ->
                            NavigationBarItem(
                                selected = tab == label,
                                onClick = { tab = label },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Mint, selectedTextColor = Mint,
                                    indicatorColor = Color(0xFF29483D),
                                    unselectedIconColor = Muted, unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatsScreen(chats: List<ChatPreview>, open: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("Твои близкие — всегда рядом", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = "", onValueChange = {}, readOnly = true,
            placeholder = { Text("Поиск по семейным чатам", color = Muted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Panel, focusedBorderColor = Mint,
                unfocusedContainerColor = Panel, focusedContainerColor = Panel
            )
        )
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("СООБЩЕНИЯ", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("4 чата", color = Mint, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats) { chat ->
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp))
                        .clickable { open(chat.title) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).background(Color(0xFF29483D), CircleShape), contentAlignment = Alignment.Center) {
                        Text(chat.icon, color = Mint, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(chat.title, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(chat.message, color = Muted, fontSize = 12.sp, maxLines = 1)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(chat.time, color = Muted, fontSize = 10.sp)
                        if (chat.unread > 0) {
                            Spacer(Modifier.height(6.dp))
                            Box(Modifier.background(Mint, CircleShape).padding(horizontal = 7.dp, vertical = 3.dp)) {
                                Text(chat.unread.toString(), color = Ink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF18362D)), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, null, tint = Mint)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Закрытое семейное пространство", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text("Только участники по приглашению", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun ChatScreen(title: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Mint) }
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text("Семейный чат • демонстрационный режим", color = Muted, fontSize = 10.sp)
            }
            IconButton(onClick = {}) { Icon(Icons.Default.Call, null, tint = Mint) }
            IconButton(onClick = {}) { Icon(Icons.Default.Videocam, null, tint = Mint) }
        }
        Column(Modifier.weight(1f).fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.Bottom) {
            Text("Добро пожаловать в NEXO Family", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            MessageBubble("Привет! Это семейное пространство.", false)
            MessageBubble("Здесь скоро заработает обмен сообщениями между устройствами.", true)
        }
        var message by remember { mutableStateOf("") }
        Row(Modifier.fillMaxWidth().background(Panel).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {}) { Icon(Icons.Default.AttachFile, null, tint = Muted) }
            OutlinedTextField(
                value = message, onValueChange = { message = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Сообщение…") },
                shape = RoundedCornerShape(24.dp), singleLine = true
            )
            IconButton(onClick = { message = "" }, enabled = message.isNotBlank()) {
                Icon(Icons.Default.Send, null, tint = Mint)
            }
        }
    }
}

@Composable
fun MessageBubble(text: String, mine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Box(Modifier.widthIn(max = 290.dp).padding(vertical = 4.dp)
            .background(if (mine) Color(0xFF245441) else Panel, RoundedCornerShape(16.dp))
            .padding(12.dp)) {
            Text(text, fontSize = 13.sp)
        }
    }
}

@Composable
fun SimpleScreen(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(50.dp))
        Icon(icon, null, tint = Mint, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(18.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}
