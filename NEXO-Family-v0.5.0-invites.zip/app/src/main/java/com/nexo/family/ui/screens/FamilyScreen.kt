package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.model.FamilyInvite
import com.nexo.family.model.FamilyMember
import com.nexo.family.model.MemberRole
import com.nexo.family.ui.components.NexoAvatar
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

@Composable
fun FamilyScreen(
    familyName: String,
    currentUserRole: MemberRole,
    members: List<FamilyMember>,
    invites: List<FamilyInvite>,
    memberLimit: Int,
    freeSlots: Int,
    canManageInvites: Boolean,
    showInviteDialog: Boolean,
    lastGeneratedInviteCode: String?,
    isLoading: Boolean,
    onOpenInviteDialog: () -> Unit,
    onCloseInviteDialog: () -> Unit,
    onGenerateInvite: () -> Unit,
    onRevokeInvite: (String) -> Unit,
    onToggleAdminRole: (FamilyMember) -> Unit,
    onRemoveMember: (FamilyMember) -> Unit,
    onRefresh: () -> Unit
) {
    val progress = (members.size.toFloat() / memberLimit.coerceAtLeast(1)).coerceIn(0f, 1f)
    val clipboard = LocalClipboardManager.current
    var copiedNotice by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            NexoCard(borderColor = NexoColors.Turquoise.copy(alpha = 0.4f)) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Brush.linearGradient(listOf(NexoColors.Turquoise, NexoColors.Purple))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Groups, contentDescription = null, tint = NexoColors.DeepNavy, modifier = Modifier.size(32.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(familyName, color = NexoColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp))
                            Text("Закрытая семейная группа", color = NexoColors.TextSecondary, fontSize = 13.sp)
                        }
                        IconButton(onClick = onRefresh) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Обновить", tint = NexoColors.Turquoise)
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Участников: ${members.size} из $memberLimit",
                            color = NexoColors.TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Свободно мест: $freeSlots",
                            color = NexoColors.SuccessGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(6.dp)),
                        color = NexoColors.Turquoise,
                        trackColor = NexoColors.GraphiteElevated
                    )

                    if (canManageInvites) {
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = onOpenInviteDialog,
                            enabled = freeSlots > 0,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NexoColors.Turquoise,
                                contentColor = NexoColors.DeepNavy
                            )
                        ) {
                            Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = if (freeSlots > 0) "Приглашения и коды доступа" else "Лимит 20 участников достигнут",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            SectionLabel("Участники семьи", "${members.size} / $memberLimit")
        }

        items(members, key = { it.id }) { member ->
            var menuExpanded by remember { mutableStateOf(false) }
            val canEditMember = !member.isCurrentUser && member.role != MemberRole.OWNER && (
                currentUserRole == MemberRole.OWNER ||
                    (currentUserRole == MemberRole.ADMIN && member.role == MemberRole.MEMBER)
                )

            NexoCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NexoAvatar(
                        initials = member.initials,
                        accentColor = member.avatarColor,
                        size = 52.dp,
                        isOnline = member.isOnline
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = member.name,
                                color = NexoColors.TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Spacer(Modifier.width(8.dp))
                            RoleBadge(role = member.role)
                        }
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = member.status,
                            color = if (member.isOnline) NexoColors.SuccessGreen else NexoColors.TextSecondary,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "В группе с ${member.joinedDate}",
                            color = NexoColors.TextSecondary.copy(alpha = 0.8f),
                            fontSize = 11.sp
                        )
                    }

                    if (canEditMember) {
                        Box {
                            IconButton(onClick = { menuExpanded = true }) {
                                Icon(Icons.Rounded.MoreVert, contentDescription = "Управление", tint = NexoColors.TextSecondary)
                            }
                            DropdownMenu(
                                expanded = menuExpanded,
                                onDismissRequest = { menuExpanded = false },
                                containerColor = NexoColors.GraphiteElevated
                            ) {
                                if (currentUserRole == MemberRole.OWNER) {
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = if (member.role == MemberRole.ADMIN) "Снять права админа" else "Назначить админом",
                                                color = NexoColors.TextPrimary
                                            )
                                        },
                                        onClick = {
                                            menuExpanded = false
                                            onToggleAdminRole(member)
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("Удалить из семьи", color = NexoColors.DangerRed) },
                                    onClick = {
                                        menuExpanded = false
                                        onRemoveMember(member)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showInviteDialog) {
        AlertDialog(
            onDismissRequest = {
                copiedNotice = false
                onCloseInviteDialog()
            },
            containerColor = NexoColors.GraphiteCard,
            shape = RoundedCornerShape(22.dp),
            title = {
                Text("Одноразовые приглашения", color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Код действует 24 часа и срабатывает ровно один раз. Сервер автоматически проверяет лимит в 20 участников.",
                        color = NexoColors.TextSecondary,
                        fontSize = 13.sp
                    )

                    if (!lastGeneratedInviteCode.isNullOrBlank()) {
                        Surface(
                            color = NexoColors.TurquoiseDim.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Новый код приглашения:", color = NexoColors.TextSecondary, fontSize = 11.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = lastGeneratedInviteCode,
                                    color = NexoColors.Turquoise,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = {
                                        clipboard.setText(AnnotatedString(lastGeneratedInviteCode))
                                        copiedNotice = true
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (copiedNotice) "Скопировано!" else "Скопировать код")
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            copiedNotice = false
                            onGenerateInvite()
                        },
                        enabled = !isLoading && freeSlots > 0,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexoColors.Turquoise,
                            contentColor = NexoColors.DeepNavy
                        )
                    ) {
                        Text("Создать одноразовый код", fontWeight = FontWeight.Bold)
                    }

                    val activeInvites = invites.filter { it.isActive }
                    if (activeInvites.isNotEmpty()) {
                        HorizontalDivider(color = NexoColors.CardBorder)
                        Text("Активные приглашения (${activeInvites.size}):", color = NexoColors.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        activeInvites.take(4).forEach { inv ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("До ${inv.expiresAt}", color = NexoColors.TextPrimary, fontSize = 12.sp)
                                    Text("Статус: ${inv.statusLabel}", color = NexoColors.SuccessGreen, fontSize = 11.sp)
                                }
                                TextButton(onClick = { onRevokeInvite(inv.id) }) {
                                    Text("Отозвать", color = NexoColors.DangerRed, fontSize = 12.sp, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    copiedNotice = false
                    onCloseInviteDialog()
                }) {
                    Text("Закрыть", color = NexoColors.Turquoise, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun RoleBadge(role: MemberRole) {
    val (bg, fg) = when (role) {
        MemberRole.OWNER -> NexoColors.TurquoiseDim to NexoColors.Turquoise
        MemberRole.ADMIN -> NexoColors.PurpleDim to NexoColors.Purple
        MemberRole.MEMBER -> NexoColors.GraphiteElevated to NexoColors.TextSecondary
    }
    Surface(color = bg, shape = RoundedCornerShape(8.dp)) {
        Text(
            text = role.label,
            color = fg,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
        )
    }
}
