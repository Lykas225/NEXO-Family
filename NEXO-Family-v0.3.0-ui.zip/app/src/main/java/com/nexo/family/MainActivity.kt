package com.nexo.family

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexo.family.model.NexoTab
import com.nexo.family.ui.components.NexoBottomBar
import com.nexo.family.ui.components.NexoTopBar
import com.nexo.family.ui.screens.*
import com.nexo.family.ui.theme.NexoColors
import com.nexo.family.ui.theme.NexoTheme
import com.nexo.family.viewmodel.NexoViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            NexoTheme {
                NexoFamilyApp()
            }
        }
    }
}

@Composable
fun NexoFamilyApp(vm: NexoViewModel = viewModel()) {
    val state by vm.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
    ) {
        val activeChat = state.selectedChatId?.let { id ->
            state.chats.firstOrNull { it.id == id }
        }

        when {
            activeChat != null -> {
                ChatDetailScreen(
                    chat = activeChat,
                    messages = state.messagesByChat[activeChat.id].orEmpty(),
                    onBack = { vm.closeChat() },
                    onSendMessage = { vm.sendLocalPreviewMessage(activeChat.id, it) },
                    onCallClick = {
                        vm.showInfoDialog(
                            "Голосовые звонки",
                            "Инфраструктура WebRTC и сервер сигнализации будут подключены на Этапе 7. Сейчас интерфейс честно показывает статус без имитации звонка."
                        )
                    },
                    onVideoCallClick = {
                        vm.showInfoDialog(
                            "Видеозвонки и групповые вызовы",
                            "Видеозвонки и SFU-сервер до 20 участников будут подключены на Этапе 7."
                        )
                    },
                    onAttachClick = {
                        vm.showInfoDialog(
                            "Вложения и файлы",
                            "Отправка фото, видео, PDF, DOCX, XLSX и архивов через Supabase Storage будет подключена на Этапе 5."
                        )
                    },
                    onVoiceClick = {
                        vm.showInfoDialog(
                            "Голосовые сообщения",
                            "Запись, прослушивание и ускорение 1× / 1.5× / 2× будут подключены на Этапе 5."
                        )
                    }
                )
            }

            state.showProfile -> {
                ProfileScreen(
                    biometricEnabled = state.biometricEnabled,
                    pinEnabled = state.pinEnabled,
                    onBack = { vm.closeProfile() },
                    onToggleBiometric = { vm.toggleBiometric(it) },
                    onTogglePin = { vm.togglePin(it) },
                    onActionInfo = { title, body -> vm.showInfoDialog(title, body) }
                )
            }

            else -> {
                Scaffold(
                    containerColor = NexoColors.DeepNavy,
                    topBar = {
                        NexoTopBar(
                            familyName = state.familyName,
                            onlineCount = state.onlineCount,
                            unreadNotifications = state.unreadNotificationsCount,
                            onNotificationsClick = {
                                vm.showInfoDialog(
                                    "Уведомления NEXO Family",
                                    "Непрочитанных сообщений: ${state.unreadNotificationsCount}. Серверные push-уведомления (FCM) будут подключены на Этапе 6."
                                )
                            },
                            onProfileClick = { vm.openProfile() }
                        )
                    },
                    bottomBar = {
                        NexoBottomBar(
                            currentTab = state.currentTab,
                            onTabSelected = { vm.selectTab(it) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = state.currentTab,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(200)) togetherWith fadeOut(animationSpec = tween(160))
                            },
                            label = "NexoTabTransition"
                        ) { tab ->
                            when (tab) {
                                NexoTab.CHATS -> ChatsScreen(
                                    chats = state.chats,
                                    searchQuery = state.searchQuery,
                                    onSearchChange = { vm.updateSearchQuery(it) },
                                    onChatClick = { vm.openChat(it) }
                                )

                                NexoTab.FAMILY -> FamilyScreen(
                                    familyName = state.familyName,
                                    members = state.members,
                                    memberLimit = state.memberLimit,
                                    freeSlots = state.freeSlots,
                                    onCreateInviteClick = {
                                        vm.showInfoDialog(
                                            "Одноразовое приглашение",
                                            "Генерация одноразового токена со сроком действия и серверной проверкой лимита в 20 человек будет подключена на Этапе 3."
                                        )
                                    },
                                    onManageRolesClick = {
                                        vm.showInfoDialog(
                                            "Управление ролями",
                                            "Назначение администраторов, удаление участников и передача прав владельца будут подключены на Этапе 3."
                                        )
                                    }
                                )

                                NexoTab.EVENTS -> EventsScreen(
                                    events = state.events,
                                    shoppingList = state.shoppingList,
                                    tasks = state.tasks,
                                    locationSharingEnabled = state.locationSharingEnabled,
                                    onToggleEventConfirm = { vm.toggleEventConfirmation(it) },
                                    onToggleShopping = { vm.toggleShoppingItem(it) },
                                    onAddShopping = { vm.addShoppingItem(it) },
                                    onToggleTask = { vm.toggleTask(it) },
                                    onToggleLocationSharing = { vm.toggleLocationSharing(it) }
                                )

                                NexoTab.GALLERY -> GalleryScreen(
                                    albums = state.albums,
                                    onUploadClick = {
                                        vm.showInfoDialog(
                                            "Семейная галерея",
                                            "Загрузка фотографий и видео в зашифрованное хранилище Supabase Storage с выбором доступа будет подключена на Этапе 9."
                                        )
                                    }
                                )

                                NexoTab.AI -> AiScreen(
                                    tools = state.aiTools,
                                    messages = state.aiMessages,
                                    onSendPrompt = { vm.sendAiPreviewPrompt(it) }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (state.infoDialogTitle != null && state.infoDialogBody != null) {
            AlertDialog(
                onDismissRequest = { vm.dismissInfoDialog() },
                containerColor = NexoColors.GraphiteCard,
                shape = RoundedCornerShape(22.dp),
                title = {
                    Text(
                        text = state.infoDialogTitle!!,
                        color = NexoColors.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Text(
                        text = state.infoDialogBody!!,
                        color = NexoColors.TextSecondary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { vm.dismissInfoDialog() }) {
                        Text("Понятно", color = NexoColors.Turquoise, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}
