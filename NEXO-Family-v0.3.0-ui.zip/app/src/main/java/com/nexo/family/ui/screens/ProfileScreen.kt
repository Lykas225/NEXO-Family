package com.nexo.family.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexo.family.ui.components.NexoAvatar
import com.nexo.family.ui.components.NexoCard
import com.nexo.family.ui.components.SectionLabel
import com.nexo.family.ui.theme.NexoColors

@Composable
fun ProfileScreen(
    biometricEnabled: Boolean,
    pinEnabled: Boolean,
    onBack: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onTogglePin: (Boolean) -> Unit,
    onActionInfo: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoColors.DeepNavy)
    ) {
        Surface(color = NexoColors.SurfaceBar) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = NexoColors.TextPrimary)
                    }
                    Text("Профиль и настройки", color = NexoColors.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.55f))
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                NexoCard {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NexoAvatar(
                            initials = "ВЫ",
                            accentColor = NexoColors.Turquoise,
                            size = 68.dp,
                            isOnline = true
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Владелец семьи", color = NexoColors.TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp))
                            Text("Статус: В сети", color = NexoColors.SuccessGreen, fontSize = 13.sp)
                            Text("NEXO Family • Версия 0.3.0 (Этап 1)", color = NexoColors.TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }

            item { SectionLabel("Безопасность и вход") }

            item {
                NexoCard {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        SettingSwitchRow(
                            icon = Icons.Rounded.Fingerprint,
                            title = "Биометрическая блокировка",
                            subtitle = "Вход по отпечатку или лицу",
                            checked = biometricEnabled,
                            onCheckedChange = onToggleBiometric
                        )
                        HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))
                        SettingSwitchRow(
                            icon = Icons.Rounded.Key,
                            title = "PIN-код приложения",
                            subtitle = "Дополнительная защита экрана",
                            checked = pinEnabled,
                            onCheckedChange = onTogglePin
                        )
                    }
                }
            }

            item { SectionLabel("Аккаунт и шифрование") }

            item {
                NexoCard {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        SettingActionRow(
                            icon = Icons.Rounded.Devices,
                            title = "Управление устройствами",
                            subtitle = "Активные сессии и доверенные телефоны",
                            onClick = {
                                onActionInfo(
                                    "Управление устройствами",
                                    "Подключение реальных сессий Supabase Auth и список активных устройств будут добавлены на Этапе 2."
                                )
                            }
                        )
                        HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))
                        SettingActionRow(
                            icon = Icons.Rounded.Lock,
                            title = "Сквозное шифрование (E2EE)",
                            subtitle = "Обмен ключами и проверка устройств — Этап 6",
                            onClick = {
                                onActionInfo(
                                    "Сквозное шифрование E2EE",
                                    "Реализация протокола обмена ключами, шифрования файлов и проверки подлинности устройств запланирована на Этапе 6."
                                )
                            }
                        )
                        HorizontalDivider(color = NexoColors.CardBorder.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))
                        SettingActionRow(
                            icon = Icons.Rounded.NotificationsNone,
                            title = "Уведомления и приватность",
                            subtitle = "Push-уведомления FCM и устройства без GMS",
                            onClick = {
                                onActionInfo(
                                    "Уведомления",
                                    "Интеграция Firebase Cloud Messaging и резервной стратегии уведомлений запланирована на Этапе 6."
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NexoColors.Turquoise, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(subtitle, color = NexoColors.TextSecondary, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = NexoColors.DeepNavy,
                checkedTrackColor = NexoColors.Turquoise
            )
        )
    }
}

@Composable
private fun SettingActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        color = NexoColors.GraphiteCard,
        onClick = onClick,
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = NexoColors.Purple, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = NexoColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(subtitle, color = NexoColors.TextSecondary, fontSize = 12.sp)
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = NexoColors.TextSecondary)
        }
    }
}
