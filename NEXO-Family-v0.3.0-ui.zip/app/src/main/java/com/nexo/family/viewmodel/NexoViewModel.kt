package com.nexo.family.viewmodel

import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import com.nexo.family.model.*
import com.nexo.family.ui.theme.NexoColors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class NexoViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(createInitialState())
    val uiState: StateFlow<NexoUiState> = _uiState.asStateFlow()

    fun selectTab(tab: NexoTab) {
        _uiState.update { it.copy(currentTab = tab, showProfile = false, selectedChatId = null) }
    }

    fun openProfile() {
        _uiState.update { it.copy(showProfile = true, selectedChatId = null) }
    }

    fun closeProfile() {
        _uiState.update { it.copy(showProfile = false) }
    }

    fun toggleNotificationsSheet(show: Boolean) {
        _uiState.update { it.copy(showNotificationsSheet = show) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun openChat(chatId: String) {
        _uiState.update { state ->
            val updatedChats = state.chats.map { chat ->
                if (chat.id == chatId) chat.copy(unreadCount = 0, hasMissedCall = false) else chat
            }
            state.copy(selectedChatId = chatId, chats = updatedChats)
        }
    }

    fun closeChat() {
        _uiState.update { it.copy(selectedChatId = null) }
    }

    fun sendLocalPreviewMessage(chatId: String, rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        _uiState.update { state ->
            val currentList = state.messagesByChat[chatId].orEmpty()
            val newMsg = ChatMessage(
                id = "local_${System.currentTimeMillis()}",
                chatId = chatId,
                senderName = "Вы",
                text = text,
                time = "Сейчас",
                isMine = true,
                isRead = false
            )
            val updatedMap = state.messagesByChat.toMutableMap().apply {
                put(chatId, currentList + newMsg)
            }
            val updatedChats = state.chats.map { chat ->
                if (chat.id == chatId) chat.copy(lastMessage = text, time = "Сейчас") else chat
            }
            state.copy(messagesByChat = updatedMap, chats = updatedChats)
        }
    }

    fun toggleEventConfirmation(eventId: String) {
        _uiState.update { state ->
            val updated = state.events.map { event ->
                if (event.id == eventId) {
                    val nowConfirmed = !event.isConfirmedByMe
                    event.copy(
                        isConfirmedByMe = nowConfirmed,
                        confirmedCount = if (nowConfirmed) event.confirmedCount + 1 else (event.confirmedCount - 1).coerceAtLeast(0)
                    )
                } else event
            }
            state.copy(events = updated)
        }
    }

    fun toggleShoppingItem(itemId: String) {
        _uiState.update { state ->
            state.copy(
                shoppingList = state.shoppingList.map {
                    if (it.id == itemId) it.copy(isBought = !it.isBought) else it
                }
            )
        }
    }

    fun addShoppingItem(title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        _uiState.update { state ->
            val item = ShoppingItem(
                id = "shop_${System.currentTimeMillis()}",
                title = clean,
                category = "Семейное",
                isBought = false
            )
            state.copy(shoppingList = listOf(item) + state.shoppingList)
        }
    }

    fun toggleTask(taskId: String) {
        _uiState.update { state ->
            state.copy(
                tasks = state.tasks.map {
                    if (it.id == taskId) it.copy(isDone = !it.isDone) else it
                }
            )
        }
    }

    fun sendAiPreviewPrompt(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        _uiState.update { state ->
            val userMsg = AiChatItem(
                id = "u_${System.currentTimeMillis()}",
                text = text,
                isUser = true,
                time = "Сейчас"
            )
            val botMsg = AiChatItem(
                id = "a_${System.currentTimeMillis() + 1}",
                text = "Запрос принят в интерфейсе NEXO AI (Этап 1). Подключение защищённого серверного AI Gateway запланировано на Этапе 8 — ключи не хранятся в APK, а помощник получает только те сообщения, которые вы сами передадите.",
                isUser = false,
                time = "Сейчас"
            )
            state.copy(aiMessages = state.aiMessages + userMsg + botMsg)
        }
    }

    fun toggleBiometric(enabled: Boolean) {
        _uiState.update { it.copy(biometricEnabled = enabled) }
    }

    fun togglePin(enabled: Boolean) {
        _uiState.update { it.copy(pinEnabled = enabled) }
    }

    fun toggleLocationSharing(enabled: Boolean) {
        _uiState.update { it.copy(locationSharingEnabled = enabled) }
    }

    fun showInfoDialog(title: String, body: String) {
        _uiState.update { it.copy(infoDialogTitle = title, infoDialogBody = body) }
    }

    fun dismissInfoDialog() {
        _uiState.update { it.copy(infoDialogTitle = null, infoDialogBody = null) }
    }

    private fun createInitialState(): NexoUiState {
        val chats = listOf(
            ChatPreview(
                id = "family_main",
                title = "Семейный чат",
                lastMessage = "Мама: Доброе утро всем! Кто во сколько в воскресенье?",
                time = "09:42",
                unreadCount = 2,
                initials = "NF",
                accentColor = NexoColors.Turquoise,
                isFamilyChat = true,
                isPinned = true,
                isOnline = true
            ),
            ChatPreview(
                id = "direct_mom",
                title = "Мама",
                lastMessage = "Пропущенный видеозвонок • Перезвони как освободишься",
                time = "09:15",
                unreadCount = 1,
                initials = "М",
                accentColor = NexoColors.Purple,
                isPinned = true,
                isOnline = true,
                hasMissedCall = true
            ),
            ChatPreview(
                id = "direct_dad",
                title = "Папа",
                lastMessage = "Загрузил фото с дачи в общую галерею",
                time = "Вчера",
                unreadCount = 0,
                initials = "П",
                accentColor = Color(0xFF38BDF8),
                isOnline = true
            ),
            ChatPreview(
                id = "direct_sister",
                title = "Анна",
                lastMessage = "Добавила продукты в список покупок",
                time = "Вчера",
                unreadCount = 0,
                initials = "А",
                accentColor = Color(0xFFA78BFA),
                isOnline = false
            )
        )

        val messages = mapOf(
            "family_main" to listOf(
                ChatMessage("m1", "family_main", "Папа", "Доброе утро! Напоминаю, что в воскресенье собираемся в 15:00.", "09:30", isMine = false),
                ChatMessage("m2", "family_main", "Мама", "Голосовое сообщение • 0:18", "09:38", isMine = false, kind = MessageKind.VOICE, voiceDuration = "0:18"),
                ChatMessage("m3", "family_main", "Вы", "Отлично, я буду вовремя и захвачу торт.", "09:41", isMine = true, isRead = true)
            ),
            "direct_mom" to listOf(
                ChatMessage("m4", "direct_mom", "Мама", "Привет! Не забудь посмотреть список покупок перед магазином.", "09:10", isMine = false),
                ChatMessage("m5", "direct_mom", "Вы", "Хорошо, уже открыл раздел События.", "09:14", isMine = true, isRead = true)
            ),
            "direct_dad" to listOf(
                ChatMessage("m6", "direct_dad", "Папа", "Загрузил фото с дачи в общую галерею.", "Вчера", isMine = false)
            ),
            "direct_sister" to listOf(
                ChatMessage("m7", "direct_sister", "Анна", "Добавила продукты в список покупок.", "Вчера", isMine = false)
            )
        )

        val members = listOf(
            FamilyMember("u1", "Вы (Основатель)", MemberRole.OWNER, true, "В сети • Управление семьёй", "22 ноя 2026", "ВЫ", NexoColors.Turquoise),
            FamilyMember("u2", "Мама", MemberRole.ADMIN, true, "В сети", "22 ноя 2026", "М", NexoColors.Purple),
            FamilyMember("u3", "Папа", MemberRole.MEMBER, true, "В сети", "22 ноя 2026", "П", Color(0xFF38BDF8)),
            FamilyMember("u4", "Анна", MemberRole.MEMBER, false, "Была 20 мин назад", "22 ноя 2026", "А", Color(0xFFA78BFA)),
            FamilyMember("u5", "Дедушка", MemberRole.MEMBER, false, "Был вчера", "22 ноя 2026", "Д", Color(0xFF34D399))
        )

        val events = listOf(
            FamilyEvent("e1", "Семейный ужин", "Воскресенье, 29 ноя", "15:00", "Дом родителей", "Мама", 4, true),
            FamilyEvent("e2", "День рождения Анны", "12 декабря", "18:00", "Ресторан «Север»", "Вы", 5, true),
            FamilyEvent("e3", "Поездка за город", "3 января", "10:00", "Загородный дом", "Папа", 3, false)
        )

        val shopping = listOf(
            ShoppingItem("s1", "Молоко и творог", "Молочное", false),
            ShoppingItem("s2", "Свежие фрукты к ужину", "Фрукты", false),
            ShoppingItem("s3", "Кофе в зёрнах", "Напитки", true),
            ShoppingItem("s4", "Салфетки и свечи", "Дом", false)
        )

        val tasks = listOf(
            FamilyTask("t1", "Забрать торт из пекарни", "Вы", "Вс, 14:00", false),
            FamilyTask("t2", "Подготовить фотоархив за осень", "Папа", "Сб, 20:00", true),
            FamilyTask("t3", "Забронировать столик на 12 дек", "Мама", "Пт, 18:00", false)
        )

        val albums = listOf(
            GalleryAlbum("g1", "Отдых 2026", 48, "Июль — Август", "Вся семья", true, false),
            GalleryAlbum("g2", "Семейные встречи", 32, "Осень 2026", "Вся семья", true, true),
            GalleryAlbum("g3", "Новый год", 64, "Январь 2026", "Вся семья", false, false),
            GalleryAlbum("g4", "Дни рождения", 29, "2025 — 2026", "Выбранные", false, true)
        )

        val aiTools = listOf(
            AiTool("ai1", "Сводка переписки", "Кратко о главном за день", "Сделай краткую сводку обсуждения воскресного ужина"),
            AiTool("ai2", "Список покупок", "Собрать и сгруппировать", "Составь список продуктов для семейного ужина на 5 человек"),
            AiTool("ai3", "Планировщик", "Поездки и праздники", "Помоги спланировать семейную поездку за город на 3 дня"),
            AiTool("ai4", "Переводчик и редактор", "Перевод и правка текста", "Переведи и оформи короткое поздравление с днём рождения")
        )

        val aiMessages = listOf(
            AiChatItem(
                id = "ai_welcome",
                text = "Привет! Я NEXO AI — встроенный помощник вашей семьи. Я не читаю личные чаты автоматически: вы сами выбираете, какие сообщения или задачи мне передать.",
                isUser = false,
                time = "Сегодня"
            )
        )

        return NexoUiState(
            chats = chats,
            messagesByChat = messages,
            members = members,
            events = events,
            shoppingList = shopping,
            tasks = tasks,
            albums = albums,
            aiTools = aiTools,
            aiMessages = aiMessages
        )
    }
}
