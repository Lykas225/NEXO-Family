package com.nexo.family.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.net.Uri
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.nexo.family.model.ActiveCallSession
import com.nexo.family.ui.theme.NexoColors

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CallScreen(
    call: ActiveCallSession,
    displayName: String,
    onEndCall: () -> Unit
) {
    val context = LocalContext.current
    val isVideo = call.callType == "video"
    var permissionsGranted by remember {
        val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val cam = !isVideo || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        mutableStateOf(mic && cam)
    }
    var pageStatus by remember { mutableStateOf("Подключение к звонку…") }
    var pageError by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val micOk = result[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val camOk = !isVideo || result[Manifest.permission.CAMERA] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        permissionsGranted = micOk && camOk
        if (!permissionsGranted) pageStatus = "Не предоставлены разрешения на микрофон/камеру"
    }


    LaunchedEffect(call.id) {
        if (!permissionsGranted) {
            val requested = if (isVideo) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                else arrayOf(Manifest.permission.RECORD_AUDIO)
            permLauncher.launch(requested)
        }
    }

    val encodedName = Uri.encode(displayName.ifBlank { "Участник" })
    val videoMutedFlag = if (isVideo) "false" else "true"
    val callUrl = "https://meet.ffmuc.net/${call.roomCode}" +
        "#userInfo.displayName=%22$encodedName%22" +
        "&config.prejoinPageEnabled=false" +
        "&config.startWithVideoMuted=$videoMutedFlag" +
        "&config.startWithAudioMuted=false" +
        "&config.disableDeepLinking=true" +
        "&interfaceConfig.SHOW_JITSI_WATERMARK=false" +
        "&interfaceConfig.MOBILE_APP_PROMO=false"

    DisposableEffect(call.id) {
        onDispose {
            webViewRef?.let { webView ->
                webView.onPause()
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.clearHistory()
                webView.removeAllViews()
                webView.destroy()
            }
            webViewRef = null
        }
    }


    Column(Modifier.fillMaxSize().background(NexoColors.DeepNavy)) {
        Surface(color = NexoColors.SurfaceBar) {
            Row(
                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (isVideo) Icons.Rounded.Videocam else Icons.Rounded.Mic, null,
                        tint = if (isVideo) NexoColors.Purple else NexoColors.Turquoise, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(call.chatTitle, color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold,
                            fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (isVideo) "Видеозвонок" else "Аудиозвонок", color = NexoColors.SuccessGreen, fontSize = 11.sp)
                    }
                }
                Button(onClick = onEndCall, shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NexoColors.DangerRed, contentColor = NexoColors.TextPrimary),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)) {
                    Icon(Icons.Rounded.CallEnd, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                    Text("Завершить", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        if (!permissionsGranted) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(if (isVideo) "Нужен доступ к камере и микрофону" else "Нужен доступ к микрофону",
                        color = NexoColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Button(onClick = {
                        val requested = if (isVideo) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                            else arrayOf(Manifest.permission.RECORD_AUDIO)
                        permLauncher.launch(requested)
                    }, colors = ButtonDefaults.buttonColors(containerColor = NexoColors.Turquoise, contentColor = NexoColors.DeepNavy)) {
                        Text("Разрешить доступ", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth().navigationBarsPadding(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        setLayerType(View.LAYER_TYPE_HARDWARE, null)
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            loadsImagesAutomatically = true
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            javaScriptCanOpenWindowsAutomatically = true
                        }
                        settings.userAgentString = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                                pageStatus = "Загрузка комнаты…"; pageError = false
                            }
                            override fun onPageFinished(view: WebView, url: String) {
                                pageStatus = "Страница звонка загружена. Ожидание участников…"; pageError = false
                            }
                            override fun onReceivedError(view: WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                                if (request.isForMainFrame) { pageStatus = "Не удалось подключиться. Проверьте интернет и попробуйте снова."; pageError = true }
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onPermissionRequest(request: PermissionRequest) {
                                post {
                                    val allowedOrigin = request.origin?.scheme == "https"
                                    val allowedResources = request.resources.filter { resource ->
                                        (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) ||
                                        (resource == PermissionRequest.RESOURCE_VIDEO_CAPTURE && isVideo && ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                                    }.toTypedArray()
                                    if (allowedOrigin && allowedResources.isNotEmpty()) request.grant(allowedResources) else request.deny()
                                }
                            }
                            override fun onProgressChanged(view: WebView, newProgress: Int) {
                                if (newProgress < 100) pageStatus = "Подключение: $newProgress%"
                            }
                        }
                        webViewRef = this
                        loadUrl(callUrl)
                    }
                }
            )
            Row(Modifier.fillMaxWidth().background(NexoColors.SurfaceBar).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(if (pageError) "⚠ $pageStatus" else pageStatus, color = NexoColors.TextPrimary, fontSize = 11.sp)
            }
        }
    }
}
